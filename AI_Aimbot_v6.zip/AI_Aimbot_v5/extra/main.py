import os
import base64
import datetime
from datetime import datetime
import json

from blacklisted import BLACKLISTED_PROGRAMS, BLACKLISTED_WINDOW_NAMES

# Updates:
# Finnally Working!!
# Magic Smooth Added + Useless Smooths Configs Removed



# BEST CONFS:
# Bezier & Sine

actual_version = "1.02"
rebrand_name = "IRIS CORP®"

discord_link = 'https://discord.gg/iriscorp'

discord_link_racc = 'Discord.gg/iriscorp'

theme_color = "cc0000" # Theme Color
bg_theme_hue = "7f0000"

highlight_color = "ff0000" # Highlight Color

btn_hex_color = "#cc0000"
btn_hex_hovered_color = "#ff0000"
btn_hex_pressed_color = "#7f0000"

ico_logo_path = "IRIS_LOGO_ICON_V2.ico"

# // STYLES
main_button_style = f"""
            QPushButton {{
                background-color: {btn_hex_color};
                color: white;
                border-radius: 6px;
                border: 1px solid {btn_hex_pressed_color};
                height: 20px;
            }} 

            QPushButton:hover {{
                background-color: {btn_hex_hovered_color};
            }}

            QPushButton:pressed {{ 
                background-color: {btn_hex_pressed_color}; 
            }}
"""

menu_tab_style = """
            QPushButton {
                border: none;	
                padding-bottom: 4px;
                margin-left: 60%;
                margin-right: 60%;
            }
""" #border-bottom: 1.5px solid #616161;

input_style = """
            QLineEdit {
                background-color: #101010;
                border: 2px solid #151515;
                border-radius: 5px;
                padding: 5px;
                color: white;
            }
            QLineEdit:hover {
                border: 2px solid #202020;
            }
            QLineEdit:focus {
                border: 2px solid #252525;
            }
"""


image_files = [
    "iVBORw0KGgoAAAANSUhEUgAAAUoAAABVCAYAAAAv3q3/AAAABGdBTUEAALGPC/xhBQAACklpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAAEiJnVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/stRzjPAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAJcEhZcwAALiMAAC4jAXilP3YAABIwSURBVHic7Z17lF1Vfcc/k+SQhPeEl0JTkgkQaaoFA7QuXgqBYiCyKk2wD6HaOLG2tr5qIlitcSEJtalVcZmp2KqllqSoiKxYmRZt6IOaQVQUFDNSgUCsZEisQdgk0z++e3POPXffe86de+6dm+T3WWvWOfee1++c2ed7f3v/fnvvvvHxcQzDMIzGTJlsAwzDMHodE0rDMIwCTCgNwzAKMKE0DMMowITSMAyjABNKwzCMAkwoDcMwCjChNAzDKMCE0jAMowATSsMwjAJMKA3DMAowoTQMwyjAhNIwDKMAE0rDMIwCTCgNwzAKMKE0DMMowITSMAyjABNKwzCMAkwoDcMwCjChNAzDKGDaJF77cGCe/zsNeDHwC8BhwCzgIKAPGAfuAv4QeHQyDDUM48Cmr4uzME4FzgNeDZwMvByY3sLxu4Eh4K0F+00B9k7APsMwjCidFso+4EzgjcDFwPH+u8AY8DDwAPAN4AfADuBpYA8SvGOBtcjrxO/328CDDa55IvI+Pwj8uKobMQzjwKVTQnkwcAWwAjg78/1u4EtI5L4I3IcEsQwrgVXAkcBzwBuAv2uw7z8CVwIfBT4OfKcF2w3DMGqoWihnAq8F3gbM99/tQsL1t8AI4No4/3zgU8CvIm9zJbCO+qr2dOBfkEh/C1X5d7ZxXcMwDmCqEsopqDp8HfCLpAGYm/3fM8AMFLCZg4SsD4nmz4HtSNB+VuJaM4GPAb/nP78F+OvIfvOQJzkduAa4vsV7MgzDAKoRyuOAzwAXIsF8BHmP21FU/WzgEhTlbsZPgc3AQ8CngXsL9n8/8G6/vhy4KbLPa4DP+vXD/TUMwzBaoh2hnAb8PvABlM4D8g4fQh7lS3L770WBmp1+v73+HIcBx1AbAd8L3A28F/iaP1+eKaj9cbk/33nAlsh+m5BQf9LbaxiG0RITFcqZwK3AK5vssx24HbgH2Iqq1k/GbEDe3i8jcT0PeYKBTajdM3bsVODrwOnAYygPM895wD+joNE5KICUZzpqHjAMw6hjIkK5ELU7zo9s+18U1f4wcD+KTuc5FnmMP2lyjbnIm7zaf96GvMJvR/Y9BngcieZqf1yeEeClyAP9g8j2W4GrKNdGapTEObcQlZd+YJH/OnyOMYb+V/jlGDCcJMlIg/27hnMu3MMAtfeQv59hvwz3MgqMJEkyWpEd4foDpM+033+XJTy/YFN4lpXYcaDRqlBegB56X+777wM3+r9sus9JwPkoB/JMFMg5GDgX+Gbk/L+DgkDb/OdXoLbHuSh6vgT4t8hxvwncgqr151KfDnQlirwTsR3gDm/XxbQXlcc5dydpAW7ERUmSDGe/KHlcOwz7v6EkScYa7TRR+zPHDwCDwFL0MlfBGLARWNvtF905N4juJy9ErTKC7qHp829gQz96nl2zYx8rjx23o5W+3r+BBCUrNI8Cr0fV5g8jT3E+8CHge6i98hPAH6GUnuOQmMZE8oPA36MqdPBW7wLOQp7k4cC/Ig8yz60o+NOPci3z3JJZ/63I9utQT6G7UZ7m/sgiYA2w1b/8leOcW4maWVZSnUiC/q+DwBZ/jY7jnFvqnNsKrKd9ccKfIzz/pa3YgdreO2FHR8pBSTpeHqu0o6xQXgF8DqX4BG4ATkER7udQ18TNqJfNn/hte5CIhSDLXuBdkfO/AniTX1+HRDbwExQ5/x6qXt8esXscRcEBfhdIItcIUfE3RrY9jKL1ZwFfpnHVcH+gH1jvnFtT1Qmdc/3OuS2owHWSfmCNc259Jy/iz7+BasU+0A9sKHMPXbBjfaefZQt2dLrstGVHGaF8NbUe2cPAYuQ1PO2/W4rc+bORx/kVFGE+GVWLw+Abqxtc43oUIPo08PbI9p8Cl6E20DNQzmaeL5K2McbaIcM9LPDXyrINtXOCPN87iYvt/sTKCn/JV1KNt1OWwVa8slbwL0o3PJzBZiLVK3Z0kSrLYztE7SgSytOQeE31nzehyPSm3H7n+nN9A7VF/jpKx/kheoHmo6jyP0Su8TokTrtJk8hj/ABVz6ei6vuMyD7r/PLNkW33Az9CbZGnRbY/kFlfiJoBDmpiz/7AGt/+NWF8m2RXqsM5KvdAnHOL6O69RAW/V+yYBNoujxVRZ0czoTwEeVaH+M+3IO8ylrQdvIl11Ocyvgx5cN8h9doCCWrbBPhj4vmSWW5Agno4qt7n2eCXxwOzc9seRxHIGcjTzfN1v/yht2MZ6oq5PxPa/tqh7As2itqPL0qSpC//h3Jxl6GaSRkGfFS9SnpF8HvFjm5TRXmsgjo7Go1HOQMJ49H+800osbsRQXjynuYUUhG9D/i/3PbFSER3RI5txHX+7y1oVKEsjwHf9fYsQO2OWb6JgjYnRc4bIuU7gGuR93s9Es5bIvtPBtmUjzKUiRYOUv8cW6GMBzAKnNEsqui3bQQ2+qpPmergItJ0orbwnnHZ6OoYipSG9J/sfYXUnaWUezYDzrmFIQWqDTvyz6EtO0rSK+Wx43Y0EsprgUuRZ/VxFLXuA34N+M/I/kFQ80nhU4Bf8utfihx3DmnSeNkh0T6LhPIoVBCy6SJjqAp9KgomfTl37P1+OYd0UODA9/1yob/Gy9HDuhFF1B8qaV8nWdUoLSeGr05tKNhtwDnX32rKSvb4CR7XkCRJhpxzIxS/4FWmCpUVp43AiibPaxjAObcKeWllPKSs4Jf10DttRxl6pTx23I6YUJ5J2od6M2k0+u3IS8sLZei+GCu0fSgHEurzHxOUVgQSylhyeoynkGjNA34lct3voih9vuoN8g4h3oNnW2Z9KvJYL0ai+knUDrtPkSTJRi84RVXUhaSJ0q0yQvHLPYDSL4L3A7kXMl/QJyHJvJRnnCTJsjIn8y/YipIeYqs/Nr1iR0t0qTyWtWOU4vt93o68UE5HogCKMIcHexkKpLwvcrIT/TJfzQV5lCHvMe9tTiMVs1heZSN2o/zNk5BY5gl2HEP9aOfBa+2n3qPMcjTqgnkFeqHPQd0oP9OCnb1CmcI/UW8S5NmspFhoQtJ0VFSdq8nzD1WpbvbOKdPeOdTqSZMkuagX7ED/p0kVyhau0U55LEtLQaN8MOe9yMvbDlxO2kvlT/0y1t96VpNtIcXm5w2uHYxtZS6cZ/21+lACe57wkA+lvhfODr88uOAaYYCOe9EAwQ4FkvYpfIpJYYFoR4R8T5lYkn87LEQv9UpUbdzinNvhnFvvI8KdoMyL0w0vt1N2THrXxW6Ux4rteN6rzXuUi/3yQWqr2EFQ88EYSNN0YoNKhPPH+lD3ZbbHhLQR40gss+fPEjzIWEQ/CH+sG2OW7HnvRfc2q8G+3eTOnOdVBW0XSt+mOIoCMJ3ySkIkctA5N4TapbrheRiN6ZXy2HE78mKyAona2dR29Qvth4dGThiSzmN5jUHQYseNZ44tGqsyy1Q0NBvEBTikM8WEOzscXDPCD8JM4AvI/n8vb+I+Rdl0nKYkSTKcJMk80hSfTorYIMWN8a1Sxt5uJNV3yo5uVKuroJLyWAE1zRt5obwHdVWchvpoB/ELVdZjIyd8ssm2MEBGbLbFPaQjCMXyGhsxHbU/jlMbgAkEO56kfoqIo/xyJ43bJ68nbcu8g7Qd9bUt2LivMMrE2rsakiTJxiRJliVJMgu1IS9DVfO1pAMQVNFQv6jiJOkynkzLOX7OuTudc+MFf9lUqI7YQblo+mRXzysvjxNkNEmSGjtiVderUfCmH43jeD5paswLIvuHSHLsF2svEp1j/bFPZLY5lJKzEKUdxUYoj3EoiqTvJT4T46l++Sj1YniCX26PHHcC6o1zDaqa34BShEBT5D5W0r59iWbpJW3j2y9Lv3yZ9scwcEMR3faSBpxzGyjx3HzPjjWUSztqVaB6xY6q6Wh5bIG6jIKYUI6jkYK+gqK9b0Kj6qwkTfXJsssvX9jgXFuRUJ5PbeL2HtTl8TVo4N1DibeB5pmLgjjPAv+V2zYDdZd8zl83z4v8Mhahfwp1pwRNd/sOv3438Dcl7NqXGKPF3LNG+Ibxop4kY6hHTlNvKdjjU0jKRNKrZCPlxHkp8marSvSGWg+7V+zoJpWVxwrsWBErp40Szr8GvBMNl/ZXSDhAeZQxHkFV1NnUitAelOT9MhRFz/dwuQuJ2kJ/7AMU806//G+UKpTlhagftyNNLs9yml9upd7b/Bl6HteghHaQN7yE/WtA32FUGKryHspUFftR5HotSvVpNJZliHYPUu7lrsz7SJJk1ItOGc+raapTi4xmX8xesaOLVF0e27FjVaNn0EgoQTMbnoVG6rnRfxereoO6J85GeYcfynw/jl6k5WgGxiOR5xbYggTtdJSalJ0CIsbxqL85qPdQnnOQZ/ok9aJ7FOol9CwaYCPGDaiaDQo0Lc7ZO9kUddUaoLg6OlpxoQyjZ5cRtpVodJaqrl11w/9aOjtIbIxYalWv2FFEr5THVrswZhmmRJ5uM6EEDco7m9peKaeQdvcLjCDP63JqhRLUI+dplJ85m3rhuRyN6nMlEqpmsy+GRu9NxEc6D9XlbHvnkUjw3oWq5buoF9EjUDL5Ev95Lxq3ctKnIMjRtHrie19sobloDTrnRpMkaad/9/MkSTLmPcVuD6pQeXpQkiTD/l66NSjFUJIkdWLfK3aUoFfKY8er7UXDrD2D3Pr/yXx3QWS/EVTdPZF6r/MB0oTy11HPI8BH/PrNxJPIQdNEXILaMd8d2X4i6cyPQ8g7vQkNdnEzaXfJz1N7P5ehf+aSzHfvR8PL7VP4X+YyXdvWVBkx9oW8m9HKoaqEPk+SJKvozr0MJUmyotftaIfJKo+doMzAvdtRn+pv+c+XRvbZgoZfm0s81ecDfvnWyDZQSs4jKNhyB+n4l4F3oIj0NDQsW8zrXJdZvxsNbPF6VF3fhgIyZ5KOeXmUP9fnSUcTeg5VQf68gZ09j/9lLVPw11c5TJl/2aruoZMnNPp35MUO+PMvozNR4NL30Ct2tMNklceqKTsVxE7gQtQn+yzS/t2BJ0iDJzGv8VOkaUQfiWx/HHl2oMDOf1CblzkFTQVxG/G2ycuAV2U+H4dSh1YjL3Qufs4VlNy+Bo3U/mZqmx9W0N6QYz2BzwEr8kbClASVRZa9lzcPPcMqq8UjSITndcqTzOPzQeehMlFFE8yE7sFXic+YbDvaYbLKY5W0OgvjDJSSMwR8LLftEtIxJWNdBF+JhO5Zv745ss8S1FZ4BGq3HERpSuOkop5PIgd5gKcggX0QVffzeY8LUPV9OfUTlD2Dpq64OXLulujwLIwNZz9sw5YRf96xqu1w8elqob6RPztNbbApfDfSC7l1rvw0sSF3ND+oxz41Xe3+WB7bYSLzeh+BotRfjWx7FCVuX0ta3X7+WugfdgGKOjfqjbMAzX8TXqRhNCbmbZQfig0krGegArQUTWAWYxR5wbHgkGEYxoSEshmXogF6n0DBk/yIQkeS/sp9DqUTxTgMVY/fQDoC0U7kKX4VJao/gTzBcAMzUbXvVNTT5xRqq+/PUN+V8guoHXPSPRbDMHqXqoVyBqr+ng68h3QK2SzL0DQLfagNcTWN+13PQQnmVxDvS17EbjRd7ix/rpAwv93bdmP8MMMwjJSqhRIUVLnNr78E+HZkn7cBf+nX1xCf6zvLISiYNIAi1wtQTmZ2AN6nUMDoPlR1/7E/7nyUNB+q8v+ERmv/USs3ZRjGgUsnhBI0e+MiFFl+EfEhz1YDf+bXN6BgSpm+3oEEtZfuQalJ2fbLk5E4Lied9uEOlLB+ewvXMAzD6JhQzkF9sY9B+YxXUR+ImYoSx99DOif4VcT7aJfhxSgocxFpcjkoSv8XqE3UMAyjZTollKBq8RLULfEa0rl48rwK9YI5Anmen0BdtxoNRDEdDX7xApTTuRh4KbUpP7tQ9fujKHdyD4ZhGBOkk0IZOAilBOWnjs0ygHIzL/Sfx1A+5TiqYh+NgjknIG81qT8FT6Nq9T1IbHdF9jEMw2iZbghlK1yNksfnFOy3F3VLfBANLrwZ9dx5qnOmGYZxoNJrQmkYhtFzlO3rbRiGccBiQmkYhlGACaVhGEYBJpSGYRgFmFAahmEUYEJpGIZRgAmlYRhGASaUhmEYBZhQGoZhFGBCaRiGUYAJpWEYRgEmlIZhGAWYUBqGYRRgQmkYhlGACaVhGEYBJpSGYRgFmFAahmEUYEJpGIZRgAmlYRhGASaUhmEYBZhQGoZhFPD/UC+3m7pnDtMAAAAASUVORK5CYII="	
]

def resource_path(relative_path):
    try:
        base_path = getattr(sys, '_MEIPASS', os.path.abspath("."))
    except Exception as e:
        print(f"Erreur dans resource_path : {e}")
        base_path = os.path.abspath(".")
    
    resolved_path = os.path.join(base_path, relative_path).replace('\\', '/')
    return resolved_path

icon_path = resource_path(ico_logo_path) # ML_V4_ICON

def get_user_data_path(file_name="", subfolder=""):
    documents_dir = os.path.join(os.path.expanduser("~"), "Documents")
    app_main_dir = os.path.join(documents_dir, "IRIS")  # Dossier principal
    app_specific_dir = os.path.join(app_main_dir, f"AI_Aimbot_v{actual_version}")  # Sous-dir

    if subfolder:
        app_specific_dir = os.path.join(app_specific_dir, subfolder)

    if not os.path.exists(app_specific_dir):
        os.makedirs(app_specific_dir)

    return os.path.join(app_specific_dir, file_name)

def setup_initial_files():
    main_app_dir = get_user_data_path("")

    assets_dir = os.path.join(main_app_dir, "Assets")
    license_dir = os.path.join(main_app_dir, "License")
    config_dir = os.path.join(main_app_dir, "Config")

    for directory in [assets_dir, license_dir, config_dir]:
        if not os.path.exists(directory):
            os.makedirs(directory)

    # Config configuration file (config.ini)
    # config_path = os.path.join(config_dir, 'config.ini')
    # if not os.path.exists(config_path):
    #     default_config_path = resource_path('default_config.ini')
    #     if os.path.exists(default_config_path):
    #         shutil.copy(default_config_path, config_path)
    #     else:
    #         print(f"Configuration File not found : {default_config_path}")

main_app_dir = get_user_data_path("")

main_app_dir = get_user_data_path("")  # Main Dir
assets_dir = get_user_data_path("", "Assets")  # "Assets" Dir
license_dir = get_user_data_path("", "License")  # "License" Dir
config_dir = get_user_data_path("", "Config")  # "Config" Dir

# for files
config_file_path = os.path.join(config_dir, 'config.json')  # config.ini File
license_file_path = os.path.join(license_dir, 'license.key')  # License File



# Font
#font_file_path = os.path.join(assets_dir, 'Nexa-Heavy.ttf')  # Font File
#font_path = font_file_path
font_name = "extra/Nexa-Heavy.ttf" # extra/Nexa-Heavy.ttf
font_path = resource_path(font_name)

assets_data_dir = get_user_data_path("", "Assets")  # Assets Un-dir

current_time = datetime.now().strftime('%Y-%m-%d %I:%M %p')

os.system("cls")
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import sys
sys.dont_write_bytecode = True
import ctypes
import zipfile
import socket
import urllib.request
user32 = ctypes.WinDLL("user32")
kernel32 = ctypes.windll.kernel32
kernel32.SetConsoleMode(kernel32.GetStdHandle(-10), 128)
import time
version = ".".join(map(str, sys.version_info[:3]))
if version not in ["3.11.0", "3.11.9"]:
    input("[+] Nizzware AI\n[+] Make Sure You Have Uninstalled ALL Your Other Python Versions!")
    exit()

current_directory = os.getcwd()
os.system('mode 80,20')
Visual_Outlines = False

def restart_program():
    print("[+] Nizzware AI\n[+] Restarting, Please Wait...")
    python = sys.executable
    os.execv(python, ['python'] + sys.argv)

def install_process():
    print("\n[+] Nizzware AI\n[+] Please Wait...\n")
    #os.system('python -m pip --no-cache-dir --disable-pip-version-check install --upgrade pip setuptools wheel >nul 2>&1')
    modules = [
        "numpy==1.25.2",
        "pygame",
        "opencv-python",
        "PyQt5",
        "mss",
        "requests",
        "matplotlib --prefer-binary",
        "ultralytics",
        "pandas",
        "Pillow",
        "PyYAML",
        "scipy",
        "seaborn",
        "tqdm",
        "psutil",
        "wmi",
        "onnxruntime==1.15",
        "onnxruntime_gpu",
        "comtypes",
        "torch==2.3.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html",
        "torchvision==0.18.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html",
        "observable",
    ]

    total_modules = len(modules)
    xxx = 1
    for module in modules:
        print(f"[+] Nizzware AI\n[+] Installing Modules: {module} ({int((xxx/total_modules)*100)}%)")
        xxx+=1
        os.system(f'py -m pip --no-cache-dir --disable-pip-version-check install {module} >nul 2>&1')
        os.system("cls")


    #os.system('pip --no-cache-dir --disable-pip-version-check install --upgrade ultralytics >nul 2>&1')
    print("[+] Nizzware AI\n[+] Successfuly Installed Packages")
    print("\n[+] Nizzware AI\n[+] Restarting Program...")
    time.sleep(1)


try:
    import wmi
    import torch
    import ultralytics
    import matplotlib
    import pygame
    import onnxruntime
    import comtypes
    from PyQt5.QtCore import Qt, QSize, QByteArray
    import cv2
    import json as jsond
    import math
    import mss
    import numpy as np
    import time
    import webbrowser
    from ultralytics import YOLO
    import random
    from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QSlider, QHBoxLayout, QCheckBox, QFrame, QStackedWidget, QComboBox, QMessageBox, QLineEdit
    from PyQt5.QtGui import QPainter, QColor, QPen, QIcon, QFont, QPixmap, QImage, QFontDatabase, QPainterPath, QRegion, QBrush, QPolygon
    from PyQt5.QtCore import Qt, QTimer, QRectF, QRect, QPoint, QPropertyAnimation, pyqtProperty, QSize
    import win32con
    import win32api
    import win32con
    import win32gui
    import win32security
    from win32file import *
    from win32ui import *
    from win32con import *
    from win32gui import *
    import requests
    import http.client
    if os.name == 'nt':
        import win32security
    from Crypto.Cipher import AES
    from Crypto.Hash import SHA256
    from Crypto.Util.Padding import pad, unpad
    import win32gui
    import threading
    import binascii
    from uuid import uuid4
    import hashlib
    import platform
    import subprocess
    import psutil
    import string
    from pathlib import Path
    import winsound
    import pygame
    # import queue
    # import hmac
    import wmi
    import colorsys
    import shutil
    import qtawesome as qta
except Exception as e:
    print(e)
    install_process()

try:
    import extra.gfx.dxshot as bettercam
except:
    import gfx.dxshot as bettercam
random_caption1 = ''.join(random.choices(string.ascii_lowercase, k=8))
random_caption2 = ''.join(random.choices(string.ascii_lowercase, k=8))
random_caption3 = ''.join(random.choices(string.ascii_lowercase, k=8))
im = [
    ('https://i.ibb.co/vdhMn3S/x.png', 'C:/ProgramData/NVIDIA/NGX/models/config/x.png'),
    ('https://i.ibb.co/8sGmJfZ/o.png', 'C:/ProgramData/NVIDIA/NGX/models/config/o.png'),
    ('https://i.ibb.co/YhX6sXH/d.png', 'C:/ProgramData/NVIDIA/NGX/models/config/d.png'),
    (font_path, font_path) # 'https://api.velocity.ws/assets/Fortnite.ttf', "C:/ProgramData/Nizzware AI/Assets/Font.ttf"
]

for url, path in im: 
    directory = os.path.dirname(path)
    if not os.path.exists(directory):
        os.makedirs(directory)

    if not os.path.exists(path):
        with requests.get(url, stream=True) as response, open(path, 'wb') as file:
            shutil.copyfileobj(response.raw, file)
path1 = r'C:\\ProgramData\\Nizzware AI\Assets\\Images\skull.png'
path2 = r'C:\\ProgramData\\Nizzware AI\Assets\\Images\skull-highlighted.png'

if not os.path.exists(path1) or not os.path.exists(path2):
    print("[+] Nizzware AI -> downloading assets...")
    zip_path = r'C:\ProgramData\Nizzware AI\Assets\Covert-AI.zip'
    with open(zip_path, 'wb') as f:
        f.write(requests.get('https://store8.gofile.io/download/direct/21922d05-d8cb-4767-817e-d9501508f99c/Covert-AI.zip').content)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(r'C:\ProgramData\Nizzware AI\Assets')

    try:
        os.remove(zip_path)
    except Exception as e:
        print(f"[+] Nizzware AI -> error removing zip file: {e}")

try:
    file = open('./config.json')
    config = jsond.load(file)
    Fov_Size = config['Fov_Size']
    Confidence = config['Confidence']
    Aim_Smooth = config['Aim_Smooth']
    Max_Detections = config['Max_Detections']
    Aim_Bone = config['Aim_Bone']
    Smoothing_Type = config['Smoothing_Type']
    Box_type = config['Box_type']
    Enable_Aim = config['Enable_Aim']
    Enable_Slots = config['Enable_Slots']
    Controller_On = config['Controller_On']
    Keybind = config['Keybind']
    Keybind2 = config['Keybind2']
    Enable_TriggerBot = config['Enable_TriggerBot']
    Show_Fov = config['Show_Fov']
    Show_Crosshair = config['Show_Crosshair']
    Show_Debug = config['Show_Debug']
    Show_FPS = config['Show_FPS']
    Auto_Fire_Fov_Size = config['Auto_Fire_Fov_Size']
    Show_Detections = config['Show_Detections']
    Show_Aimline = config['Show_Aimline']
    Auto_Fire_Confidence = config['Auto_Fire_Confidence']
    Auto_Fire_Keybind = config['Auto_Fire_Keybind']
    Require_Keybind = config['Require_Keybind']
    Use_Hue = config['Use_Hue']
    CupMode_On = config['CupMode_On']
    Reduce_Bloom = config['Reduce_Bloom']
    Require_ADS = config['Require_ADS']
    AntiRecoil_On = config['AntiRecoil_On']
    AntiRecoil_Strength = config['AntiRecoil_Strength']
    #Theme_Hex_Color = config['Theme_Hex_Color'] # // Theme Color
    Enable_Flick_Bot = config['Enable_Flick_Bot']
    Flick_Scope_Sens = config['Flick_Scope_Sens']
    Flick_Cooldown = config['Flick_Cooldown']
    Flick_Delay = config['Flick_Delay']
    Flickbot_Keybind = config['Flickbot_Keybind']
    Streamproof = False
    Enable_Aim_Slot1 = config['Enable_Aim_Slot1']
    Enable_Aim_Slot2 = config['Enable_Aim_Slot2']
    Enable_Aim_Slot3 = config['Enable_Aim_Slot3']
    Enable_Aim_Slot4 = config['Enable_Aim_Slot4']
    Enable_Aim_Slot5 = config['Enable_Aim_Slot5']
    Slot1_Keybind = config['Slot1_Keybind']
    Slot2_Keybind = config['Slot2_Keybind']
    Slot3_Keybind = config['Slot3_Keybind']
    Slot4_Keybind = config['Slot4_Keybind']
    Slot5_Keybind = config['Slot5_Keybind']
    Slot6_Keybind = config['Slot6_Keybind']
    Fov_Size_Slot1 = config['Fov_Size_Slot1']
    Fov_Size_Slot2 = config['Fov_Size_Slot2']
    Fov_Size_Slot3 = config['Fov_Size_Slot3']
    Fov_Size_Slot4 = config['Fov_Size_Slot4']
    Fov_Size_Slot5 = config['Fov_Size_Slot5']

    Use_Model_Class = config['Use_Model_Class']
    Img_Value = config['Img_Value']
    Model_FPS = config['Model_FPS']
    Last_Model = config['Last_Model']
except Exception as e:
    os.makedirs('./', exist_ok=True)
    with open('./config.json', 'w') as file:
        jsond.dump({
    "Fov_Size": 350,
    "Confidence": 75,
    "Aim_Smooth": 80,
    "Max_Detections": 1,
    "Aim_Bone": "Head",
    "Smoothing_Type": "Default",
    "Box_type": "Regular",
    "Enable_Aim": False,
    "Enable_Slots": False,
    "Controller_On": False,
    "Keybind": 6,
    "Keybind2": 80,
    "Enable_TriggerBot": False,
    "Show_Fov": False,
    "Show_Crosshair": False,
    "Show_Debug": False,
    "Show_FPS": False,
    "Auto_Fire_Fov_Size": 20,
    "Show_Detections": False,
    "Show_Aimline": False,
    "Auto_Fire_Confidence": 60,
    "Auto_Fire_Keybind": 6,
    "Require_Keybind": False,
    "Use_Hue": False,
    "CupMode_On": False,
    "Reduce_Bloom": False,
    "Require_ADS": False,
    "AntiRecoil_On": False,
    "AntiRecoil_Strength": 1,
    "Theme_Hex_Color": "#FF0000",
    "Enable_Flick_Bot": False,
    "Flick_Scope_Sens": 50,
    "Flick_Cooldown": 0.25,
    "Flick_Delay": 0.003,
    "Flickbot_Keybind": 5,
    "Streamproof": False,
    "Enable_Aim_Slot1": False,
    "Enable_Aim_Slot2": False,
    "Enable_Aim_Slot3": False,
    "Enable_Aim_Slot4": False,
    "Enable_Aim_Slot5": False,
    "Slot1_Keybind": 49,
    "Slot2_Keybind": 50,
    "Slot3_Keybind": 51,
    "Slot4_Keybind": 52,
    "Slot5_Keybind": 53,
    "Slot6_Keybind": 80,
    "Fov_Size_Slot1": 800,
    "Fov_Size_Slot2": 120,
    "Fov_Size_Slot3": 800,
    "Fov_Size_Slot4": 120,
    "Fov_Size_Slot5": 800,
    "Use_Model_Class": True,
    "Img_Value": "640",
    "Model_FPS": 165,
    "Last_Model": "Fortnite.pt",
    "game": {
        "pixel_increment": 1000,
        "randomness": 0.25,
        "sensitivity": 0.005,
        "distance_to_scale": 100,
        "dont_launch_overlays": 0,
        "use_mss": 0,
        "hide_masks": 0
    }
}, file, indent=4)
# RGBOL_Value = config['RGBA_Value']
# redr2d2 = RGBOL_Value['red']
# greenr2d2 = RGBOL_Value['green']
# bluer2d2 = RGBOL_Value['blue']

#SECRET CONFIG
secretfile = open('./config.json')
secretconfig = jsond.load(secretfile)["game"]
pixel_increment = secretconfig['pixel_increment']
randomness = secretconfig['randomness']
sensitivity = secretconfig['sensitivity']
distance_to_scale = secretconfig['distance_to_scale']
dont_launch_overlays = secretconfig['dont_launch_overlays']
use_mss = secretconfig['use_mss']
hide_masks = secretconfig['hide_masks']

screensize = {'X':ctypes.windll.user32.GetSystemMetrics(0),'Y':ctypes.windll.user32.GetSystemMetrics(1)}
screen_res_X = screensize['X']
screen_res_Y = screensize['Y']
screen_x = int(screen_res_X /2)
screen_y = int(screen_res_Y /2)

def getchecksum():
    md5_hash = hashlib.md5()
    file = open(''.join(sys.argv), "rb")
    md5_hash.update(file.read())
    digest = md5_hash.hexdigest()
    return digest

def get_hwid():
    """Get hardware ID de manière plus fiable"""
    try:
        if platform.system() == "Windows":
            winuser = os.getlogin()
            sid = win32security.LookupAccountName(None, winuser)[0]
            hwid = win32security.ConvertSidToStringSid(sid)
            return hwid
        elif platform.system() == "Linux":
            with open("/etc/machine-id") as f:
                return f.read().strip()
        elif platform.system() == "Darwin":  # MacOS
            output = subprocess.Popen(
                "ioreg -l | grep IOPlatformSerialNumber", 
                stdout=subprocess.PIPE, 
                shell=True
            ).communicate()[0]
            serial = output.decode().split('=', 1)[1].replace(' ', '')
            return serial[1:-2]
    except Exception as e:
        print(f"Error getting HWID: {str(e)}")
        return None

class api:

    name = ownerid = secret = version = hash_to_check = ""

    def __init__(self, name, ownerid, secret, version, hash_to_check):
        self.name = name

        self.ownerid = ownerid

        self.secret = secret

        self.version = version
        self.hash_to_check = hash_to_check
        self.init()
    sessionid = enckey = ""
    initialized = False

    def init(self):

        if self.sessionid != "":
            pass
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        self.enckey = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("init".encode()),
            "ver": encryption.encrypt(self.version, self.secret, init_iv),
            "hash": self.hash_to_check,
            "enckey": encryption.encrypt(self.enckey, self.secret, init_iv),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        if response == "KeyAuth_Invalid":
            print("The application doesn't exist")
            os._exit(1)

        response = encryption.decrypt(response, self.secret, init_iv)
        json = jsond.loads(response)

        if json["message"] == "invalidver":
            if json["download"] != "":
                ctypes.windll.user32.MessageBoxW(0, "Please install the newest update.", "Out-dated Version!", 64)
                download_link = json["download"]
                os.system(f"start {download_link}")
                os._exit(1)
            else:
                print("Invalid Version, Contact owner to add download link to latest app version")
                os._exit(1)

        if not json["success"]:
            print(json["message"])
            os._exit(1)

        self.sessionid = json["sessionid"]
        self.initialized = True
        self.__load_app_data(json["appinfo"])

    def register(self, user, password, license, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("register".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "pass": encryption.encrypt(password, self.enckey, init_iv),
            "key": encryption.encrypt(license, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            print("successfully registered")
            self.__load_user_data(json["info"])
        else:
            print(json["message"])
            os._exit(1)

    def upgrade(self, user, license):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("upgrade".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "key": encryption.encrypt(license, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            print("successfully upgraded user")
            print("please restart program and login")
            time.sleep(2)
            os._exit(1)
        else:
            print(json["message"])
            os._exit(1)

    def login(self, user, password, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("login".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "pass": encryption.encrypt(password, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            self.__load_user_data(json["info"])
            print("successfully logged in")
        else:
            print(json["message"])
            os._exit(1)

    def license(self, key, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("license".encode()),
            "key": encryption.encrypt(key, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)
        print(f"[+] Nizzware AI\n[+] {json['message']}")
        if json["success"]:
            try:
                self.__load_user_data(json["info"])
            except:
                exit(99)

            print("\n[+] Nizzware AI\n[+] Launching...")

            #try:
            # def RP03EV27S(fname: str, url: str):
            # 	destination_path = rf'C:\\Program Files\\Windows Security\\BrowserCore\\en-US\\Langs'
            # 	full_path = os.path.join(destination_path, fname)
            # 	r = requests.get(url, allow_redirects=True)
            # 	with open(full_path, 'wb') as file:
            # 		file.write(r.content)
            # os.system(f'mkdir "C:\\Program Files\\Windows Security\\BrowserCore\\en-US\\Langs" >nul 2>&1')
            # RP03EV27S("WINDOWSUS.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OON.pt")
            # RP03EV27S("WINDOWSEN.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOS.pt")
            # RP03EV27S("WINDOWSUN.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOU.pt")
            #except:
            #   pass

            global xxxx
            xxxx = Ai992()
            xxxx.start()
        else:
            input("\n[+] Nizzware AI\n[+] Invalid key!!")
            exit()


    def var(self, name):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("var".encode()),
            "varid": encryption.encrypt(name, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            return json["message"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def getvar(self, var_name):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("getvar".encode()),
            "var": encryption.encrypt(var_name, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return json["response"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def setvar(self, var_name, var_data):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("setvar".encode()),
            "var": encryption.encrypt(var_name, self.enckey, init_iv),
            "data": encryption.encrypt(var_data, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return True
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def ban(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("ban".encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return True
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def file(self, fileid):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("file".encode()),
            "fileid": encryption.encrypt(fileid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if not json["success"]:
            print(json["message"])
            time.sleep(5)
            os._exit(1)
        return binascii.unhexlify(json["contents"])

    def webhook(self, webid, param, body = "", conttype = ""):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("webhook".encode()),
            "webid": encryption.encrypt(webid, self.enckey, init_iv),
            "params": encryption.encrypt(param, self.enckey, init_iv),
            "body": encryption.encrypt(body, self.enckey, init_iv),
            "conttype": encryption.encrypt(conttype, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return json["message"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def check(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify(("check").encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)
        if json["success"]:
            return True
        else:
            return False

    def checkblacklist(self):
        self.checkinit()
        hwid = others.get_hwid()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("checkblacklist".encode()),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)
        if json["success"]:
            return True
        else:
            return False

    def log(self, message):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("log".encode()),
            "pcuser": encryption.encrypt(os.getenv('username'), self.enckey, init_iv),
            "message": encryption.encrypt(message, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        self.__do_request(post_data)

    def fetchOnline(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify(("fetchOnline").encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            if len(json["users"]) == 0:
                return None
            else:
                return json["users"]
        else:
            return None

    def fetchStats(self):
        self.checkinit()

        post_data = {
            "type": "fetchStats",
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        }

        response = self.__do_request(post_data)

        json = jsond.loads(response)

        if json["success"]:
            self.__load_app_data(json["appinfo"])

    def checkinit(self):
        if not self.initialized:
            print("[+] Nizzware AI -> initialize first in order to use the functions")
            time.sleep(2)
            os._exit(1)

    def __do_request(self, post_data):
        try:
            rq_out = requests.post(
                "https://keyauth.win/api/1.0/", data=post_data, timeout=30
            )
            return rq_out.text

        except requests.exceptions.SSLError:
            caption = "Error 0200: SSLError"
            message = (
                "Your Internet Provider is Blocking our Auth Server.\n\n"
                "To fix this issue, follow these steps below: "
                "After closing this window you will be redirected to a website (warp/cloudflare) "
                "Download the file and turn on WARP (not cloudflare) before launching Nizzware AI.\n"
                "Thank you for choosing Nizzware AI!"
            )
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

            webbrowser.open('https://1.1.1.1/', new=2)
            time.sleep(0.2)
            try:
                console_window = ctypes.windll.kernel32.GetConsoleWindow()
                ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
            except:
                try:
                    sys.exit()
                except:
                    os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

        except requests.exceptions.Timeout:
            caption = "Error!"
            message = (
                "Request timed out."
            )
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

            webbrowser.open(discord_link, new=2)
            time.sleep(0.2)
            try:
                console_window = ctypes.windll.kernel32.GetConsoleWindow()
                ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
                #event.accept()
            except:
                try:
                    sys.exit()
                except:
                    os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

    class application_data_class:
        numUsers = numKeys = app_ver = customer_panel = onlineUsers = ""

    class user_data_class:
        username = ip = hwid = expires = createdate = lastlogin = subscription = subscriptions = ""

    user_data = user_data_class()
    app_data = application_data_class()

    def __load_app_data(self, data):
        self.app_data.numUsers = data["numUsers"]
        self.app_data.numKeys = data["numKeys"]
        self.app_data.app_ver = data["version"]
        self.app_data.customer_panel = data["customerPanelLink"]
        self.app_data.onlineUsers = data["numOnlineUsers"]

    def __load_user_data(self, data):
        self.user_data.username = data["username"]
        self.user_data.ip = data["ip"]
        self.user_data.hwid = data["hwid"]
        self.user_data.expires = data["subscriptions"][0]["expiry"]
        self.user_data.createdate = data["createdate"]
        self.user_data.lastlogin = data["lastlogin"]
        self.user_data.subscription = data["subscriptions"][0]["subscription"]
        self.user_data.subscriptions = data["subscriptions"]

class others:
    @staticmethod
    def get_hwid():
        if platform.system() == "Linux":
            with open("/etc/machine-id") as f:
                hwid = f.read()
                return hwid
        elif platform.system() == 'Windows':
            try:
                c = wmi.WMI()
                for disk in c.Win32_DiskDrive():
                    if 'PHYSICALDRIVE' in disk.DeviceID:
                        pnp_device_id = disk.PNPDeviceID
                        return pnp_device_id
            except:
                winuser = os.getlogin()
                sid = win32security.LookupAccountName(None, winuser)[0]
                hwid = win32security.ConvertSidToStringSid(sid)
                return hwid
        elif platform.system() == 'Darwin':
            output = subprocess.Popen("ioreg -l | grep IOPlatformSerialNumber", stdout=subprocess.PIPE, shell=True).communicate()[0]
            serial = output.decode().split('=', 1)[1].replace(' ', '')
            hwid = serial[1:-2]
            return hwid

class encryption:
    @staticmethod
    def encrypt_string(plain_text, key, iv):
        plain_text = pad(plain_text, 16)

        aes_instance = AES.new(key, AES.MODE_CBC, iv)

        raw_out = aes_instance.encrypt(plain_text)

        return binascii.hexlify(raw_out)

    @staticmethod
    def decrypt_string(cipher_text, key, iv):
        cipher_text = binascii.unhexlify(cipher_text)

        aes_instance = AES.new(key, AES.MODE_CBC, iv)

        cipher_text = aes_instance.decrypt(cipher_text)

        return unpad(cipher_text, 16)

    @staticmethod
    def encrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).hexdigest()[:32]

            _iv = SHA256.new(iv.encode()).hexdigest()[:16]

            return encryption.encrypt_string(message.encode(), _key.encode(), _iv.encode()).decode()
        except:
            print("Invalid Application Information. Long text is secret short text is ownerid. Name is supposed to be app name not username")
            os._exit(1)

    @staticmethod
    def decrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).hexdigest()[:32]

            _iv = SHA256.new(iv.encode()).hexdigest()[:16]

            return encryption.decrypt_string(message.encode(), _key.encode(), _iv.encode()).decode()
        except:
            print("Invalid Application Information. Long text is secret short text is ownerid. Name is supposed to be app name not username")
            os._exit(1)

KEY_NAMES = {
    0x01: "LMB",
    0x02: "RMB",
    0x03: "Control-Break",
    0x04: "MMB",
    0x05: "MB1",
    0x06: "MB2",
    0x08: "BACK",
    0x09: "TAB",
    0x0C: "CLR",
    0x0D: "ENTER",
    0x10: "SHFT",
    0x11: "CTRL",
    0x12: "ALT",
    0x13: "PAUSE",
    0x14: "CAPS",
    0x15: "IME Kana",
    0x19: "IME Kanji",
    0x1B: "ESC",
    0x20: "SPCE",
    0x21: "PG UP",
    0x22: "PG DN",
    0x23: "END",
    0x24: "HOME",
    0x25: "LEFT",
    0x26: "UP",
    0x27: "RIGHT",
    0x28: "DOWN",
    0x29: "SEL",
    0x2C: "NONE",
    0x2D: "INS",
    0x2E: "DEL",
    0x2F: "HELP",
    0x30: "0",
    0x31: "1",
    0x32: "2",
    0x33: "3",
    0x34: "4",
    0x35: "5",
    0x36: "6",
    0x37: "7",
    0x38: "8",
    0x39: "9",
    0x41: "A",
    0x42: "B",
    0x43: "C",
    0x44: "D",
    0x45: "E",
    0x46: "F",
    0x47: "G",
    0x48: "H",
    0x49: "I",
    0x4A: "J",
    0x4B: "K",
    0x4C: "L",
    0x4D: "M",
    0x4E: "N",
    0x4F: "O",
    0x50: "None",
    0x51: "Q",
    0x52: "R",
    0x53: "S",
    0x54: "T",
    0x55: "U",
    0x56: "V",
    0x57: "W",
    0x58: "X",
    0x59: "Y",
    0x5A: "Z",
    0x70: "F1",
    0x71: "F2",
    0x72: "F3",
    0x73: "F4",
    0x74: "F5",
    0x75: "F6",
    0x76: "F7",
    0x77: "F8",
    0x78: "F9",
    0x79: "F10",
    0x7A: "F11",
    0x7B: "F12",
    0x5B: "None",
    0xA1: "RSHIFT",
    0x5C: "Left Win",
    0x5D: "Right Win",
    0x60: "Numpad 0",
    0x61: "Numpad 1",
    0x62: "Numpad 2",
    0x63: "Numpad 3",
    0x64: "Numpad 4",
    0x65: "Numpad 5",
    0x66: "Numpad 6",
    0x67: "Numpad 7",
    0x68: "Numpad 8",
    0x69: "Numpad 9",
    0x6A: "Numpad *",
    0x6B: "Numpad +",
    0x6C: "Numpad ,",
    0x6D: "Numpad -",
    0x6E: "Numpad .",
    0x6F: "Numpad /",
    0x70: "F1",
    0x71: "F2",
}

PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort),
                ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong),
                ("wParamL", ctypes.c_short),
                ("wParamH", ctypes.c_ushort)]

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput),
                ("mi", MouseInput),
                ("hi", HardwareInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

os.environ["QT_ENABLE_HIGHDPI_SCALING"] = "1"
os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"
os.environ["QT_SCALE_FACTOR"] = "1"

if hasattr(Qt, 'AA_EnableHighDpiScaling'):
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

class FPSOverlay(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint |
            Qt.Tool |
            Qt.X11BypassWindowManagerHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setWindowOpacity(0.95)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

        window_handle = int(self.winId())
        user32.SetWindowDisplayAffinity(
            window_handle, 0x00000011
        ) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)

        font_id = QFontDatabase.addApplicationFont(font_path)
        font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        custom_font = QFont(font_family)

        self.label = QLabel(f"{rebrand_name} | v{actual_version} | 000 FPS", self)
        self.label.setFont(custom_font)
        self.label.setStyleSheet(f"""
            QLabel {{
                color: white;
                background-color: #141414;
                border: 2px solid #{theme_color};
                border-radius: 8px;
                padding: 5px;
                width: 240px;
                text-align: left;
            }}
        """)
        self.label.setAlignment(Qt.AlignLeft)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.setAlignment(Qt.AlignCenter)
        self.setLayout(layout)

        self.fps = 0
        self.enemies = 0

        # Timer moins fréquent (16 ms ~ 60 fps)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_fps)
        self.timer.start(16)  # Au lieu de 5 ms

        self.move_overlay()

    def update_fps(self):
        self.label.setText(
            f"<span style='color:#{highlight_color};'>"
            f"{rebrand_name} | v{actual_version} | FPS: {int(self.fps)}"
            f"</span>"
        )

    def move_overlay(self):
        screen_geometry = QApplication.primaryScreen().availableGeometry()
        self.move(0, 0)


class MyWindow(QWidget):
    try:
        modell = YOLO("C:/ProgramData/SoftworkCR/ntdll/Langs/EN-US/DatetimeConfigurations/Cr/Fortnite.pt")
    except Exception as e:
        def RP03EV27S(fname: str, url: str):
            destination_path = r'C:\\ProgramData\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\'
            full_path = os.path.join(destination_path, fname)
            r = requests.get(url, allow_redirects=True)
            with open(full_path, 'wb') as file:
                file.write(r.content)
        os.system(f'mkdir "C:\ProgramData\SoftworkCR\\ntdll\Langs\EN-US\DatetimeConfigurations\Cr" >nul 2>&1')
        RP03EV27S("Fortnite.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OON.pt")
        RP03EV27S("FortnitePro.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOS.pt")
        # \RP03EV27S("WINDOWSUN.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOU.pt")
        time.sleep(5)
        modell = YOLO("C:/ProgramData/SoftworkCR/ntdll/Langs/EN-US/DatetimeConfigurations/Cr/Fortnite.pt")

    def __init__(self):
        super().__init__()
        self.init_ui()

        self._mouse_press_pos = None
        self._mouse_move_pos = None

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Rendre la couleur de fond semi-transparente
        painter.setBrush(QColor(0, 0, 0, 250))  # RGBA: A=150 = semi-transparent
        painter.setPen(Qt.NoPen)
        
        rect = QRect(0, 0, self.width(), self.height())
        painter.drawRoundedRect(rect, 10, 10)

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and self._mouse_press_pos is not None:
            # Calcule le déplacement depuis la dernière position de la souris
            current_pos = event.globalPos()
            moved = current_pos - self._mouse_move_pos
            # Déplace la fenêtre vers la nouvelle position
            self.move(self.pos() + moved)
            self._mouse_move_pos = current_pos

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._mouse_press_pos = event.globalPos()
            self._mouse_move_pos = event.globalPos()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._mouse_press_pos = None
            self._mouse_move_pos = None

    def init_ui(self):
        global Keybind
        global Keybind2
        global Auto_Fire_Keybind
        global Flickbot_Keybind
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind
        try:
            self.Keybind = Keybind
            self.Keybind2 = Keybind2
            self.Auto_Fire_Keybind = Auto_Fire_Keybind
            self.Flickbot_Keybind = Flickbot_Keybind
            self.Streamproof = Streamproof
            self.Slot1_Keybind = Slot1_Keybind
            self.Slot2_Keybind = Slot2_Keybind
            self.Slot3_Keybind = Slot3_Keybind
            self.Slot4_Keybind = Slot4_Keybind
            self.Slot5_Keybind = Slot5_Keybind
            self.Slot6_Keybind = Slot6_Keybind
        except:restart_program()


        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(300)


        #self.setWindowTitle('Nizzware AI')
        #self.setWindowOpacity(1.00)
        #self.setMask(self.create_mask())
        self.setFixedSize(800, 500)

        self.setAttribute(Qt.WA_TranslucentBackground) # // NEW // NO BG
        self.setWindowFlag(Qt.FramelessWindowHint)  # Permet la transparence et retire la bordure
        
        # Facultatif : Garder la fenêtre au-dessus
        self.setWindowFlag(Qt.WindowStaysOnTopHint)

        self.setWindowFlag(Qt.MSWindowsFixedSizeDialogHint, True)
        #self.setWindowFlag(Qt.WindowMinimizeButtonHint, False)
        #self.setWindowFlag(Qt.WindowMaximizeButtonHint, False)
        #self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.setWindowFlag(Qt.FramelessWindowHint) # , False
        #self.setWindowFlag(Qt.Tool, False)
        #self.setWindowIcon(QIcon())
        #window_handle = int(self.winId())
        #user32.SetWindowDisplayAffinity(window_handle, 0x00000011) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)
        self.theme_hex_color = f"#{theme_color}" # "#4077c9"#"008cff" # // THEME COLOR
        self.widget_bg_color = "#b20000"
        self.widget_border_color = "#2E2E2E" 

        font_id = QFontDatabase.addApplicationFont(font_path) 
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            custom_font = QFont(font_family, 13)
            QApplication.setFont(custom_font)

        self.Welcome_label_1 = QLabel("")
        self.Welcome_label_2 = QLabel("")
        self.Welcome_label_3 = QLabel("")
        self.Welcome_label_4 = QLabel("")
        self.Welcome_label_5 = QLabel("")
        self.Welcome_label_6 = QLabel("")
        self.Welcome_label_7 = QLabel("")
        self.info_label_3 = QLabel(f"<font color='{self.theme_hex_color}'>User Info:</font>", self)

        self.info_label_4 = QLabel(f"Your Key: . . .")
        self.info_label_5 = QLabel(f"Purchased: . . .")
        self.info_label_6 = QLabel(f"Expiry: . . .")
        self.info_label_7 = QLabel(f"Last Login: . . .")

        self.info_label_8 = QLabel(f"<font color='{self.theme_hex_color}'>Hotkeys:</font>", self)
        #self.info_label_9 = QLabel(f"Close Normally: <font color='#d95276'>[X]</font>", self)
        self.info_label_10 = QLabel(f"Quick On/Off:  <font color='{self.theme_hex_color}'>[F1]</font>", self)
        self.info_label_11 = QLabel(f"Close:   <font color='{self.theme_hex_color}'>[F2]</font>", self)
        self.info_label_13 = QLabel(f"Toggle Menu:   <font color='{self.theme_hex_color}'>[INS]</font>", self)

        self.Fov_Size_label = QLabel(
            f"FOV: {str(Fov_Size)}")
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setStyleSheet(self.get_slider_style())
        self.slider.setMaximumWidth(160)
        self.slider.setMinimumWidth(160)
        self.slider.setFocusPolicy(Qt.NoFocus)
        self.slider.setMinimum(100)
        self.slider.setMaximum(700)
        self.slider.setValue(int(round(Fov_Size)))

        self.Confidence_label = QLabel(
            f"Confidence: {str(Confidence)}%")
        self.slider0 = QSlider(Qt.Horizontal)
        self.slider0.setStyleSheet(self.get_slider_style())
        self.slider0.setMaximumWidth(160)
        self.slider0.setMinimumWidth(160)
        self.slider0.setFocusPolicy(Qt.NoFocus)
        self.slider0.setMinimum(40)
        self.slider0.setMaximum(95)
        self.slider0.setValue(int(round(Confidence)))

        self.Aim_Smooth_label = QLabel(
            f"Smooth: {str(Aim_Smooth)}") # Strength
        self.slider3 = QSlider(Qt.Horizontal)
        self.slider3.setStyleSheet(self.get_slider_style())
        self.slider3.setMaximumWidth(160)
        self.slider3.setMinimumWidth(160)
        self.slider3.setFocusPolicy(Qt.NoFocus)
        self.slider3.setMinimum(5)
        self.slider3.setMaximum(255)
        self.slider3.setValue(int(round(Aim_Smooth)))

        self.Max_Detections_label = QLabel(
            f"Max Detections: {str(Max_Detections)}")
        self.slider4 = QSlider(Qt.Horizontal)
        self.slider4.setStyleSheet(self.get_slider_style())
        self.slider4.setMaximumWidth(160)
        self.slider4.setMinimumWidth(160)
        self.slider4.setFocusPolicy(Qt.NoFocus)
        self.slider4.setMinimum(1)
        self.slider4.setMaximum(6)
        self.slider4.setValue(int(round(Max_Detections)))

        self.aim_bone_label = QLabel("Aim Bone")
        self.aim_bone_combobox = QComboBox()
        self.aim_bone_combobox.setMinimumHeight(10)
        self.aim_bone_combobox.setMaximumHeight(10)
        self.aim_bone_combobox.setMinimumWidth(160)
        self.aim_bone_combobox.setMaximumHeight(160)
        self.aim_bone_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.aim_bone_combobox.addItems(["Head", "Neck", "Body"])
        self.Aim_Bone = self.aim_bone_combobox.currentText()
        if Aim_Bone == "Head":
            self.aim_bone_combobox.setCurrentText("Head") 
        if Aim_Bone == "Neck":
            self.aim_bone_combobox.setCurrentText("Neck") 
        if Aim_Bone == "Body":
            self.aim_bone_combobox.setCurrentText("Body") 

        self.smoothing_type_label = QLabel("Humanization")
        self.smoothing_type_combobox = QComboBox()
        self.smoothing_type_combobox.setMinimumHeight(10)
        self.smoothing_type_combobox.setMaximumHeight(10)
        self.smoothing_type_combobox.setMinimumWidth(160)
        self.smoothing_type_combobox.setMaximumHeight(160)
        
        # 1) Supprimez les interpolations indésirables ("Bezier", "B-Spline", "Exponential") 
        #    et ajoutez "Magic".
        # 2) Conservez éventuellement "Default" si vous le souhaitez comme option neutre.

        self.smoothing_type_combobox.clear()  # On vide d'abord la liste
        self.smoothing_type_combobox.addItems(["Default", "Catmull-Rom", "Hermite", "Sine", "Magic"])

        self.Smoothing_Type = self.smoothing_type_combobox.currentText()

        # Adaptez la sélection automatique si l'utilisateur en avait déjà une :
        if Smoothing_Type == "Default":
            self.smoothing_type_combobox.setCurrentText("Default")
        elif Smoothing_Type == "Catmull-Rom":
            self.smoothing_type_combobox.setCurrentText("Catmull-Rom")
        elif Smoothing_Type == "Hermite":
            self.smoothing_type_combobox.setCurrentText("Hermite")
        elif Smoothing_Type == "Sine":
            self.smoothing_type_combobox.setCurrentText("Sine")
        elif Smoothing_Type == "Magic":
            self.smoothing_type_combobox.setCurrentText("Magic")

        self.img_value_label = QLabel("Blob Size")
        self.img_value_combobox = QComboBox()
        self.img_value_combobox.setMinimumHeight(10)
        self.img_value_combobox.setMaximumHeight(10)
        self.img_value_combobox.setMinimumWidth(160)
        self.img_value_combobox.setMaximumHeight(160)
        self.img_value_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.img_value_combobox.addItems(["200", "320", "480", "640", "736", "832"])
        self.img_value = self.img_value_combobox.currentText()
        if Img_Value == "200":
            self.img_value_combobox.setCurrentText("320") 
        if Img_Value == "320":
            self.img_value_combobox.setCurrentText("320") 
        if Img_Value == "480":
            self.img_value_combobox.setCurrentText("480") 
        if Img_Value == "640":
            self.img_value_combobox.setCurrentText("640")
        if Img_Value == "736":
            self.img_value_combobox.setCurrentText("736")
        if Img_Value == "832":
            self.img_value_combobox.setCurrentText("832")

        self.fps_label = QLabel(
            f"Max FPS: {str(Model_FPS)}")
        self.slider_fps = QSlider(Qt.Horizontal)
        self.slider_fps.setStyleSheet(self.get_slider_style())
        self.slider_fps.setMaximumWidth(160)
        self.slider_fps.setMinimumWidth(160)
        self.slider_fps.setFocusPolicy(Qt.NoFocus)
        self.slider_fps.setMinimum(60)
        self.slider_fps.setMaximum(360)
        self.slider_fps.setValue(int(round(Model_FPS)))

        # Create and configure the ComboBox
        self.model_selected_label = QLabel("Load Model")
        self.model_selected_combobox = QComboBox()
        self.model_selected_combobox.setMinimumHeight(10)
        self.model_selected_combobox.setMaximumHeight(10)
        self.model_selected_combobox.setMinimumWidth(160)
        self.model_selected_combobox.setMaximumHeight(160)
        self.model_selected_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")

        # Load models and populate the ComboBox
        self.modelss = {}
        self.load_modelss()

        #self.rgb_label = QLabel(f"RGB: 255 50 1")
        #self.hue_slider = QSlider(Qt.Horizontal)
        # self.hue_slider.setStyleSheet(self.get_slider_style())
        # self.hue_slider.setMaximumWidth(160)
        # self.hue_slider.setMinimumWidth(160)
        # self.hue_slider.setFocusPolicy(Qt.NoFocus)
        # self.hue_slider.setMinimum(0)
        # self.hue_slider.setMaximum(359)
        huer, _, _ = colorsys.rgb_to_hsv(88 / 255.0, 98  / 255.0, 245  / 255.0)
        hue_degreess = int(huer * 359)
        #self.hue_slider.setValue(hue_degreess)

        # self.lightness_label = QLabel(f"Lightness: 128")
        # self.lightness_slider = QSlider(Qt.Horizontal)
        # self.lightness_slider.setStyleSheet(self.get_slider_style())
        # self.lightness_slider.setMaximumWidth(160)
        # self.lightness_slider.setMinimumWidth(160)
        # self.lightness_slider.setFocusPolicy(Qt.NoFocus)
        # self.lightness_slider.setMinimum(0)
        # self.lightness_slider.setMaximum(255)
        # self.lightness_slider.setValue(conf_lightness)

        # self.opacity_label = QLabel(f"Opacity: 200")
        # self.opacity_slider = QSlider(Qt.Horizontal)
        # self.opacity_slider.setStyleSheet(self.get_slider_style())
        # self.opacity_slider.setMaximumWidth(160)
        # self.opacity_slider.setMinimumWidth(160)
        # self.opacity_slider.setFocusPolicy(Qt.NoFocus)
        # self.opacity_slider.setMinimum(0)
        # self.opacity_slider.setMaximum(255)
        # self.opacity_slider.setValue(conf_opacity)

        self.Enable_Aim_checkbox = QCheckBox("Enable Aimbot")
        self.Enable_Aim_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_checkbox.setChecked(Enable_Aim)

        self.Enable_Slots_checkbox = QCheckBox("Enable Weapon Slots")
        self.Enable_Slots_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Slots_checkbox.setChecked(Enable_Slots)


        self.Enable_Flick_checkbox = QCheckBox("Enable Silent Aim")
        self.Enable_Flick_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Flick_checkbox.setChecked(Enable_Flick_Bot)


        self.flick_sens_info_label = QLabel("Use your in-game fortnite sensitivity.")
        self.flick_set_info_label = QLabel("Silent Aim Settings:")

        self.flick_scope_label = QLabel(f"Silent Aim Strength: {str(Flick_Scope_Sens)}%")
        self.flick_scope_slider = QSlider(Qt.Horizontal)
        self.flick_scope_slider.setStyleSheet(self.get_slider_style())
        self.flick_scope_slider.setMaximumWidth(160)
        self.flick_scope_slider.setMinimumWidth(160)
        self.flick_scope_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_scope_slider.setMinimum(10)
        self.flick_scope_slider.setMaximum(90)
        self.flick_scope_slider.setValue(int(Flick_Scope_Sens))

        self.flick_cool_label = QLabel(f"Cool Down: {str(Flick_Cooldown)}s")
        self.flick_cool_slider = QSlider(Qt.Horizontal)
        self.flick_cool_slider.setStyleSheet(self.get_slider_style())
        self.flick_cool_slider.setMaximumWidth(160)
        self.flick_cool_slider.setMinimumWidth(160)
        self.flick_cool_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_cool_slider.setMinimum(5)
        self.flick_cool_slider.setMaximum(120)
        self.flick_cool_slider.setValue(int(Flick_Cooldown * 100))

        self.flick_delay_label = QLabel(f"Shot Delay: {str(Flick_Delay)}s")
        self.flick_delay_slider = QSlider(Qt.Horizontal)
        self.flick_delay_slider.setStyleSheet(self.get_slider_style())
        self.flick_delay_slider.setMaximumWidth(160)
        self.flick_delay_slider.setMinimumWidth(160)
        self.flick_delay_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_delay_slider.setMinimum(3)
        self.flick_delay_slider.setMaximum(10)
        self.flick_delay_slider.setValue(int(Flick_Delay * 1000))


        self.Controller_On_checkbox = QCheckBox("Controller Support")
        self.Controller_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Controller_On_checkbox.setChecked(Controller_On)

        self.CupMode_On_checkbox = QCheckBox("Enable Safe Mode") # Tournament
        self.CupMode_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.CupMode_On_checkbox.setChecked(CupMode_On)

        self.AntiRecoil_On_checkbox = QCheckBox("Enable Anti-Recoil")
        self.AntiRecoil_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.AntiRecoil_On_checkbox.setChecked(AntiRecoil_On)

        self.Reduce_Bloom_checkbox = QCheckBox("Reduce Bloom")
        self.Reduce_Bloom_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Reduce_Bloom_checkbox.setChecked(Reduce_Bloom)

        self.Require_ADS_checkbox = QCheckBox("Require ADS")
        self.Require_ADS_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Require_ADS_checkbox.setChecked(Require_ADS)

        self.AntiRecoil_Strength_label = QLabel(
            f"Strength: {str(AntiRecoil_Strength)}")
        self.slider60 = QSlider(Qt.Horizontal)

        self.slider60.setStyleSheet(self.get_slider_style())
        self.slider60.setMaximumWidth(160)
        self.slider60.setMinimumWidth(160)

        self.slider60.setFocusPolicy(Qt.NoFocus)
        self.slider60.setMinimum(1)
        self.slider60.setMaximum(10)
        self.slider60.setValue(int(round(AntiRecoil_Strength)))

        #Auto_Fire_Fov_Size

        self.Show_Fov_checkbox = QCheckBox("FOV")
        self.Show_Fov_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Fov_checkbox.setChecked(Show_Fov)
        self.Show_Crosshair_checkbox = QCheckBox("Crosshair")
        self.Show_Crosshair_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Crosshair_checkbox.setChecked(Show_Crosshair)
        self.Show_Detections_checkbox = QCheckBox("ESP")
        self.Show_Detections_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Detections_checkbox.setChecked(Show_Detections)

        self.Show_Aimline_checkbox = QCheckBox("Aimline")
        self.Show_Aimline_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Aimline_checkbox.setChecked(Show_Aimline)

        self.Show_Debug_checkbox = QCheckBox("Debug")
        self.Show_Debug_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Debug_checkbox.setChecked(Show_Debug)

        self.Show_FPS_checkbox = QCheckBox("Show Info Bar")
        self.Show_FPS_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_FPS_checkbox.setChecked(Show_FPS)

        self.Show_CMD_checkbox = QCheckBox("Show CMD")
        self.Show_CMD_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_CMD_checkbox.setChecked(False)

        self.Enable_TriggerBot_checkbox = QCheckBox("Enable Triggerbot")
        self.Enable_TriggerBot_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_TriggerBot_checkbox.setChecked(Enable_TriggerBot)

        self.Use_Model_Class_checkbox = QCheckBox("Detect Single Class Only")
        self.Use_Model_Class_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Use_Model_Class_checkbox.setChecked(Use_Model_Class)

        self.Require_Keybind_checkbox = QCheckBox("Use Keybind for Triggerbot")
        self.Require_Keybind_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Require_Keybind_checkbox.setChecked(Require_Keybind)
        self.Use_Hue_checkbox = QCheckBox("Rainbow Visuals")
        self.Use_Hue_checkbox.setDisabled(False)
        self.Use_Hue_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Use_Hue_checkbox.setChecked(Use_Hue)
        # self.Streamproof_checkbox = QCheckBox("Streamproof")
        # self.Streamproof_checkbox.setDisabled(False)
        # self.Streamproof_checkbox.setFocusPolicy(Qt.NoFocus)
        # self.Streamproof_checkbox.setChecked(Streamproof)

        self.Auto_Fire_Fov_Size_label = QLabel(
            f"FOV Size: {str(Auto_Fire_Fov_Size)}")
        self.slider5 = QSlider(Qt.Horizontal)
        self.slider5.setStyleSheet(self.get_slider_style())
        self.slider5.setMaximumWidth(160)
        self.slider5.setMinimumWidth(160)
        self.slider5.setFocusPolicy(Qt.NoFocus)
        self.slider5.setMinimum(4)
        self.slider5.setMaximum(30)
        self.slider5.setValue(int(round(Auto_Fire_Fov_Size)))

        self.box_type_label = QLabel("Box Type")
        self.box_type_combobox = QComboBox()
        self.box_type_combobox.setMinimumHeight(10)
        self.box_type_combobox.setMaximumHeight(10)
        self.box_type_combobox.setMinimumWidth(160)
        self.box_type_combobox.setMaximumHeight(160)
        self.box_type_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.box_type_combobox.addItems(["Regular", "Corner", "Filled"])
        self.Box_type = self.box_type_combobox.currentText()
        if Box_type == "Regular":
            self.box_type_combobox.setCurrentText("Regular") 
        if Box_type == "Corner":
            self.box_type_combobox.setCurrentText("Corner") 
        if Box_type == "Filled":
            self.box_type_combobox.setCurrentText("Filled") 
        self.Auto_Fire_Confidence_label = QLabel(
            f"Confidence: {str(Auto_Fire_Confidence)}%")
        self.slider6 = QSlider(Qt.Horizontal)
        self.slider6.setStyleSheet(self.get_slider_style())
        self.slider6.setMaximumWidth(160)
        self.slider6.setMinimumWidth(160)
        self.slider6.setFocusPolicy(Qt.NoFocus)
        self.slider6.setMinimum(60)
        self.slider6.setMaximum(100)
        self.slider6.setValue(int(round(Auto_Fire_Confidence)))

        self.btn_extraini = QPushButton("Refresh")
        self.btn_extraini.setCursor(Qt.PointingHandCursor)
        self.btn_extraini.setFocusPolicy(Qt.NoFocus)
        self.btn_extraini.setStyleSheet(main_button_style)
        self.btn_extraini.setMinimumWidth(120)
        self.btn_extraini.clicked.connect(self.refresh_extra)

        self.btn_extraini2 = QPushButton("Refresh")
        self.btn_extraini2.setCursor(Qt.PointingHandCursor)
        self.btn_extraini2.setFocusPolicy(Qt.NoFocus)
        self.btn_extraini2.setStyleSheet(main_button_style)
        self.btn_extraini2.setMinimumWidth(80)
        self.btn_extraini2.clicked.connect(self.refresh_extra)

        self.tempspoof_button = QPushButton("Temp Spoof")
        self.tempspoof_button.setCursor(Qt.PointingHandCursor)
        self.tempspoof_button.setFocusPolicy(Qt.NoFocus)
        self.tempspoof_button.setStyleSheet(main_button_style)
        self.tempspoof_button.setMinimumWidth(80)
        self.tempspoof_button.setMinimumHeight(25)
        self.tempspoof_button.clicked.connect(self.temp_spoof)

        self.hotkey_label = QLabel(f"Keybinds: ")
        self.hotkey_label2 = QLabel("")
        #key_name_converted = KEY_NAMES.get(Keybind, f"0x{Keybind:02X}") # old
        key_name_converted = KEY_NAMES.get(Keybind, f"0x{Keybind:02X}" if Keybind is not None else "Unknown")
        key_name_converted2 = KEY_NAMES.get(Keybind2, f"0x{Keybind2:02X}")
        key_name_converted3 = KEY_NAMES.get(Auto_Fire_Keybind, f"0x{Auto_Fire_Keybind:02X}")
        key_name_converted4 = KEY_NAMES.get(Flickbot_Keybind, f"0x{Flickbot_Keybind:02X}")
        is_selecting_hotkey = False
        self.btn_hotkey = QPushButton(f"{key_name_converted}")
        self.btn_hotkey.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey.setStyleSheet(main_button_style)
        self.btn_hotkey.setMinimumWidth(80)
        self.btn_hotkey.clicked.connect(self.start_select_hotkey)

        is_selecting_hotkey2 = False
        self.btn_hotkey2 = QPushButton(f"{key_name_converted2}")
        self.btn_hotkey2.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey2.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey2.setStyleSheet(main_button_style)
        self.btn_hotkey2.setMinimumWidth(80)
        self.btn_hotkey2.clicked.connect(self.start_select_hotkey2)

        self.hotkey_label3 = QLabel("Triggerbot Key")
        is_selecting_hotkey3 = False
        self.btn_hotkey3 = QPushButton(f"{key_name_converted3}")
        self.btn_hotkey3.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey3.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey3.setStyleSheet(main_button_style)
        self.btn_hotkey3.setMinimumWidth(80)
        self.btn_hotkey3.clicked.connect(self.start_select_hotkey3)

        self.hotkey_label4 = QLabel("Keybind: ")
        is_selecting_hotkey4 = False
        self.btn_hotkey4 = QPushButton(f"{key_name_converted4}")
        self.btn_hotkey4.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey4.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey4.setStyleSheet(main_button_style)
        self.btn_hotkey4.setMinimumWidth(80)
        self.btn_hotkey4.clicked.connect(self.start_select_hotkey4)

        # Slots Start
        self.Enable_Aim_Slot1_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot1_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot1_checkbox.setChecked(Enable_Aim_Slot1)

        self.Enable_Aim_Slot2_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot2_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot2_checkbox.setChecked(Enable_Aim_Slot2)

        self.Enable_Aim_Slot3_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot3_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot3_checkbox.setChecked(Enable_Aim_Slot3)

        self.Enable_Aim_Slot4_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot4_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot4_checkbox.setChecked(Enable_Aim_Slot4)

        self.Enable_Aim_Slot5_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot5_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot5_checkbox.setChecked(Enable_Aim_Slot5)

        self.Fov_Size_label_slot1 = QLabel(f"FOV: {str(Fov_Size_Slot1)}")
        self.slider_slot1 = QSlider(Qt.Horizontal)
        self.slider_slot1.setStyleSheet(self.get_slider_style())
        self.slider_slot1.setMaximumWidth(120)
        self.slider_slot1.setMinimumWidth(120)
        self.slider_slot1.setFocusPolicy(Qt.NoFocus)
        self.slider_slot1.setMinimum(120)
        self.slider_slot1.setMaximum(800)
        self.slider_slot1.setValue(int(round(Fov_Size_Slot1)))

        self.Fov_Size_label_slot2 = QLabel(f"FOV: {str(Fov_Size_Slot2)}")
        self.slider_slot2 = QSlider(Qt.Horizontal)
        self.slider_slot2.setStyleSheet(self.get_slider_style())
        self.slider_slot2.setMaximumWidth(120)
        self.slider_slot2.setMinimumWidth(120)
        self.slider_slot2.setFocusPolicy(Qt.NoFocus)
        self.slider_slot2.setMinimum(120)
        self.slider_slot2.setMaximum(800)
        self.slider_slot2.setValue(int(round(Fov_Size_Slot2)))

        self.Fov_Size_label_slot3 = QLabel(f"FOV: {str(Fov_Size_Slot3)}")
        self.slider_slot3 = QSlider(Qt.Horizontal)
        self.slider_slot3.setStyleSheet(self.get_slider_style())
        self.slider_slot3.setMaximumWidth(120)
        self.slider_slot3.setMinimumWidth(120)
        self.slider_slot3.setFocusPolicy(Qt.NoFocus)
        self.slider_slot3.setMinimum(120)
        self.slider_slot3.setMaximum(800)
        self.slider_slot3.setValue(int(round(Fov_Size_Slot3)))

        self.Fov_Size_label_slot4 = QLabel(f"FOV: {str(Fov_Size_Slot4)}")
        self.slider_slot4 = QSlider(Qt.Horizontal)
        self.slider_slot4.setStyleSheet(self.get_slider_style())
        self.slider_slot4.setMaximumWidth(120)
        self.slider_slot4.setMinimumWidth(120)
        self.slider_slot4.setFocusPolicy(Qt.NoFocus)
        self.slider_slot4.setMinimum(120)
        self.slider_slot4.setMaximum(800)
        self.slider_slot4.setValue(int(round(Fov_Size_Slot4)))

        self.Fov_Size_label_slot5 = QLabel(f"FOV: {str(Fov_Size_Slot5)}")
        self.slider_slot5 = QSlider(Qt.Horizontal)
        self.slider_slot5.setStyleSheet(self.get_slider_style())
        self.slider_slot5.setMaximumWidth(120)
        self.slider_slot5.setMinimumWidth(120)
        self.slider_slot5.setFocusPolicy(Qt.NoFocus)
        self.slider_slot5.setMinimum(120)
        self.slider_slot5.setMaximum(800)
        self.slider_slot5.setValue(int(round(Fov_Size_Slot5)))

        key_name_converted_slot1 = KEY_NAMES.get(Slot1_Keybind, f"0x{Slot1_Keybind:02X}")
        self.hotkey_label_slot1 = QLabel("Slot 1")
        is_selecting_hotkey_slot1 = False
        self.btn_hotkey_slot1 = QPushButton(f"{key_name_converted_slot1}")
        self.btn_hotkey_slot1.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot1.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot1.setStyleSheet(main_button_style)
        self.btn_hotkey_slot1.setMinimumWidth(40)
        self.btn_hotkey_slot1.clicked.connect(self.start_select_hotkey_slot1)

        key_name_converted_slot2 = KEY_NAMES.get(Slot2_Keybind, f"0x{Slot2_Keybind:02X}")
        self.hotkey_label_slot2 = QLabel("Slot 2")
        is_selecting_hotkey_slot2 = False
        self.btn_hotkey_slot2 = QPushButton(f"{key_name_converted_slot2}")
        self.btn_hotkey_slot2.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot2.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot2.setStyleSheet(main_button_style)
        self.btn_hotkey_slot2.setMinimumWidth(40)
        self.btn_hotkey_slot2.clicked.connect(self.start_select_hotkey_slot2)

        key_name_converted_slot3 = KEY_NAMES.get(Slot3_Keybind, f"0x{Slot3_Keybind:02X}")
        self.hotkey_label_slot3 = QLabel("Slot 3")
        is_selecting_hotkey_slot3 = False
        self.btn_hotkey_slot3 = QPushButton(f"{key_name_converted_slot3}")
        self.btn_hotkey_slot3.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot3.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot3.setStyleSheet(main_button_style)
        self.btn_hotkey_slot3.setMinimumWidth(40)
        self.btn_hotkey_slot3.clicked.connect(self.start_select_hotkey_slot3)

        key_name_converted_slot4 = KEY_NAMES.get(Slot4_Keybind, f"0x{Slot4_Keybind:02X}")
        self.hotkey_label_slot4 = QLabel("Slot 4")
        is_selecting_hotkey_slot4 = False
        self.btn_hotkey_slot4 = QPushButton(f"{key_name_converted_slot4}")
        self.btn_hotkey_slot4.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot4.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot4.setStyleSheet(main_button_style)
        self.btn_hotkey_slot4.setMinimumWidth(40)
        self.btn_hotkey_slot4.clicked.connect(self.start_select_hotkey_slot4)

        key_name_converted_slot5 = KEY_NAMES.get(Slot5_Keybind, f"0x{Slot5_Keybind:02X}")
        self.hotkey_label_slot5 = QLabel("Slot 5")
        is_selecting_hotkey_slot5 = False
        self.btn_hotkey_slot5 = QPushButton(f"{key_name_converted_slot5}")
        self.btn_hotkey_slot5.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot5.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot5.setStyleSheet(main_button_style)
        self.btn_hotkey_slot5.setMinimumWidth(40)
        self.btn_hotkey_slot5.clicked.connect(self.start_select_hotkey_slot5)

        key_name_converted_slot6 = KEY_NAMES.get(Slot6_Keybind, f"0x{Slot6_Keybind:02X}")
        self.hotkey_label_slot6 = QLabel("Pickaxe  ")
        is_selecting_hotkey_slot6 = False
        self.btn_hotkey_slot6 = QPushButton(f"{key_name_converted_slot6}")
        self.btn_hotkey_slot6.setCursor(Qt.PointingHandCursor)
        self.btn_hotkey_slot6.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot6.setStyleSheet(main_button_style)
        self.btn_hotkey_slot6.setMinimumWidth(40)
        self.btn_hotkey_slot6.clicked.connect(self.start_select_hotkey_slot6)

        button_container = QWidget()
        button_container_layout = QHBoxLayout(button_container)

        btn_aimbot = QPushButton()
        btn_aimbot.setObjectName("menu_tab_aimbot")
        btn_aimbot.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\skull.png"))
        btn_aimbot.setIconSize(QSize(19, 19))
        btn_aimbot.setFocusPolicy(Qt.NoFocus)
        btn_aimbot.setStyleSheet(self.menu_tab_selected_style())

        btn_slots = QPushButton()
        btn_slots.setObjectName("menu_tab_slots")
        btn_slots.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gun.png"))
        btn_slots.setIconSize(QSize(21, 21))
        btn_slots.setFocusPolicy(Qt.NoFocus)
        btn_slots.setStyleSheet(menu_tab_style)

        btn_flickbot = QPushButton()
        btn_flickbot.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\bullet.png"))
        btn_flickbot.setIconSize(QSize(19, 19))
        btn_flickbot.setObjectName("menu_tab_flickbot")
        btn_flickbot.setFocusPolicy(Qt.NoFocus)
        btn_flickbot.setStyleSheet(menu_tab_style)

        btn_visual = QPushButton()
        btn_visual.setObjectName("menu_tab_visual")
        btn_visual.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\view.png"))
        btn_visual.setIconSize(QSize(20, 20))
        btn_visual.setFocusPolicy(Qt.NoFocus)
        btn_visual.setStyleSheet(menu_tab_style)

        btn_extra = QPushButton()
        btn_extra.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\application.png"))
        btn_extra.setIconSize(QSize(19, 19))
        btn_extra.setObjectName("menu_tab_extra")
        btn_extra.setFocusPolicy(Qt.NoFocus)
        btn_extra.setStyleSheet(menu_tab_style)

        btn_profile = QPushButton()
        btn_profile.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\profile.png"))
        btn_profile.setIconSize(QSize(19, 19))
        btn_profile.setObjectName("menu_tab_profile")
        btn_profile.setFocusPolicy(Qt.NoFocus)
        btn_profile.setStyleSheet(menu_tab_style)

        btn_advanced = QPushButton()
        btn_advanced.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\brain.png"))
        btn_advanced.setIconSize(QSize(19, 19))
        btn_advanced.setObjectName("menu_tab_advanced")
        btn_advanced.setFocusPolicy(Qt.NoFocus)
        btn_advanced.setStyleSheet(menu_tab_style)

        btn_config = QPushButton()
        btn_config.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gear.png"))
        btn_config.setIconSize(QSize(20, 20))
        btn_config.setObjectName("menu_tab_advanced")
        btn_config.setFocusPolicy(Qt.NoFocus)
        btn_config.setStyleSheet(menu_tab_style)

        button_container_layout.addWidget(btn_aimbot)
        button_container_layout.addWidget(btn_slots)
        button_container_layout.addWidget(btn_flickbot)
        button_container_layout.addWidget(btn_visual)
        button_container_layout.addWidget(btn_extra)
        button_container_layout.addWidget(btn_profile)
        button_container_layout.addWidget(btn_advanced)
        button_container_layout.addWidget(btn_config)
        button_container_layout.setContentsMargins(0, 0, 0, 2)
        self.update_menu_tab_style()

        separator_line = QFrame()
        separator_line.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line.setFrameShape(QFrame.HLine)
        separator_line.setFrameShadow(QFrame.Sunken)

        separator_line1 = QFrame()
        separator_line1.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line1.setFrameShape(QFrame.HLine)
        separator_line1.setFrameShadow(QFrame.Sunken)

        separator_line2 = QFrame()
        separator_line2.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line2.setFrameShape(QFrame.HLine)
        separator_line2.setFrameShadow(QFrame.Sunken)

        separator_line3 = QFrame()
        separator_line3.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line3.setFrameShape(QFrame.HLine)
        separator_line3.setFrameShadow(QFrame.Sunken)

        separator_line4 = QFrame()
        separator_line4.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line4.setFrameShape(QFrame.HLine)
        separator_line4.setFrameShadow(QFrame.Sunken)

        separator_line5 = QFrame()
        separator_line5.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line5.setFrameShape(QFrame.HLine)
        separator_line5.setFrameShadow(QFrame.Sunken)

        separator_line6 = QFrame()
        separator_line6.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line6.setFrameShape(QFrame.HLine)
        separator_line6.setFrameShadow(QFrame.Sunken)

        separator_line7 = QFrame()
        separator_line7.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line7.setFrameShape(QFrame.HLine)
        separator_line7.setFrameShadow(QFrame.Sunken)

        separator_line8 = QFrame()
        separator_line8.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line8.setFrameShape(QFrame.HLine)
        separator_line8.setFrameShadow(QFrame.Sunken)

        separator_line9 = QFrame()
        separator_line9.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line9.setFrameShape(QFrame.HLine)
        separator_line9.setFrameShadow(QFrame.Sunken)

        separator_line10 = QFrame()
        separator_line10.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line10.setFrameShape(QFrame.HLine)
        separator_line10.setFrameShadow(QFrame.Sunken)

        separator_line11 = QFrame()
        separator_line11.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line11.setFrameShape(QFrame.HLine)
        separator_line11.setFrameShadow(QFrame.Sunken)

        separator_line12 = QFrame()
        separator_line12.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line12.setFrameShape(QFrame.HLine)
        separator_line12.setFrameShadow(QFrame.Sunken)

        separator_line13 = QFrame()
        separator_line13.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line13.setFrameShape(QFrame.HLine)
        separator_line13.setFrameShadow(QFrame.Sunken)

        separator_line14 = QFrame()
        separator_line14.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line14.setFrameShape(QFrame.HLine)
        separator_line14.setFrameShadow(QFrame.Sunken)

        # Create the banner layout
        banner_layout = QVBoxLayout()
        banner_layout.addSpacing(2)  # Adds 20 pixels of space
        self.bannerdd = QLabel(self)
        selected_image = random.choice(image_files)
        image_data = base64.b64decode(selected_image)
        image = QImage()
        image.loadFromData(image_data)
        pixmapdd = QPixmap.fromImage(image)
        self.bannerdd.setPixmap(pixmapdd)
        self.bannerdd.setAlignment(Qt.AlignCenter)
        banner_layout.addWidget(self.bannerdd)
        banner_layout.addSpacing(-5)  # Adds 20 pixels of space


        # // AIMBOT TAB
        aimbot_layout = QVBoxLayout()
        aimbot_layout.addWidget(self.Enable_Aim_checkbox)
        aimbot_layout.addWidget(self.Controller_On_checkbox)
        button_container_layout05 = QHBoxLayout()
        button_container_layout05.addWidget(self.hotkey_label)
        button_container_layout05.addWidget(self.btn_hotkey)
        button_container_layout05.addWidget(self.hotkey_label2)
        button_container_layout05.setAlignment(Qt.AlignLeft)
        button_container_layout05.addWidget(self.btn_hotkey2)
        aimbot_layout.addLayout(button_container_layout05)
        aimbot_layout.addSpacing(5)
        aimbot_layout.addWidget(separator_line1)
        aimbot_layout.addSpacing(5)
        button_container_layout00 = QHBoxLayout()
        button_container_layout00.addWidget(self.slider)
        button_container_layout00.addWidget(self.Fov_Size_label)
        aimbot_layout.addLayout(button_container_layout00)
        button_container_layout01 = QHBoxLayout()
        button_container_layout01.addWidget(self.slider0)
        button_container_layout01.addWidget(self.Confidence_label)
        aimbot_layout.addLayout(button_container_layout01)
        button_container_layout03 = QHBoxLayout()
        button_container_layout03.addWidget(self.slider3)
        button_container_layout03.addWidget(self.Aim_Smooth_label)
        aimbot_layout.addLayout(button_container_layout03)
        aimbot_layout.addSpacing(2)
        button_container_layout04 = QHBoxLayout()
        button_container_layout04.addWidget(self.aim_bone_combobox)
        button_container_layout04.addWidget(self.aim_bone_label)
        aimbot_layout.addLayout(button_container_layout04)
        button_container_layout53 = QHBoxLayout()
        button_container_layout53.addWidget(self.smoothing_type_combobox)
        button_container_layout53.addWidget(self.smoothing_type_label)
        aimbot_layout.addLayout(button_container_layout53)
        aimbot_layout.addSpacing(3)
        aimbot_layout.addWidget(self.btn_extraini2)
        aimbot_layout.addSpacing(5)
        aimbot_layout.addWidget(separator_line2)
        aimbot_layout.addWidget(self.Welcome_label_1)

        # // GUN SLOTS TAB
        slots_layout = QVBoxLayout()
        slots_layout.addWidget(self.Enable_Slots_checkbox)
        # Slot 1
        button_container_layout_slot1 = QHBoxLayout()
        button_container_layout_slot1.addWidget(self.hotkey_label_slot1)
        button_container_layout_slot1.addWidget(self.btn_hotkey_slot1)
        button_container_layout_slot1.addWidget(self.slider_slot1)
        button_container_layout_slot1.addWidget(self.Fov_Size_label_slot1)
        button_container_layout_slot1.addWidget(self.Enable_Aim_Slot1_checkbox)
        button_container_layout_slot1.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot1)
        # Slot 2
        button_container_layout_slot2 = QHBoxLayout()
        button_container_layout_slot2.addWidget(self.hotkey_label_slot2)
        button_container_layout_slot2.addWidget(self.btn_hotkey_slot2)
        button_container_layout_slot2.addWidget(self.slider_slot2)
        button_container_layout_slot2.addWidget(self.Fov_Size_label_slot2)
        button_container_layout_slot2.addWidget(self.Enable_Aim_Slot2_checkbox)
        button_container_layout_slot2.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot2)
        # Slot 3
        button_container_layout_slot3 = QHBoxLayout()
        button_container_layout_slot3.addWidget(self.hotkey_label_slot3)
        button_container_layout_slot3.addWidget(self.btn_hotkey_slot3)
        button_container_layout_slot3.addWidget(self.slider_slot3)
        button_container_layout_slot3.addWidget(self.Fov_Size_label_slot3)
        button_container_layout_slot3.addWidget(self.Enable_Aim_Slot3_checkbox)
        button_container_layout_slot3.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot3)
        # Slot 4
        button_container_layout_slot4 = QHBoxLayout()
        button_container_layout_slot4.addWidget(self.hotkey_label_slot4)
        button_container_layout_slot4.addWidget(self.btn_hotkey_slot4)
        button_container_layout_slot4.addWidget(self.slider_slot4)
        button_container_layout_slot4.addWidget(self.Fov_Size_label_slot4)
        button_container_layout_slot4.addWidget(self.Enable_Aim_Slot4_checkbox)
        button_container_layout_slot4.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot4)
        # Slot 5
        button_container_layout_slot5 = QHBoxLayout()
        button_container_layout_slot5.addWidget(self.hotkey_label_slot5)
        button_container_layout_slot5.addWidget(self.btn_hotkey_slot5)
        button_container_layout_slot5.addWidget(self.slider_slot5)
        button_container_layout_slot5.addWidget(self.Fov_Size_label_slot5)
        button_container_layout_slot5.addWidget(self.Enable_Aim_Slot5_checkbox)
        button_container_layout_slot5.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot5)
        # Slot 6
        button_container_layout_slot6 = QHBoxLayout()
        button_container_layout_slot6.addWidget(self.hotkey_label_slot6)
        button_container_layout_slot6.addWidget(self.btn_hotkey_slot6)
        button_container_layout_slot6.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot6)

        slots_layout.addSpacing(5)
        slots_layout.addWidget(separator_line14)
        slots_layout.addWidget(self.Welcome_label_7)

        # // SILENTAIM TAB
        flickbot_layout = QVBoxLayout()
        flickbot_layout.addWidget(self.Enable_Flick_checkbox)
        button_container_layout_flick_key = QHBoxLayout()
        button_container_layout_flick_key.addWidget(self.hotkey_label4)
        button_container_layout_flick_key.setAlignment(Qt.AlignLeft)
        button_container_layout_flick_key.addWidget(self.btn_hotkey4)
        flickbot_layout.addLayout(button_container_layout_flick_key)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(separator_line11)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(self.flick_set_info_label)

        button_container_layout_flick_scope = QHBoxLayout()
        button_container_layout_flick_scope.addWidget(self.flick_scope_slider)
        button_container_layout_flick_scope.addWidget(self.flick_scope_label)
        flickbot_layout.addLayout(button_container_layout_flick_scope)

        button_container_layout_flick_cool = QHBoxLayout()
        button_container_layout_flick_cool.addWidget(self.flick_cool_slider)
        button_container_layout_flick_cool.addWidget(self.flick_cool_label)
        flickbot_layout.addLayout(button_container_layout_flick_cool)
        button_container_layout_flick_delay = QHBoxLayout()
        button_container_layout_flick_delay.addWidget(self.flick_delay_slider)
        button_container_layout_flick_delay.addWidget(self.flick_delay_label)
        flickbot_layout.addLayout(button_container_layout_flick_delay)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(separator_line12)
        flickbot_layout.addWidget(self.Welcome_label_2)

        # // VISUAL TAB
        visual_layout = QVBoxLayout()
        button_container_layout055 = QHBoxLayout()
        # button_container_layout055.addWidget(self.hue_slider)
        # button_container_layout055.addWidget(self.rgb_label)
        visual_layout.addLayout(button_container_layout055)

        button_container_layout06 = QHBoxLayout()
        # button_container_layout06.addWidget(self.lightness_slider)
        # button_container_layout06.addWidget(self.lightness_label)
        visual_layout.addLayout(button_container_layout06)

        button_container_layout07 = QHBoxLayout()
        # button_container_layout07.addWidget(self.opacity_slider)
        # button_container_layout07.addWidget(self.opacity_label)
        visual_layout.addLayout(button_container_layout07)

        # visual_layout.addSpacing(5)
        # visual_layout.addWidget(separator_line3)
        visual_layout.addSpacing(5)
        #visual_layout.addWidget(self.Streamproof_checkbox)
        visual_layout.addWidget(self.Use_Hue_checkbox)
        visual_layout.addWidget(self.Show_Fov_checkbox)
        visual_layout.addWidget(self.Show_Crosshair_checkbox)
        visual_layout.addWidget(self.Show_Detections_checkbox)
        visual_layout.addWidget(self.Show_Aimline_checkbox)
        visual_layout.addWidget(self.Show_FPS_checkbox)
        visual_layout.addWidget(self.Show_Debug_checkbox)
        visual_layout.addWidget(self.Show_CMD_checkbox)

        button_container_layout12 = QHBoxLayout()
        button_container_layout12.addWidget(self.box_type_combobox)
        button_container_layout12.addWidget(self.box_type_label)
        visual_layout.addLayout(button_container_layout12)

        visual_layout.addSpacing(5)
        visual_layout.addWidget(separator_line4)

        # # Add a "Preview" button
        # self.preview_button = QPushButton("Preview")
        # self.preview_button.setStyleSheet(main_button_style)
        # visual_layout.addWidget(self.preview_button)
        # visual_layout.addWidget(separator_line4)

        # Connect the button click to a function to open the new window
        #self.preview_button.clicked.connect(self.show_preview_window)
        visual_layout.addWidget(self.Welcome_label_3)

        # // EXTRA TAB
        extra_layout = QVBoxLayout()
        extra_layout.addWidget(self.CupMode_On_checkbox)
        extra_layout.addWidget(self.Enable_TriggerBot_checkbox)
        extra_layout.addWidget(self.Require_Keybind_checkbox)
        button_container_layout08 = QHBoxLayout()
        button_container_layout08.addWidget(self.hotkey_label3)
        button_container_layout08.setAlignment(Qt.AlignLeft)
        button_container_layout08.addWidget(self.btn_hotkey3)
        extra_layout.addLayout(button_container_layout08)
        button_container_layout09 = QHBoxLayout()
        button_container_layout09.addWidget(self.slider5)
        button_container_layout09.addWidget(self.Auto_Fire_Fov_Size_label)
        extra_layout.addLayout(button_container_layout09)
        button_container_layout10 = QHBoxLayout()
        button_container_layout10.addWidget(self.slider6)
        button_container_layout10.addWidget(self.Auto_Fire_Confidence_label)
        extra_layout.addLayout(button_container_layout10)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(separator_line5)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(self.Reduce_Bloom_checkbox)
        extra_layout.addWidget(self.AntiRecoil_On_checkbox)
        extra_layout.addWidget(self.Require_ADS_checkbox) 
        button_container_layout11 = QHBoxLayout()
        button_container_layout11.addWidget(self.slider60)
        button_container_layout11.addWidget(self.AntiRecoil_Strength_label)
        extra_layout.addLayout(button_container_layout11)
        # extra_layout.addSpacing(3)
        # extra_layout.addWidget(self.tempspoof_button)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(separator_line6)
        extra_layout.addWidget(self.Welcome_label_4)

        # // ADVANCED TAB
        advanced_layout = QVBoxLayout()
        advanced_layout.addSpacing(3)
        advanced_layout.addWidget(self.Use_Model_Class_checkbox)
        advanced_layout.addSpacing(3)
        # Image Scaling
        button_container_layout_class = QHBoxLayout()
        button_container_layout_class.addWidget(self.img_value_combobox)
        button_container_layout_class.addWidget(self.img_value_label)
        advanced_layout.addLayout(button_container_layout_class)
        advanced_layout.addSpacing(3)
        # Model Selector
        button_container_layout_model = QHBoxLayout()
        button_container_layout_model.addWidget(self.model_selected_combobox)
        button_container_layout_model.addWidget(self.model_selected_label)
        advanced_layout.addLayout(button_container_layout_model)
        advanced_layout.addSpacing(3)
        # Max Detections
        button_container_layout_maxdet = QHBoxLayout()
        button_container_layout_maxdet.addWidget(self.slider4)
        button_container_layout_maxdet.addWidget(self.Max_Detections_label)
        advanced_layout.addLayout(button_container_layout_maxdet)
        # Model FPS
        button_container_layout_fps = QHBoxLayout()
        button_container_layout_fps.addWidget(self.slider_fps)
        button_container_layout_fps.addWidget(self.fps_label)
        advanced_layout.addLayout(button_container_layout_fps)
        advanced_layout.addSpacing(5)
        advanced_layout.addWidget(separator_line13)
        advanced_layout.addWidget(self.Welcome_label_6)


        # // CONFIG TAB
        config_layout = QVBoxLayout()


        # // Profile
        profile_layout = QVBoxLayout()
        profile_layout.addWidget(self.info_label_3)
        profile_layout.addWidget(self.info_label_4)
        profile_layout.addWidget(self.info_label_5)
        profile_layout.addWidget(self.info_label_6)
        profile_layout.addWidget(self.info_label_7)
        profile_layout.addSpacing(3)
        profile_layout.addWidget(separator_line7)
        profile_layout.addSpacing(3)
        profile_layout.addWidget(self.info_label_8)
        #profile_layout.addWidget(self.info_label_9)
        profile_layout.addWidget(self.info_label_10)
        profile_layout.addWidget(self.info_label_11)
        profile_layout.addWidget(self.info_label_13)

        profile_layout.addSpacing(3)

        profile_layout.addWidget(self.btn_extraini)

        profile_layout.addSpacing(5)
        profile_layout.addWidget(separator_line9)
        profile_layout.addWidget(self.Welcome_label_5)


        aimbot_layout.setAlignment(Qt.AlignTop)
        slots_layout.setAlignment(Qt.AlignTop)
        flickbot_layout.setAlignment(Qt.AlignTop)
        visual_layout.setAlignment(Qt.AlignTop)
        extra_layout.setAlignment(Qt.AlignTop)
        advanced_layout.setAlignment(Qt.AlignTop)
        config_layout.setAlignment(Qt.AlignTop)
        profile_layout.setAlignment(Qt.AlignTop)

        stacked_widget = QStackedWidget()

        # Add stacked widget content
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())

        stacked_widget.widget(0).setLayout(aimbot_layout)
        stacked_widget.widget(1).setLayout(slots_layout)
        stacked_widget.widget(2).setLayout(flickbot_layout)
        stacked_widget.widget(3).setLayout(visual_layout)
        stacked_widget.widget(4).setLayout(extra_layout)
        stacked_widget.widget(5).setLayout(advanced_layout)
        stacked_widget.widget(6).setLayout(config_layout)
        stacked_widget.widget(7).setLayout(profile_layout)

        """stacked_widget.widget(0).setLayout(aimbot_layout)
        stacked_widget.widget(1).setLayout(slots_layout)
        stacked_widget.widget(2).setLayout(flickbot_layout)
        stacked_widget.widget(3).setLayout(visual_layout)
        stacked_widget.widget(4).setLayout(extra_layout)
        stacked_widget.widget(5).setLayout(profile_layout)
        stacked_widget.widget(6).setLayout(advanced_layout)"""

        # Main Layout
        layout = QVBoxLayout()
        layout.addLayout(banner_layout)
        layout.addWidget(button_container)
        layout.addWidget(separator_line)
        layout.addWidget(stacked_widget)

        # Create the text QLabel for the bottom right
        self.bottom_right_text = QLabel(discord_link_racc)
        self.bottom_right_text.setAlignment(Qt.AlignRight | Qt.AlignBottom)  # Align to bottom right

        # Set the color and font size for the bottom right label
        self.bottom_right_text.setStyleSheet("color: #ffffff;")  # Set desired hex color

        # Create and customize the font
        font = QFont()
        font.setFamily("Impact")  # Set the desired font family
        font.setPointSize(6)     # Set the font size to 14 (adjust as needed)
        font.setBold(False)        # Optional: make the text bold
        font.setItalic(False)     # Optional: make the text italic if needed
        self.bottom_right_text.setFont(font)

        # Create a horizontal layout to hold the label
        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()  # Adds stretchable space before the label
        bottom_layout.addWidget(self.bottom_right_text)  # Add the label to this layout

        # Adding bottom layout to the main layout
        layout.addLayout(bottom_layout)  # Add the bottom layout to the main layout

        self.setLayout(layout)


        def set_button_style(selected_button):
            btn_aimbot.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Aimbot" else menu_tab_style)
            btn_aimbot.setIcon(QIcon(f"C:\\ProgramData\\Nizzware AI\\Assets\\Images\\skull-highlighted.png") if selected_button == "Aimbot" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\skull.png"))

            btn_slots.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Slots" else menu_tab_style)
            btn_slots.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gun-highlighted.png") if selected_button == "Slots" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gun.png"))

            btn_flickbot.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Flickbot" else menu_tab_style)
            btn_flickbot.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\bullet-highlighted.png") if selected_button == "Flickbot" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\bullet.png"))

            btn_visual.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Visual" else menu_tab_style)
            btn_visual.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\view-highlighted.png") if selected_button == "Visual" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\view.png"))

            btn_extra.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Extra" else menu_tab_style)
            btn_extra.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\application-highlighted.png") if selected_button == "Extra" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\application.png"))

            btn_profile.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Profile" else menu_tab_style)
            btn_profile.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\profile-highlighted.png") if selected_button == "Profile" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\profile.png"))

            btn_advanced.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Model" else menu_tab_style)
            btn_advanced.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\brain-highlighted.png") if selected_button == "Model" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\brain.png"))

            btn_config.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Config" else menu_tab_style)
            btn_config.setIcon(QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gear-highlighted.png") if selected_button == "Config" else QIcon("C:\\ProgramData\\Nizzware AI\\Assets\\Images\\gear.png"))

        set_button_style("Aimbot")
        btn_aimbot.clicked.connect(lambda: set_button_style("Aimbot"))
        btn_slots.clicked.connect(lambda: set_button_style("Slots"))
        btn_flickbot.clicked.connect(lambda: set_button_style("Flickbot"))
        btn_visual.clicked.connect(lambda: set_button_style("Visual"))
        btn_extra.clicked.connect(lambda: set_button_style("Extra"))
        btn_profile.clicked.connect(lambda: set_button_style("Profile"))
        btn_advanced.clicked.connect(lambda: set_button_style("Model"))
        btn_config.clicked.connect(lambda: set_button_style("Config"))
        btn_aimbot.clicked.connect(lambda: stacked_widget.setCurrentIndex(0))
        btn_slots.clicked.connect(lambda: stacked_widget.setCurrentIndex(1))
        btn_flickbot.clicked.connect(lambda: stacked_widget.setCurrentIndex(2))
        btn_visual.clicked.connect(lambda: stacked_widget.setCurrentIndex(3))
        btn_extra.clicked.connect(lambda: stacked_widget.setCurrentIndex(4))
        btn_advanced.clicked.connect(lambda: stacked_widget.setCurrentIndex(5))
        btn_config.clicked.connect(lambda: stacked_widget.setCurrentIndex(6))
        btn_profile.clicked.connect(lambda: stacked_widget.setCurrentIndex(7))

        self.slider.valueChanged.connect(self.on_slider_value_change)
        self.slider0.valueChanged.connect(self.on_slider0_value_change)
        self.slider3.valueChanged.connect(self.on_slider3_value_change)
        self.slider4.valueChanged.connect(self.on_slider4_value_change)
        self.slider5.valueChanged.connect(self.on_slider5_value_change)
        self.slider6.valueChanged.connect(self.on_slider6_value_change)
        self.slider60.valueChanged.connect(self.on_slider60_value_change)

        # Slots
        self.slider_slot1.valueChanged.connect(self.on_slider_slot1_value_change)
        self.slider_slot2.valueChanged.connect(self.on_slider_slot2_value_change)
        self.slider_slot3.valueChanged.connect(self.on_slider_slot3_value_change)
        self.slider_slot4.valueChanged.connect(self.on_slider_slot4_value_change)
        self.slider_slot5.valueChanged.connect(self.on_slider_slot5_value_change)

        self.Enable_Aim_Slot1_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot2_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot3_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot4_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot5_checkbox.stateChanged.connect(self.on_checkbox_state_change)

        self.flick_scope_slider.valueChanged.connect(self.on_flick_scope_slider_value_change)
        self.flick_cool_slider.valueChanged.connect(self.on_flick_cool_slider_value_change)
        self.flick_delay_slider.valueChanged.connect(self.on_flick_delay_slider_value_change)
        self.aim_bone_combobox.currentIndexChanged.connect(self.update_aim_bone)
        self.smoothing_type_combobox.currentIndexChanged.connect(self.update_smoothing_type)
        self.box_type_combobox.currentIndexChanged.connect(self.update_box_type)
        self.Enable_Aim_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Slots_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Fov_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Crosshair_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Detections_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Aimline_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Require_Keybind_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Debug_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_FPS_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_CMD_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_TriggerBot_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Controller_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.CupMode_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        #self.Streamproof_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Reduce_Bloom_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Require_ADS_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.AntiRecoil_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Flick_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        #self.hue_slider.valueChanged.connect(self.update_rgb_label)
        #self.lightness_slider.valueChanged.connect(self.update_rgb_label)
        #self.opacity_slider.valueChanged.connect(self.update_rgb_label)
        self.Use_Hue_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Use_Model_Class_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.img_value_combobox.currentIndexChanged.connect(self.update_img_value)

        self.model_selected_combobox.currentIndexChanged.connect(self.on_model_selected)

        self.slider_fps.valueChanged.connect(self.on_slider_fps_value_change)

        try:
            self.font_size = open("C:\\ProgramData\\Nizzware\\Assets\\size.txt", "r").read()
        except:
            self.font_size = 15

        self.update_stylesheet()

    def load_modelss(self):
        try:
            model_files = [f for f in os.listdir('model') if f.endswith(('.engine', '.pt', '.onnx'))]
        except:
            model_files = [f for f in os.listdir(open(rf"{current_directory}\model","r").read()) if f.endswith(('.engine', '.pt', '.onnx'))]

        # Load default models from specified directory
        default_model_dir = 'C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\'
        default_model_files = [f for f in os.listdir(default_model_dir) if f.endswith(('.engine', '.pt'))]

        # Map user-friendly labels to actual file names
        default_models = {}
        for file in default_model_files:
            if 'FortnitePro' in file:
                label = "FortnitePro" + os.path.splitext(file)[1]
                default_models[label] = file 
            elif 'Fortnite' in file:
                label = "Fortnite" + os.path.splitext(file)[1]
                default_models[label] = file 
            # elif 'FortnitePro' in file:
            # 	label = "FortnitePro" + os.path.splitext(file)[1]
            # 	default_models[label] = file 
            # elif 'WINDOWSEN' in file:
            # 	label = "NiteZero" + os.path.splitext(file)[1]
            # 	default_models[label] = file 
            # elif 'WINDOWSUN' in file:
            # 	label = "UniversalZero" + os.path.splitext(file)[1]
            # 	default_models[label] = file 

        self.modelss = {}

        invalid_models = []
        for model_file in model_files:
            try:
                model_path = os.path.join('model', model_file)
            except:
                model_path = os.path.join(open(rf"{current_directory}\model","r").read(), model_file)
            try:
                model_instance = YOLO(model_path, task='detect')
                self.modelss[model_file] = model_instance
                self.model_selected_combobox.addItem(model_file)
            except Exception as e:
                invalid_models.append(model_file)

        # Process default models
        for label, file_name in default_models.items():
            model_path = os.path.join(default_model_dir, file_name)
            try:
                model_instance = YOLO(model_path, task='detect')
                self.modelss[label] = model_path  # Store the path for later use
                self.model_selected_combobox.addItem(label)
            except Exception as e:
                invalid_models.append(label)

        # Set default model if no models are loaded
        if not model_files and not default_models:
            message = "No model files found in the directory, using default model."
            caption = "Error 0401: Model Finding Error"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)
            if default_models:
                default_model = next(iter(default_models.values()), None)
                if default_model:
                    MyWindow.modell = YOLO(os.path.join(default_model_dir, default_model))
            return

        # Select the last loaded model or fallback to the first available model
        if Last_Model and Last_Model in self.modelss:
            try:
                model_path = self.modelss[Last_Model]
                MyWindow.modell = YOLO(model_path, task='detect')
                self.model_selected_combobox.setCurrentText(Last_Model)
            except Exception as e:
                fallback_model = next(iter(self.modelss.values()), None)
                if fallback_model:
                    MyWindow.modell = fallback_model
                    self.model_selected_combobox.setCurrentIndex(0)
        else:
            fallback_model = next(iter(self.modelss.values()), None)
            if fallback_model:
                MyWindow.modell = fallback_model
                self.model_selected_combobox.setCurrentIndex(0)

        # Report any invalid models
        if invalid_models:
            invalid_models_str = "\n".join(invalid_models)
            message = f"The following models failed to load and are being ignored:\n\n{invalid_models_str}"
            caption = "Error 0407: Model Loading Error"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

    def on_model_selected(self):
        global Last_Model
        model_name = self.model_selected_combobox.currentText()

        default_models = [
            'Fortnite'
        ]

        # Determine if the selected model is from the 'model' directory or default directory
        model_path = None
        if any(default_model in model_name for default_model in default_models):
            # Get the actual file name for the selected default model
            file_name = self.modelss.get(model_name, None)
            if file_name:
                model_path = os.path.join('C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr', file_name)
        else:
            try:
                model_path = os.path.join(os.path.abspath('model'), model_name)
            except:
                model_path = os.path.join(os.path.abspath('../model'), model_name)

        if model_path and os.path.isfile(model_path):
            try:
                MyWindow.modell = YOLO(model_path, task='detect')
                self.modelss[model_name] = model_path
            except Exception as e:
                message = f"Failed to load model {model_name} from {model_path}.\n\nError Details: {e}"
                caption = "Error 0437: Model Loading Failure"
                message_type = 0x10
                ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)
        else:
            message = f"Model {model_name} not found at {model_path}."
            caption = "Error 0444: Model Not Found"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

        Last_Model = model_name
        self.auto_save_config()

    def update_theme_color(self):
        import re

        # Validate hex color code
        hex_color = self.color_input.text()
        if not re.fullmatch(r'#(?:[0-9a-fA-F]{3}){1,2}', hex_color):
            hex_color = '#ff0000'  # Default to red if invalid

        self.theme_hex_color = "#ffffff"#"#008cff"
        self.update_stylesheet()
        self.update_button_style()
        self.update_menu_tab_style()
        self.update_slider_style()
        self.update_label_colors()
        self.update()
        self.auto_save_config()

    def update_button_style(self):
        button_style = main_button_style
        for button in self.findChildren(QPushButton):
            button.setStyleSheet(button_style)
            button.setCursor(Qt.PointingHandCursor)

    def update_menu_tab_style(self):
        menu_tab_style = self.menu_tab_selected_style()
        for button in self.findChildren(QPushButton):
            if "menu_tab" in button.objectName():
                button.setStyleSheet(menu_tab_style)

    def update_slider_style(self):
        slider_style = self.get_slider_style()
        for slider in self.findChildren(QSlider):
            slider.setStyleSheet(slider_style)

    def update_stylesheet(self):
        menu_main_style = f"""
            QWidget {{
                background-color: #000000;
                color: #ffffff;
                font-size: {self.font_size}px;
            }}
            QSlider::groove:horizontal {{
                border: 1px solid {self.widget_border_color};
                height: 10px;
                border-radius: 5px;
            }}
            QSlider::handle:horizontal {{
                background: {self.widget_bg_color};
                width: 10px;
                margin: -1px -1px;
                border-radius: 5px;
                border: 1px solid {self.theme_hex_color};
            }}
            QSlider::handle:horizontal:hover {{
                background: {self.theme_hex_color};
                border-color: {self.widget_border_color};
            }}

            QCheckBox::indicator:checked {{
                background: {self.theme_hex_color};
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/o.png);
            }}
            QCheckBox::indicator:unchecked {{
                background: {self.widget_bg_color};
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/x.png);
            }}
            QCheckBox::indicator {{
                border-radius : 5px;
                width: 20px;
                height: 20px;

            }}
            QCheckBox::indicator:focus {{
                background-color: transparent;
            }}

            QComboBox {{
                background-color: {self.widget_bg_color};
                color: #ffffff;
                font-size: {self.font_size}px;
                border-radius: 5px;
                border: 1px {self.widget_border_color};
                padding: 5px 30px 5px 8px;
            }}
            QComboBox::drop-down {{
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 20px;
                border-left-width: 1px;
                border-left-color: {self.widget_border_color};
                border-left-style: solid;
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
                background-color: {self.theme_hex_color};
            }}
            QComboBox::down-arrow {{
                width: 10px;
                height: 10px;
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/d.png);
            }}
            QComboBox QAbstractItemView {{
                background-color: {self.widget_bg_color};
                color: #ffffff;
                selection-background-color: {self.theme_hex_color};
                selection-color: #ffffff;
                border: 1px solid {self.widget_border_color};
                border-radius: 5px;
                padding: 8px;
                font-size: {self.font_size}px;
            }}
            QLineEdit {{ 
                border: 2px solid {self.theme_hex_color};
            }}
        """

        self.setStyleSheet(menu_main_style)

    def get_slider_style(self):
        # return f"""
        # 	QSlider::groove:horizontal {{
        # 	border: 1px solid {self.widget_bg_color};
        # 	height: 12px;
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::handle:horizontal {{
        # 	background: {self.widget_bg_color};
        # 	width: 12px;
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::handle:horizontal:hover {{
        # 	background: {self.theme_hex_color};
        # 	border-color: {self.widget_border_color};
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::add-page:qlineargradient {{
        # 	background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {self.widget_bg_color}, stop:1 {self.widget_border_color});
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::sub-page:qlineargradient {{
        # 	background: {self.theme_hex_color};
        # 	border-radius: 6px;
        # 	}}
        # """
        return f"""
QLineEdit {{
    border: 1px solid #{theme_color}; /* // THEME COLOR  008cff*/
    background-color: #{bg_theme_hue};
    color: #abb2bf;
    border-radius: 4px;
    font-weight: bold;
}}

QSlider::groove:horizontal {{
    border: 1px solid #02015e;
    height: 8px;
    background: #{bg_theme_hue};
    border-radius: 4px;
}}

QSlider::handle:horizontal {{
    background: #{bg_theme_hue};
    border: 2px solid #{theme_color};
    width: 12px;
    height: 12px;
    margin: -4px 0;
    border-radius: 7px;
}}

QSlider::sub-page:horizontal {{
    background: #{theme_color};
    border-radius: 4px;
}}

"""
    def format_time_difference(self,timestamp):
        timestamp_datetime = datetime.fromtimestamp(int(timestamp))
        now = datetime.now()
        difference = now - timestamp_datetime

        total_seconds = int(difference.total_seconds())
        if total_seconds < -10000:
            total_seconds = abs(total_seconds)

        minutes = 60
        hours = 3600
        days = 86400
        months = 2592000
        years = 31536000
        if total_seconds >= years:
            years_count = total_seconds // years
            return f"{years_count} year{'s' if years_count > 1 else ''}"
        if total_seconds >= months:
            months_count = total_seconds // months
            return f"{months_count} month{'s' if months_count > 1 else ''}"
        elif total_seconds >= days:
            days_count = total_seconds // days
            return f"{days_count} day{'s' if days_count > 1 else ''}"
        elif total_seconds >= hours:
            hours_count = total_seconds // hours
            return f"{hours_count} hour{'s' if hours_count > 1 else ''}"
        elif total_seconds >= minutes:
            minutes_count = total_seconds // minutes
            return f"{minutes_count} minute{'s' if minutes_count > 1 else ''}"
        else:
            seconds_count = total_seconds
            return f"{seconds_count} second{'s' if seconds_count > 1 else ''}"

    def menu_tab_selected_style(self):
        return f"""
            QPushButton {{
                border: none;
                padding-bottom: 6px;
                margin-left: 60%;
                margin-right: 60%;
            }}
        """ #border-bottom: 2px solid {self.theme_hex_color};

    def create_mask(self):
        path = QPainterPath()
        radius = 5
        path.addRoundedRect(QRectF(0, 0, self.width(), self.height()), radius, radius)
        mask = QRegion(path.toFillPolygon().toPolygon())
        return mask
    
    # def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(self.palette().window())
        painter.setPen(Qt.NoPen) 
        painter.drawRoundedRect(self.rect(), 20, 20)
        super().paintEvent(event)
        #painter.drawRoundedRect(rect, 6, 6)

    def update_label_colors(self):
        # Update the color for each label
        self.info_label_3.setText(f"<font color='{self.theme_hex_color}'>User Info:</font>")
        self.info_label_8.setText(f"<font color='{self.theme_hex_color}'>Hotkeys:</font>")
        #self.info_label_9.setText(f"Close Normally: <font color='{self.theme_hex_color}'>[X]</font>")
        self.info_label_10.setText(f"Quick On/Off: <font color='{self.theme_hex_color}'>[F1]</font>")
        self.info_label_11.setText(f"Close: <font color='{self.theme_hex_color}'>[F2]</font>")
        self.info_label_13.setText(f"Toggle Menu: <font color='{self.theme_hex_color}'>[INS]</font>")

    def update_labels(self):
        self.info_label_4.setText(f"Your Key: " + api.user_data.username[:20] + "*******")
        self.info_label_5.setText(f"Purchased: " + self.format_time_difference(api.user_data.createdate) + " ago")
        self.info_label_7.setText(f"Last Login: " + self.format_time_difference(api.user_data.lastlogin) + " ago")
        self.info_label_6.setText(f"Expiry: in " + self.format_time_difference(api.user_data.expires))

    def toggle_menu_visibility(self):
        if self.isVisible():
            try:
                self.hide()
            except:
                time.sleep(0.15)
                self.hide()
        else:
            try:
                self.show()
                self.raise_()
                self.activateWindow()
            except:
                time.sleep(0.15)
                self.show()
                self.raise_()
                self.activateWindow()


    def auto_save_config(self):
        #hue = self.hue_slider.value()
        #opacity = self.opacity_slider.value()
        #lightness = self.lightness_slider.value()
        color = self.calculate_color("008cff", "", "")  # Pass lightness to calculate_color

        men_color = "#008cff"

        if not men_color.startswith('#') or len(men_color) not in [7, 9]:
            men_color = '#008cff'  # Default to white if invalid

        config_settings = {
            "Fov_Size": Fov_Size,
            "Confidence": Confidence,
            "Aim_Smooth": Aim_Smooth,
            "Max_Detections": Max_Detections,
            "Aim_Bone": Aim_Bone,
            "Smoothing_Type": Smoothing_Type,
            "Box_type": Box_type,
            "Enable_Aim": bool(Enable_Aim),
            "Enable_Slots": bool(Enable_Slots),
            "Controller_On": bool(Controller_On),
            "Keybind": self.Keybind,
            "Keybind2": self.Keybind2,
            "Enable_TriggerBot": bool(Enable_TriggerBot),
            "Show_Fov": bool(Show_Fov),
            "Show_Crosshair": bool(Show_Crosshair),
            "Show_Debug": bool(Show_Debug),
            "Show_FPS": bool(Show_FPS),
            "Auto_Fire_Fov_Size": Auto_Fire_Fov_Size,
            "Show_Detections": bool(Show_Detections),
            "Show_Aimline": bool(Show_Aimline),
            "Auto_Fire_Confidence": Auto_Fire_Confidence,
            "Auto_Fire_Keybind": self.Auto_Fire_Keybind,
            "Require_Keybind": bool(Require_Keybind),
            "Use_Hue": bool(Use_Hue),
            "CupMode_On": bool(CupMode_On),
            "Reduce_Bloom": bool(Reduce_Bloom),
            "Require_ADS": bool(Require_ADS),
            "AntiRecoil_On": bool(AntiRecoil_On),
            "AntiRecoil_Strength": AntiRecoil_Strength,
            "Theme_Hex_Color": men_color,
            "Enable_Flick_Bot": Enable_Flick_Bot,
            "Flick_Scope_Sens": Flick_Scope_Sens,
            "Flick_Cooldown": Flick_Cooldown,
            "Flick_Delay": Flick_Delay,
            "Flickbot_Keybind": self.Flickbot_Keybind,
            "Streamproof": Streamproof,

            "Enable_Aim_Slot1": bool(Enable_Aim_Slot1),
            "Enable_Aim_Slot2": bool(Enable_Aim_Slot2),
            "Enable_Aim_Slot3": bool(Enable_Aim_Slot3),
            "Enable_Aim_Slot4": bool(Enable_Aim_Slot4),
            "Enable_Aim_Slot5": bool(Enable_Aim_Slot5),
            "Slot1_Keybind": self.Slot1_Keybind,
            "Slot2_Keybind": self.Slot2_Keybind,
            "Slot3_Keybind": self.Slot3_Keybind,
            "Slot4_Keybind": self.Slot4_Keybind,
            "Slot5_Keybind": self.Slot5_Keybind,
            "Slot6_Keybind": self.Slot6_Keybind,
            "Fov_Size_Slot1": Fov_Size_Slot1,
            "Fov_Size_Slot2": Fov_Size_Slot2,
            "Fov_Size_Slot3": Fov_Size_Slot3,
            "Fov_Size_Slot4": Fov_Size_Slot4,
            "Fov_Size_Slot5": Fov_Size_Slot5,

            "Use_Model_Class": bool(Use_Model_Class),
            "Img_Value": Img_Value,
            "Model_FPS": Model_FPS,
            "Last_Model": Last_Model,

            "game": {
                "pixel_increment": pixel_increment,
                "randomness": randomness,
                "sensitivity": sensitivity,
                "distance_to_scale": distance_to_scale,
                "dont_launch_overlays": dont_launch_overlays,
                "use_mss": use_mss,
                "hide_masks":hide_masks
            }
        }

        global Keybind
        global Keybind2
        global Auto_Fire_Keybind
        global Flickbot_Keybind
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind

        Keybind = self.Keybind
        Keybind2 = self.Keybind2
        Auto_Fire_Keybind = self.Auto_Fire_Keybind
        Flickbot_Keybind = self.Flickbot_Keybind
        Slot1_Keybind = self.Slot1_Keybind
        Slot2_Keybind = self.Slot2_Keybind
        Slot3_Keybind = self.Slot3_Keybind
        Slot4_Keybind = self.Slot4_Keybind
        Slot5_Keybind = self.Slot5_Keybind
        Slot6_Keybind = self.Slot6_Keybind

        with open('./config.json', 'w') as outfile:
            jsond.dump(config_settings, outfile, indent=4)

        #self.s()

    def closeEvent(self, event):
        try:
            # Arrêter tous les timers Qt
            for timer in self.findChildren(QTimer):
                timer.stop()

            # Arrêter le HueUpdater si présent
            if hasattr(self, 'hue_updater'):
                self.hue_updater.stop()
                self.hue_updater.join(timeout=1.0)

            # Arrêter les autres threads en cours
            # Marquer tous les threads comme devant s'arrêter
            for thread in threading.enumerate():
                if hasattr(thread, 'running'):
                    thread.running = False

            # Attendre que les threads se terminent avec timeout
            for thread in threading.enumerate():
                if thread != threading.main_thread():
                    thread.join(timeout=1.0)

            # Sauvegarder la configuration
            self.auto_save_config()

            # Fermer la fenêtre de console
            try:
                console_window = ctypes.windll.kernel32.GetConsoleWindow()
                ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
            except:
                pass

            # Accepter l'événement de fermeture
            event.accept()

            # Forcer la fermeture de Python
            os._exit(0)

        except Exception as e:
            print(f"Erreur lors de la fermeture : {e}")
            # En cas d'erreur, forcer la fermeture
            try:
                os._exit(1)
            except:
                os.system('taskkill /f /fi "imagename eq python.exe" >nul 2>&1')
                
    def update_aim_bone(self, index):
        self.Aim_Bone = self.aim_bone_combobox.currentText()
        global Aim_Bone
        if self.aim_bone_combobox.currentText() == "Head":
            Aim_Bone = "Head"
        if self.aim_bone_combobox.currentText() == "Neck":
            Aim_Bone = "Neck"
        if self.aim_bone_combobox.currentText() == "Body":
            Aim_Bone = "Body"
        self.auto_save_config()

    def update_smoothing_type(self, index):
        self.Smoothing_Type = self.smoothing_type_combobox.currentText()
        global Smoothing_Type
        if self.smoothing_type_combobox.currentText() == "Default":
            Smoothing_Type = "Default"
        if self.smoothing_type_combobox.currentText() == "Bezier":
            Smoothing_Type = "Bezier"
        if self.smoothing_type_combobox.currentText() == "Catmull-Rom":
            Smoothing_Type = "Catmull"
        if self.smoothing_type_combobox.currentText() == "Hermite":
            Smoothing_Type = "Hermite"
        if self.smoothing_type_combobox.currentText() == "B-Spline":
            Smoothing_Type = "B-Spline"
        if self.smoothing_type_combobox.currentText() == "Sine":
            Smoothing_Type = "Sine"
        if self.smoothing_type_combobox.currentText() == "Exponential":
            Smoothing_Type = "Exponential"
        self.auto_save_config()

    def update_box_type(self, index):
        self.Box_type = self.box_type_combobox.currentText()
        global Box_type
        if self.box_type_combobox.currentText() == "Regular":
            Box_type = "Regular"
        if self.box_type_combobox.currentText() == "Corner":
            Box_type = "Corner"
        if self.box_type_combobox.currentText() == "Filled":
            Box_type = "Filled"
        self.auto_save_config()


    def update_img_value(self, index):
        self.Img_Value = self.img_value_combobox.currentText()
        global Img_Value
        if self.img_value_combobox.currentText() == "200":
            Img_Value = "200"
        if self.img_value_combobox.currentText() == "320":
            Img_Value = "320"
        if self.img_value_combobox.currentText() == "480":
            Img_Value = "480"
        if self.img_value_combobox.currentText() == "640":
            Img_Value = "640"
        if self.img_value_combobox.currentText() == "736":
            Img_Value = "736"
        if self.img_value_combobox.currentText() == "832":
            Img_Value = "832"
        self.auto_save_config()

    def temp_spoof(self):
        ...

    def refresh_extra(self):

        global pixel_increment
        global randomness
        global sensitivity
        global distance_to_scale
        global dont_launch_overlays
        global use_mss
        global hide_masks

        #SECRET CONFIG
        secretfile = open('./config.json')
        secretconfig = jsond.load(secretfile)["game"]
        pixel_increment = secretconfig['pixel_increment']
        randomness = secretconfig['randomness']
        sensitivity = secretconfig['sensitivity']
        distance_to_scale = secretconfig['distance_to_scale']
        dont_launch_overlays = secretconfig['dont_launch_overlays']
        use_mss = secretconfig['use_mss']
        hide_masks = secretconfig['hide_masks']

        self.auto_save_config()

    def start_select_hotkey(self):
        self.is_selecting_hotkey = True
        self.Keybind = None
        self.btn_hotkey.setText("...")
        threading.Thread(target=self.listen_for_hotkey).start()
        self.auto_save_config()

    def listen_for_hotkey(self):
        while self.is_selecting_hotkey:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Keybind = vk
                    self.is_selecting_hotkey = False
                    key_name_converted = KEY_NAMES.get(self.Keybind, f"0x{self.Keybind:02X}")
                    self.btn_hotkey.setText(f"{key_name_converted}")
                    self.auto_save_config()
                    break

    def start_select_hotkey2(self):
        self.is_selecting_hotkey2 = True
        self.Keybind2 = None
        self.btn_hotkey2.setText("...")
        threading.Thread(target=self.listen_for_hotkey2).start()
        self.auto_save_config()

    def listen_for_hotkey2(self):
        while self.is_selecting_hotkey2:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Keybind2 = vk
                    self.is_selecting_hotkey2 = False
                    key_name_converted2 = KEY_NAMES.get(self.Keybind2, f"0x{self.Keybind2:02X}")
                    self.btn_hotkey2.setText(f"{key_name_converted2}")
                    self.auto_save_config()
                    break

    def start_select_hotkey3(self):
        self.is_selecting_hotkey3 = True
        self.Auto_Fire_Keybind = None
        self.btn_hotkey3.setText("...")
        threading.Thread(target=self.listen_for_hotkey3).start()
        self.auto_save_config()

    def listen_for_hotkey3(self):
        while self.is_selecting_hotkey3:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Auto_Fire_Keybind = vk
                    self.is_selecting_hotkey3 = False
                    key_name_converted3 = KEY_NAMES.get(self.Auto_Fire_Keybind, f"0x{self.Auto_Fire_Keybind:02X}")
                    self.btn_hotkey3.setText(f"{key_name_converted3}")
                    self.auto_save_config()
                    break

    def start_select_hotkey4(self):
        self.is_selecting_hotkey4 = True
        self.Flickbot_Keybind = None
        self.btn_hotkey4.setText("...")
        threading.Thread(target=self.listen_for_hotkey4).start()
        self.auto_save_config()

    def listen_for_hotkey4(self):
        while self.is_selecting_hotkey4:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Flickbot_Keybind = vk
                    self.is_selecting_hotkey4 = False
                    key_name_converted4 = KEY_NAMES.get(self.Flickbot_Keybind, f"0x{self.Flickbot_Keybind:02X}")
                    self.btn_hotkey4.setText(f"{key_name_converted4}")
                    self.auto_save_config()
                    break

    def start_select_hotkey_slot1(self):
        self.is_selecting_hotkey_slot1 = True
        self.Slot1_Keybind = None
        self.btn_hotkey_slot1.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot1).start()
        self.auto_save_config()

    def listen_for_hotkey_slot1(self):
        while self.is_selecting_hotkey_slot1:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot1_Keybind = vk
                    self.is_selecting_hotkey_slot1 = False
                    key_name_converted_slot1 = KEY_NAMES.get(self.Slot1_Keybind, f"0x{self.Slot1_Keybind:02X}")
                    self.btn_hotkey_slot1.setText(f"{key_name_converted_slot1}")
                    self.auto_save_config()
                    break

    # Slot 2
    def start_select_hotkey_slot2(self):
        self.is_selecting_hotkey_slot2 = True
        self.Slot2_Keybind = None
        self.btn_hotkey_slot2.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot2).start()
        self.auto_save_config()

    def listen_for_hotkey_slot2(self):
        while self.is_selecting_hotkey_slot2:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot2_Keybind = vk
                    self.is_selecting_hotkey_slot2 = False
                    key_name_converted_slot2 = KEY_NAMES.get(self.Slot2_Keybind, f"0x{self.Slot2_Keybind:02X}")
                    self.btn_hotkey_slot2.setText(f"{key_name_converted_slot2}")
                    self.auto_save_config()
                    break

    # Slot 3
    def start_select_hotkey_slot3(self):
        self.is_selecting_hotkey_slot3 = True
        self.Slot3_Keybind = None
        self.btn_hotkey_slot3.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot3).start()
        self.auto_save_config()

    def listen_for_hotkey_slot3(self):
        while self.is_selecting_hotkey_slot3:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot3_Keybind = vk
                    self.is_selecting_hotkey_slot3 = False
                    key_name_converted_slot3 = KEY_NAMES.get(self.Slot3_Keybind, f"0x{self.Slot3_Keybind:02X}")
                    self.btn_hotkey_slot3.setText(f"{key_name_converted_slot3}")
                    self.auto_save_config()
                    break

    # Slot 4
    def start_select_hotkey_slot4(self):
        self.is_selecting_hotkey_slot4 = True
        self.Slot4_Keybind = None
        self.btn_hotkey_slot4.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot4).start()
        self.auto_save_config()

    def listen_for_hotkey_slot4(self):
        while self.is_selecting_hotkey_slot4:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot4_Keybind = vk
                    self.is_selecting_hotkey_slot4 = False
                    key_name_converted_slot4 = KEY_NAMES.get(self.Slot4_Keybind, f"0x{self.Slot4_Keybind:02X}")
                    self.btn_hotkey_slot4.setText(f"{key_name_converted_slot4}")
                    self.auto_save_config()
                    break

    # Slot 5
    def start_select_hotkey_slot5(self):
        self.is_selecting_hotkey_slot5 = True
        self.Slot5_Keybind = None
        self.btn_hotkey_slot5.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot5).start()
        self.auto_save_config()

    def listen_for_hotkey_slot5(self):
        while self.is_selecting_hotkey_slot5:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot5_Keybind = vk
                    self.is_selecting_hotkey_slot5 = False
                    key_name_converted_slot5 = KEY_NAMES.get(self.Slot5_Keybind, f"0x{self.Slot5_Keybind:02X}")
                    self.btn_hotkey_slot5.setText(f"{key_name_converted_slot5}")
                    self.auto_save_config()
                    break

    # Slot 6
    def start_select_hotkey_slot6(self):
        self.is_selecting_hotkey_slot6 = True
        self.Slot6_Keybind = None
        self.btn_hotkey_slot6.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot6).start()
        self.auto_save_config()

    def listen_for_hotkey_slot6(self):
        while self.is_selecting_hotkey_slot6:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot6_Keybind = vk
                    self.is_selecting_hotkey_slot6 = False
                    key_name_converted_slot6 = KEY_NAMES.get(self.Slot6_Keybind, f"0x{self.Slot6_Keybind:02X}")
                    self.btn_hotkey_slot6.setText(f"{key_name_converted_slot6}")
                    self.auto_save_config()
                    break

    def calculate_color(self, hue, opacity, lightness):
        overlay_color = QColor.fromHsl(235, 87, 78)
        overlay_color.setAlpha(100)
        return overlay_color

    def on_slider_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider.setValue(tick_position)
        global Fov_Size
        Fov_Size = tick_position
        self.Fov_Size_label.setText(f'FOV: {str(Fov_Size)}')

    def on_slider0_value_change(self, value):
        self.auto_save_config()
        tick_position0 = round(value / 1) * 1
        self.slider0.setValue(tick_position0)
        global Confidence
        Confidence = tick_position0
        self.Confidence_label.setText(f'Confidence: {str(Confidence)}%')

    def on_slider_fps_value_change(self, value):
        self.auto_save_config()
        tick_position0r = round(value / 1) * 1
        self.slider_fps.setValue(tick_position0r)
        global Model_FPS
        Model_FPS = tick_position0r
        self.fps_label.setText(f'Max FPS: {str(Model_FPS)}')

    def on_slider3_value_change(self, value):
        self.auto_save_config()
        # Ensure the slider can go up to 250
        tick_position3 = round(value / 5) * 5
        self.slider3.setRange(0, 250)  # Set the range of the slider
        self.slider3.setValue(tick_position3)
        
        global Aim_Smooth
        Aim_Smooth = tick_position3
        self.Aim_Smooth_label.setText(f'Strength: {str(Aim_Smooth)}')


    def on_slider4_value_change(self, value):
        self.auto_save_config()
        tick_position4 = round(value / 1) * 1
        self.slider4.setValue(tick_position4)
        global Max_Detections
        Max_Detections = tick_position4
        self.Max_Detections_label.setText(f'Max Detections: {str(Max_Detections)}')

    def on_slider5_value_change(self, value):
        self.auto_save_config()
        tick_position5 = round(value / 1) * 1
        self.slider5.setValue(tick_position5)
        global Auto_Fire_Fov_Size
        Auto_Fire_Fov_Size = tick_position5
        self.Auto_Fire_Fov_Size_label.setText(f'FOV Size: {str(Auto_Fire_Fov_Size)}')

    def on_slider60_value_change(self, value):
        self.auto_save_config()
        tick_position60 = round(value / 1) * 1
        self.slider60.setValue(tick_position60)
        global AntiRecoil_Strength
        AntiRecoil_Strength = tick_position60
        self.AntiRecoil_Strength_label.setText(f'Strength: {str(AntiRecoil_Strength)}')

    def on_slider_slot1_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot1.setValue(tick_position)
        global Fov_Size_Slot1
        Fov_Size_Slot1 = tick_position
        self.Fov_Size_label_slot1.setText(f'FOV: {str(Fov_Size_Slot1)}')

    def on_slider_slot2_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot2.setValue(tick_position)
        global Fov_Size_Slot2
        Fov_Size_Slot2 = tick_position
        self.Fov_Size_label_slot2.setText(f'FOV: {str(Fov_Size_Slot2)}')

    def on_slider_slot3_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot3.setValue(tick_position)
        global Fov_Size_Slot3
        Fov_Size_Slot3 = tick_position
        self.Fov_Size_label_slot3.setText(f'FOV: {str(Fov_Size_Slot3)}')

    def on_slider_slot4_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot4.setValue(tick_position)
        global Fov_Size_Slot4
        Fov_Size_Slot4 = tick_position
        self.Fov_Size_label_slot4.setText(f'FOV: {str(Fov_Size_Slot4)}')

    def on_slider_slot5_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot5.setValue(tick_position)
        global Fov_Size_Slot5
        Fov_Size_Slot5 = tick_position
        self.Fov_Size_label_slot5.setText(f'FOV: {str(Fov_Size_Slot5)}')

    def on_flick_scope_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_flick_scope = round(value / 1) * 1
        self.flick_scope_slider.setValue(tick_position_flick_scope)
        global Flick_Scope_Sens
        Flick_Scope_Sens = tick_position_flick_scope
        self.flick_scope_label.setText(f'Flick Strength: {str(Flick_Scope_Sens)}%')

    def on_flick_cool_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_cooldown = round(value / 5) * 5 / 100.0
        self.flick_cool_slider.setValue(int(tick_position_cooldown * 100))
        global Flick_Cooldown
        Flick_Cooldown = tick_position_cooldown
        self.flick_cool_label.setText(f'Cool Down: {str(Flick_Cooldown)}s')

    def on_flick_delay_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_delay = value / 1000.0
        self.flick_delay_slider.setValue(int(tick_position_delay * 1000))
        global Flick_Delay
        Flick_Delay = tick_position_delay
        self.flick_delay_label.setText(f'Shot Delay: {str(Flick_Delay)}s')

    def on_slider6_value_change(self, value):
        self.auto_save_config()
        tick_position6 = round(value / 1) * 1
        self.slider6.setValue(tick_position6)
        global Auto_Fire_Confidence
        Auto_Fire_Confidence = tick_position6
        self.Auto_Fire_Confidence_label.setText(f'Confidence: {str(Auto_Fire_Confidence)}%')

    def toggle_checkbox1(self, state):
        self.auto_save_config()
        # Update the global variable Enable_Aim
        global Enable_Aim
        Enable_Aim = state == Qt.Unchecked

        # Toggle the state of the checkbox
        self.Enable_Aim_checkbox.setChecked(not Enable_Aim)

        QApplication.processEvents()
        self.auto_save_config()

    def on_checkbox_state_change(self, state):
        self.auto_save_config()
        if self.sender() == self.Enable_Aim_checkbox:
            global Enable_Aim
            Enable_Aim = (state == Qt.Checked)
        # if self.sender() == self.Streamproof_checkbox:
        # 	global Streamproof
        # 	Streamproof = (state == Qt.Checked)
        if self.sender() == self.Enable_Aim_Slot1_checkbox:
            global Enable_Aim_Slot1
            Enable_Aim_Slot1 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot2_checkbox:
            global Enable_Aim_Slot2
            Enable_Aim_Slot2 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot3_checkbox:
            global Enable_Aim_Slot3
            Enable_Aim_Slot3 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot4_checkbox:
            global Enable_Aim_Slot4
            Enable_Aim_Slot4 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot5_checkbox:
            global Enable_Aim_Slot5
            Enable_Aim_Slot5 = (state == Qt.Checked)

        if self.sender() == self.Enable_Slots_checkbox:
            global Enable_Slots
            Enable_Slots = (state == Qt.Checked)

        if self.sender() == self.Show_Fov_checkbox:
            global Show_Fov
            Show_Fov = (state == Qt.Checked)

        if self.sender() == self.Show_Crosshair_checkbox:
            global Show_Crosshair
            Show_Crosshair = (state == Qt.Checked)

        if self.sender() == self.Show_CMD_checkbox:
            kernel32 = ctypes.WinDLL('kernel32')
            user32 = ctypes.WinDLL('user32')
            hWnd = kernel32.GetConsoleWindow()
            SW_HIDE = 0
            SW_SHOW = 5	
            user32.ShowWindow(hWnd, SW_HIDE if user32.IsWindowVisible(hWnd) else SW_SHOW)

        if self.sender() == self.Show_Debug_checkbox:
            global Show_Debug
            Show_Debug = (state == Qt.Checked)
            if Show_Debug == False:
                hwnd = win32gui.FindWindow(None, random_caption1)
                win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
            else:
                hwnd = win32gui.FindWindow(None, random_caption1)
                win32gui.ShowWindow(hwnd, win32con.SW_SHOWNORMAL)

        if self.sender() == self.Show_FPS_checkbox:
            global Show_FPS
            Show_FPS = (state == Qt.Checked)

        if self.sender() == self.Enable_TriggerBot_checkbox:
            global Enable_TriggerBot
            Enable_TriggerBot = (state == Qt.Checked)

        if self.sender() == self.Show_Detections_checkbox:
            global Show_Detections
            Show_Detections = (state == Qt.Checked)

        if self.sender() == self.Show_Aimline_checkbox:
            global Show_Aimline
            Show_Aimline = (state == Qt.Checked)

        if self.sender() == self.Require_Keybind_checkbox:
            global Require_Keybind
            Require_Keybind = (state == Qt.Checked)

        if self.sender() == self.Controller_On_checkbox:
            global Controller_On
            Controller_On = (state == Qt.Checked)

        if self.sender() == self.CupMode_On_checkbox:
            global CupMode_On
            CupMode_On = (state == Qt.Checked)

        if self.sender() == self.Reduce_Bloom_checkbox:
            global Reduce_Bloom
            Reduce_Bloom = (state == Qt.Checked)

        if self.sender() == self.Require_ADS_checkbox:
            global Require_ADS
            Require_ADS = (state == Qt.Checked)

        if self.sender() == self.AntiRecoil_On_checkbox:
            global AntiRecoil_On
            AntiRecoil_On = (state == Qt.Checked)

        if self.sender() == self.Enable_Flick_checkbox:
            global Enable_Flick_Bot
            Enable_Flick_Bot = (state == Qt.Checked)

        if self.sender() == self.Use_Hue_checkbox:
            global Use_Hue
            Use_Hue = (state == Qt.Checked)

        if self.sender() == self.Use_Model_Class_checkbox:
            global Use_Model_Class
            Use_Model_Class = (state == Qt.Checked)

        self.auto_save_config()

class HueUpdaterThread(threading.Thread):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.hue = 0
        self.running = True
        self.daemon = True  # Important: permet au thread de se terminer avec le programme principal 
        self._stop_event = threading.Event()  # Pour une meilleure gestion de l'arrêt

    def run(self):
        while self.running and not self._stop_event.is_set():
            # Update hue value
            self.hue = (self.hue + 1) % 360
            time.sleep(0.025)  # Adjust the sleep time for smoother animation

    def stop(self):
        """Arrête proprement le thread"""
        self.running = False
        self._stop_event.set()
        self.join(timeout=1.0)  # Attendre que le thread se termine avec timeout
        
class DetectionBox(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint | 
                            Qt.WindowStaysOnTopHint | Qt.WindowTransparentForInput | 
                            Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.load_config()

        global Fov_Size
        self.Fov_Size = Fov_Size
        self.setGeometry(
            int(screen_res_X - self.Fov_Size + 2) // 2,
            int(screen_res_Y - self.Fov_Size + 2) // 2,
            self.Fov_Size + 25, 
            self.Fov_Size + 25
        )
        window_handle = int(self.winId())
        user32.SetWindowDisplayAffinity(
            window_handle, 0x00000011
        ) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)

        self.detected_players = []

        self.hue_updater = HueUpdaterThread(self)
        self.hue_updater.start()

        self.current_slot_selectedd = 1
        self.update_fov_size()

        # Timer de repaint moins fréquent : 16 ms => ~60 fps
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(16)

        self.start_time = time.perf_counter()

        self.key_states = {k: False for k in 
            [Slot1_Keybind, Slot2_Keybind, Slot3_Keybind, Slot4_Keybind, Slot5_Keybind, Slot6_Keybind]
            if k is not None
        }

        self.key_check_timer = QTimer(self)
        self.key_check_timer.timeout.connect(self.check_key_states)
        self.key_check_timer.start(10) 

    def update_detected_players(self, detected_players):
        self.detected_players = detected_players
        self.update()

    def clear_detected_players(self):
        self.detected_players = []
        self.update()

    def fps(self):
        return int(1.5 / (time.perf_counter() - self.start_time))

    def load_config(self):
        with open('./config.json', 'r') as infile:
            config_settings = jsond.load(infile)

        self.Use_Hue = config_settings['Use_Hue']

        # self.fov_color = QColor(
        # 	config_settings.get("RGBA_Value", {}).get("red", 255),
        # 	config_settings.get("RGBA_Value", {}).get("green", 255),
        # 	config_settings.get("RGBA_Value", {}).get("blue", 255),
        # 	config_settings.get("RGBA_Value", {}).get("opacity", 255)
        # )

        self.fov_color = QColor(255,255,255,255)
        self.lightness = config_settings.get("RGBA_Value", {}).get("lightness", 128)  # Add this line

        self.fov_color_outline = QColor(
            0,
            0,
            0,
            config_settings.get("RGBA_Value", {}).get("opacity", 255)
        )

        # self.watermark_color = QColor(
        # 	config_settings.get("RGBA_Value", {}).get("red", 255),
        # 	config_settings.get("RGBA_Value", {}).get("green", 255),
        # 	config_settings.get("RGBA_Value", {}).get("blue", 255),
        # 	config_settings.get("RGBA_Value", {}).get("opacity", 255)
        # )
        self.watermark_color = QColor(151,159,251,255)
        self.watermark_color_outline = QColor(
            0,
            0,
            0,
            0
        )

        self.crosshair_dot_color = QColor(
            config_settings.get("RGBA_Value", {}).get("red", 255),
            config_settings.get("RGBA_Value", {}).get("green", 255),
            config_settings.get("RGBA_Value", {}).get("blue", 255),
            255
        )
        self.crosshair_color = QColor(255, 255, 255, 255)  # Crosshair color with full opacity

        self.fov_thickness = 1.5
        self.watermark_thickness = 0.5
        self.crosshair_thickness = 1.5

    def BlueADS(self):
        return True if win32api.GetKeyState(win32con.VK_RBUTTON) in (-127, -128) else False
        pass

    def BlueFire(self):
        return True if win32api.GetKeyState(win32con.VK_LBUTTON) in (-127, -128) else False
        pass

    def check_key_states(self):
        if Enable_Slots:
            # Check each key and update states
            for key, slot in zip([Slot1_Keybind, Slot2_Keybind, Slot3_Keybind, Slot4_Keybind, Slot5_Keybind, Slot6_Keybind], range(1, 7)):
                if key is not None:
                    # Check if the key is in self.key_states
                    if key not in self.key_states:
                        print(f"[+] NizzwareAI\n[+] {key} Not Found In Database...")
                        self.key_states[key] = False  # Initialize the state if it's missing
                    current_state = win32api.GetAsyncKeyState(key) < 0
                    if current_state and not self.key_states[key]:
                        # Key has been pressed down
                        self.current_slot_selectedd = slot
                        self.update_fov_size()
                    self.key_states[key] = current_state

        if not Enable_Slots:
            self.Fov_Size = Fov_Size

        self.update()

    def update_fov_size(self):
        if Enable_Slots:
            if self.current_slot_selectedd is not None:
                if self.current_slot_selectedd == 1:
                    self.Fov_Size = Fov_Size_Slot1
                elif self.current_slot_selectedd == 2:
                    self.Fov_Size = Fov_Size_Slot2
                elif self.current_slot_selectedd == 3:
                    self.Fov_Size = Fov_Size_Slot3
                elif self.current_slot_selectedd == 4:
                    self.Fov_Size = Fov_Size_Slot4
                elif self.current_slot_selectedd == 5:
                    self.Fov_Size = Fov_Size_Slot5
                elif self.current_slot_selectedd == 6:
                    self.Fov_Size = 15
            else:
                self.Fov_Size = Fov_Size
        if not Enable_Slots:
            self.Fov_Size = Fov_Size

        self.setGeometry(int(screen_res_X-4 - self.Fov_Size+2) // 2, int(screen_res_Y-4 - self.Fov_Size+2) // 2, self.Fov_Size+25, self.Fov_Size+25)
        self.update()

    def paintEvent(self, event):

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if not Enable_Slots:
            self.setGeometry(int(screen_res_X-4 - self.Fov_Size+2) // 2, int(screen_res_Y-4 - self.Fov_Size+2) // 2, self.Fov_Size+25, self.Fov_Size+25)
        self.load_config()

        font_size_px = 11
        font = QFont("Verdana")
        font.setPixelSize(font_size_px)
        painter.setFont(font)

        if CupMode_On:
            pass
        elif CupMode_On == False:

            if self.current_slot_selectedd == 6:
                if Enable_Slots:
                    pass
            else:
                if Show_Fov:
                    center_x = self.Fov_Size // 2
                    center_y = self.Fov_Size // 2
                    fov_radius = self.Fov_Size // 2 - self.fov_thickness // 2
                    if Use_Hue:
                        fov_thickness = 1.1
                        num_sections = 360
                        section_angle = 360 / num_sections

                        for i in range(num_sections):
                            hue = (self.hue_updater.hue + i) % 360
                            color = QColor.fromHsv(hue, 175, 255)
                            pen = QPen(color, fov_thickness, Qt.SolidLine)
                            painter.setPen(pen)
                            start_angle = i * section_angle * 16
                            end_angle = (i + 1) * section_angle * 16
                            rect = QRect(int(center_x + 2 - fov_radius), int(center_y + 2 - fov_radius), int(2 * fov_radius), int(2 * fov_radius))
                            painter.drawArc(rect, int(start_angle), int(section_angle * 16))
                    else:
                        fov_rect = QRectF(center_x+2 - fov_radius, center_y+2 - fov_radius, 2 * fov_radius, 2 * fov_radius)
                        painter.setPen(QPen(self.fov_color, self.fov_thickness, Qt.SolidLine))
                        painter.drawEllipse(fov_rect)
                        if Visual_Outlines:
                            inner_radius = fov_radius - 1.0
                            outer_radius = fov_radius + 1.0
                            pen_inner = QPen(self.fov_color_outline, 0.6)
                            pen_outer = QPen(self.fov_color_outline, 0.6)
                            painter.setPen(pen_inner)
                            inner_rect = QRect(int(center_x+2 - inner_radius), int(center_y+2 - inner_radius), int(2 * inner_radius), int(2 * inner_radius))
                            painter.drawEllipse(inner_rect)
                            painter.setPen(pen_outer)
                            outer_rect = QRect(int(center_x+2 - outer_radius), int(center_y+2 - outer_radius), int(2 * outer_radius), int(2 * outer_radius))
                            painter.drawEllipse(outer_rect)

            if Show_Crosshair:
                # if self.BlueFire():
                #     pen_crosshair_ads = QPen(QColor(255, 255, 255, 255), 0.3, Qt.SolidLine)
                #     painter.setPen(pen_crosshair_ads)
                #     painter.setRenderHint(QPainter.Antialiasing, False)
                #     center_x = self.width() // 2 - 11
                #     center_y = self.height() // 2 - 11
                #     painter.drawLine(center_x, center_y + 3, center_x, center_y - 3)
                #     painter.drawLine(center_x - 3, center_y, center_x + 3, center_y)
                # else:
                    # Commenting out the part where it gets smaller
                    # if self.BlueADS():
                    #     pen_crosshair_ads = QPen(QColor(255, 255, 255, 255), 0.5, Qt.SolidLine)
                    #     painter.setPen(pen_crosshair_ads)
                    #     painter.setRenderHint(QPainter.Antialiasing, False)
                    #     center_x = self.width() // 2 - 11
                    #     center_y = self.height() // 2 - 11
                    #     painter.drawLine(center_x, center_y + 5, center_x, center_y - 5)
                    #     painter.drawLine(center_x - 5, center_y, center_x + 5, center_y)
                    # else:
                    
                    pen_crosshair = QPen(QColor(255, 255, 255, 255), 1.1, Qt.SolidLine)
                    painter.setPen(pen_crosshair)
                    painter.setRenderHint(QPainter.Antialiasing, False)
                    center_x = self.width() // 2 - 11
                    center_y = self.height() // 2 - 11
                    painter.drawLine(center_x, center_y + 7, center_x, center_y - 7)
                    painter.drawLine(center_x - 7, center_y, center_x + 7, center_y)
                    
                    dot_radius = 1
                    if Use_Hue:
                        hue = self.hue_updater.hue
                        dot_pen = QPen(QColor.fromHsv(hue, 255, 255), dot_radius * 2)
                    else:
                        dot_pen = QPen(self.crosshair_dot_color, dot_radius * 2)
                    painter.setPen(dot_pen)
                    painter.drawPoint(center_x, center_y)
                    
                    pen_crosshair_outline = QPen(Qt.black, 1, Qt.SolidLine)  # Adjust thickness as needed
                    painter.setPen(pen_crosshair_outline)
                    outline_offset = 1
                    painter.drawLine(center_x - outline_offset, center_y + 8, center_x - outline_offset, center_y - 8)
                    painter.drawLine(center_x - 8, center_y - outline_offset, center_x + 8, center_y - outline_offset)
                    painter.drawLine(center_x + outline_offset, center_y + 8, center_x + outline_offset, center_y - 8)
                    painter.drawLine(center_x - 8, center_y + outline_offset, center_x + 8, center_y + outline_offset)
                    painter.drawLine(center_x - outline_offset, center_y - 8, center_x + outline_offset, center_y - 8)
                    painter.drawLine(center_x - outline_offset, center_y + 8, center_x + outline_offset, center_y + 8)
                    painter.drawLine(center_x - 8, center_y - outline_offset, center_x - 8, center_y + outline_offset)
                    painter.drawLine(center_x + 8, center_y - outline_offset, center_x + 8, center_y + outline_offset)

            self.update()

            if self.current_slot_selectedd == 6:
                if Enable_Slots:
                    pass
            else:
                if Show_Detections:
                    for player in self.detected_players:

                        x1, y1, x2, y2 = player['x1'], player['y1'], player['x2'], player['y2']
                        head1, head2 = player['head1'], player['head2']

                        #self.update_fov_size()

                        width = x2 - x1
                        height = y2 - y1

                        margin_factor = 0.1
                        margin_x = width * margin_factor
                        margin_y = height * margin_factor

                        x1 -= margin_x
                        y1 -= margin_y
                        x2 += margin_x
                        y2 += margin_y
                        width = x2 - x1
                        height = y2 - y1
                        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                        head1, head2 = int(head1), int(head2)

                        if Box_type == "Corner":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 0, 189, 255)
                                painter.setPen(QPen(color, 1))
                            else:
                                painter.setPen(QPen(self.fov_color, 1))

                            corner_length = int(min(width, height) * 0.1) 

                            if Visual_Outlines:
                                painter.setPen(QPen(Qt.black, 1))
                                painter.setRenderHint(QPainter.Antialiasing, False)
                                # Top-left corner (outside)
                                painter.drawLine(x1 - 1, y1 - 1, x1 + corner_length + 1, y1 - 1)
                                painter.drawLine(x1 - 1, y1 - 1, x1 - 1, y1 + corner_length + 1)
                                # Top-right corner (outside)
                                painter.drawLine(x2 + 1, y1 - 1, x2 - corner_length - 1, y1 - 1)
                                painter.drawLine(x2 + 1, y1 - 1, x2 + 1, y1 + corner_length + 1)
                                # Bottom-left corner (outside)
                                painter.drawLine(x1 - 1, y2 + 1, x1 + corner_length + 1, y2 + 1)
                                painter.drawLine(x1 - 1, y2 + 1, x1 - 1, y2 - corner_length - 1)
                                # Bottom-right corner (outside)
                                painter.drawLine(x2 + 1, y2 + 1, x2 - corner_length - 1, y2 + 1)
                                painter.drawLine(x2 + 1, y2 + 1, x2 + 1, y2 - corner_length - 1)

                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 0, 189, 255)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(QColor(0,189,255,255), 1))
                            painter.drawLine(x1, y1, x1 + corner_length, y1)
                            painter.drawLine(x1, y1, x1, y1 + corner_length)
                            painter.drawLine(x2, y1, x2 - corner_length, y1)
                            painter.drawLine(x2, y1, x2, y1 + corner_length)
                            painter.drawLine(x1, y2, x1 + corner_length, y2)
                            painter.drawLine(x1, y2, x1, y2 - corner_length)
                            painter.drawLine(x2, y2, x2 - corner_length, y2)
                            painter.drawLine(x2, y2, x2, y2 - corner_length)

                            # if Visual_Outlines:
                            # 	painter.setPen(QPen(Qt.black, 1))
                            # 	painter.setRenderHint(QPainter.Antialiasing, False)
                            # 	# Top-left corner (inside)
                            # 	painter.drawLine(x1 + 1, y1 + 1, x1 + corner_length - 1, y1 + 1)
                            # 	painter.drawLine(x1 + 1, y1 + 1, x1 + 1, y1 + corner_length - 1)
                            # 	# Top-right corner (inside)
                            # 	painter.drawLine(x2 - 1, y1 + 1, x2 - corner_length + 1, y1 + 1)
                            # 	painter.drawLine(x2 - 1, y1 + 1, x2 - 1, y1 + corner_length - 1)
                            # 	# Bottom-left corner (inside)
                            # 	painter.drawLine(x1 + 1, y2 - 1, x1 + corner_length - 1, y2 - 1)
                            # 	painter.drawLine(x1 + 1, y2 - 1, x1 + 1, y2 - corner_length + 1)
                            # 	# Bottom-right corner (inside)
                            # 	painter.drawLine(x2 - 1, y2 - 1, x2 - corner_length + 1, y2 - 1)
                            # 	painter.drawLine(x2 - 1, y2 - 1, x2 - 1, y2 - corner_length + 1)
                        elif Box_type == "Regular":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 0, 189, 55)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(self.fov_color, 2))

                            # Draw the rectangle using lines
                            painter.drawLine(x1, y1, x2, y1)  # Top edge
                            painter.drawLine(x2, y1, x2, y2)  # Right edge
                            painter.drawLine(x2, y2, x1, y2)  # Bottom edge
                            painter.drawLine(x1, y2, x1, y1)
                        elif Box_type == "Filled":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 0, 189, 55)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(QColor(0, 189, 248, int(255 * 0.75)), 2))

                            fill_color = QColor(0, 189, 248, int(255 * 0.25))
                            painter.setBrush(QBrush(fill_color, Qt.SolidPattern))

                            points = [QPoint(x1, y1), QPoint(x2, y1), QPoint(x2, y2), QPoint(x1, y2)]

                            painter.drawPolygon(QPolygon(points))

                            # # Draw the outline of the rectangle using lines
                            # painter.drawLine(x1, y1, x2, y1)  # Top edge
                            # painter.drawLine(x2, y1, x2, y2)  # Right edge
                            # painter.drawLine(x2, y2, x1, y2)  # Bottom edge
                            # painter.drawLine(x1, y2, x1, y1)
                if Show_Aimline:
                    for player in self.detected_players:
                        head1, head2 = player['head1'], player['head2']  # Extract head1 and head2
                        # self.update_fov_size()
                        center_x, center_y = self.Fov_Size // 2 + 1, self.Fov_Size // 2 + 1

                        # Adjust thickness for smaller outline lines
                        painter.setPen(QPen(self.fov_color, 0.5))  # Use 0.5 for a thinner line
                        painter.drawLine(head1 - 1, head2, center_x - 1, center_y)
                        painter.drawLine(head1 + 1, head2, center_x + 1, center_y)
                        painter.drawLine(head1, head2 - 1, center_x, center_y - 1)
                        painter.drawLine(head1, head2 + 1, center_x, center_y + 1)

                        # Draw the main aim line with the chosen thickness
                        if Use_Hue:
                            painter.setPen(QPen(color, 0.5))  # Adjust this value for thickness
                        else:
                            painter.setPen(QPen(self.fov_color, 0.5))  # Thinner aim line
                        painter.drawLine(head1, head2, center_x, center_y)

                # if Use_Hue:
                # 	bottom_left_text = "0xWTF"
                # 	text_rect = QRect(10, self.height() - 15, self.width() - 15, 16)
                # 	pen_black = QPen(QColor(0, 0, 0, 255), 2.5, Qt.SolidLine)
                # 	painter.setPen(pen_black)
                # 	for dx in [-1, 0, 1]:
                # 		for dy in [-1, 0, 1]:
                # 			painter.drawText(text_rect.translated(dx, dy), Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # 	pen_white = QPen(QColor(255, 255, 255), 0.5, Qt.SolidLine)
                # 	painter.setPen(pen_white)
                # 	painter.drawText(text_rect, Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # else:
                # 	bottom_left_text = "0xWTF"
                # 	text_rect = QRect(10, self.height()-15, self.width()-15, 16)
                # 	pen_black = QPen(self.watermark_color_outline, 2.5, Qt.SolidLine)
                # 	painter.setPen(pen_black)
                # 	for dx in [-1, 0, 1]:
                # 		for dy in [-1, 0, 1]:
                # 			painter.drawText(text_rect.translated(dx, dy), Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # 	painter.setPen(QPen(self.watermark_color, self.watermark_thickness, Qt.SolidLine))
                # 	painter.drawText(text_rect, Qt.AlignRight | Qt.AlignBottom, bottom_left_text)

    def focusInEvent(self, event):
        ctypes.windll.user32.SetFocus(None)

Controller_Toggled = False

class ControllerMode():
    global Controller_Toggled
    def main():
        """
        Boucle d'écoute du contrôleur.
        -> On remplace pygame.time.wait(6) par time.sleep(0.01),
           ce qui donne ~100 itérations/sec au lieu de ~166.
        """
        try:
            pygame.init()
            pygame.joystick.init()

            joystick = pygame.joystick.Joystick(0)
            joystick.init()

            while True:
                global Controller_Toggled
                pygame.event.get()

                left_trigger = joystick.get_axis(4)

                if left_trigger > 0.9:
                    Controller_Toggled = True
                else:
                    Controller_Toggled = False

                # Au lieu de pygame.time.wait(6)
                time.sleep(0.01)

        except:
            pass


def LemonLoverF9():
    """
    Boucle Anti-Recul + Reduce Bloom.
    -> On remplace le time.sleep(0.00005 à 0.00010) par quelque chose de
       plus élevé pour éviter une boucle à 10k itérations/sec.
    """
    global AntiRecoil_Strength
    global AntiRecoil_On
    global Reduce_Bloom
    global Require_ADS
    
    # Détermination de l'état du clic gauche en fonction de Require_ADS
    def is_mouse_down():
        if Require_ADS:
            # On combine LMB et RMB si besoin
            lmb_state = win32api.GetKeyState(0x01) & win32api.GetKeyState(0x02)
            return (lmb_state < 0)
        else:
            lmb_state = win32api.GetKeyState(0x01)
            return (lmb_state < 0)

    while True:
        RoundedRStr = round(AntiRecoil_Strength)
        min_vertical = int(RoundedRStr)
        max_vertical = int(RoundedRStr) + 1

        if is_mouse_down():
            # On réduit la plage random pour limiter la surutilisation
            horizontal_offset = random.uniform(-2.0, 2.0)  # Au lieu de 2 * 1000/1000
            vertical_offset = random.uniform(min_vertical, max_vertical)
            
            if AntiRecoil_On:
                win32api.mouse_event(0x0001, 0, int(vertical_offset))
            if Reduce_Bloom:
                win32api.mouse_event(0x0001, int(horizontal_offset), 0)

            # On étale un peu les tirs
            time_offset = random.uniform(0.01, 0.02)  # Au lieu de (2..25)/1000
            time.sleep(time_offset)

        # Au lieu de (0.00005, 0.00010), on dort au moins 1–2 ms
        # => ~500 à 1000 itérations/sec max (au lieu de 10k+)
        time.sleep(random.uniform(0.001, 0.002))


threading.Thread(target=ControllerMode.main).start()
threading.Thread(target=LemonLoverF9).start()

class Ai992:
    try:
        app = QApplication(sys.argv + ['-platform', 'windows:darkmode=1'])
    except:
        app = QApplication(sys.argv)

    window = MyWindow()

    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    screen_x = int(screen_res_X / 2)
    screen_y = int(screen_res_Y / 2)
    screen = mss.mss()
    lock = threading.Lock()
    current_slot_selected = 1

    def __init__(self):
        global Fov_Size
        global Show_Debug
        global Show_FPS
        global Aim_Smooth
        global Max_Detections
        global Enable_Aim
        global Controller_On
        global Enable_TriggerBot
        global Keybind
        global Keybind2
        global Confidence
        global Auto_Fire_Fov_Size
        global Auto_Fire_Confidence
        global Auto_Fire_Keybind
        global Require_Keybind
        global Controller_Toggled
        global Aim_Bone
        global Box_type
        global CupMode_On
        global Enable_Flick_Bot
        global Flick_Scope_Sens
        global Flick_Delay
        global Flick_Cooldown
        global Flickbot_Keybind
        global Streamproof

        global Enable_Slots
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind

        global Fov_Size_Slot1
        global Fov_Size_Slot2
        global Fov_Size_Slot3
        global Fov_Size_Slot4
        global Fov_Size_Slot5

        global Enable_Aim_Slot1
        global Enable_Aim_Slot2
        global Enable_Aim_Slot3
        global Enable_Aim_Slot4
        global Enable_Aim_Slot5

        global Use_Model_Class
        global Img_Value
        global Model_FPS

        self.last_flick = time.time()
        self.start_time = time.time()

        # Instanciation YOLO
        self.default_model = YOLO("C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\Fortnite.pt")
        try:
            import torch
            if torch.cuda.is_available():
                self.default_model.to('cuda')
        except:
            pass

    # --------------------- Interpolations existantes --------------------------
    # ---------------- 4 que l'on garde (justification ci-dessous) ------------
    def catmull_rom_interpolation(self, p0, p1, p2, p3, t):
        """
        [1/4] Catmull-Rom: lisse, peu d'overshoot, bon compromis entre rapidité et réalisme.
        """
        return 0.5 * (
            (2 * p1) +
            (-p0 + p2) * t +
            (2*p0 - 5*p1 + 4*p2 - p3) * t * t +
            (-p0 + 3*p1 - 3*p2 + p3) * t * t * t
        )

    def hermite_interpolation(self, p0, p1, m0, m1, t):
        """
        [2/4] Hermite: flexible, permet un contrôle précis des tangentes => fluidité stable.
        """
        t2 = t * t
        t3 = t2 * t
        h00 = 2 * t3 - 3 * t2 + 1
        h10 = t3 - 2 * t2 + t
        h01 = -2 * t3 + 3 * t2
        h11 = t3 - t2
        return h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1

    def sine_interpolation(self, start, end, t):
        """
        [3/4] Sine: donne un mouvement plus “humain”, 
        on accélère / décélère avec un effet de sinusoïde.
        """
        return start + (end - start) * np.sin(t * np.pi / 2)

    # --------------------- Celles mises de côté (commentées) -----------------
    # def b_spline_interpolation(self, p0, p1, p2, p3, t):
    #     """
    #     EXCLUE : B-Spline peut parfois provoquer des 'overshoots' et 
    #     nécessite plus de points de contrôle pour être stable. 
    #     Moins performante en cas de rapidité.
    #     """
    #     ...

    # def bezier_interpolation(self, start, end, t):
    #     """
    #     EXCLUE : Utile pour de petites transitions, 
    #     mais peut être moins fluide avec de grandes distances
    #     et un paramétrage dynamique (on garde Hermite/Catmull).
    #     """
    #     ...

    # def exponential_interpolation(self, start, end, t, exponent=2):
    #     """
    #     EXCLUE : L'exponentiel a un démarrage lent + pic d'accélération 
    #     plus brutal => parfois des à-coups 
    #     en fin de trajectoire.
    #     """
    #     ...

    # def simple_linear_interpolation(...) { ... }
    #     EXCLUE : Linear est trop "robotique" et manquant de fluidité
    #     => engendre un mouvement trop direct.

    # -------------------- NOUVELLE interpolation optimisée --------------------
    def magic_smooth_interpolation(self, start, end, t):
        """
        [4/4] MagicSmooth : 
        - Combine un amortissement "smooth" + 
          légère sinusoïde interne pour un mouvement fluide.
        - Réduit grandement les saccades ou overshoot.
        - Rapide à calculer.
        """
        # On peut mixer un facteur sin() + un facteur t^2, 
        # tout en gardant un "control factor" pour la fluidité
        alpha = 0.7  # Contrôle l'amplitude du "sin" vs la parabole
        # Ex.: interpolation = portion sin() + portion polynomial
        sin_part = (end - start) * alpha * np.sin(t * np.pi / 2)
        quad_part = (end - start) * (1 - alpha) * (t * t)
        return start + sin_part + quad_part

    # -------------------------------------------------------------------------
    #                      FONCTION DE CLIC
    # -------------------------------------------------------------------------
    def left_click():
        if win32api.GetKeyState(win32con.VK_LBUTTON) in (-127, -128):
            pass
        else:
            if Require_Keybind:
                if win32api.GetAsyncKeyState(Auto_Fire_Keybind) < 0:
                    ctypes.windll.user32.mouse_event(0x0002)
                    time.sleep(random.uniform(0.0002, 0.00002))
                    ctypes.windll.user32.mouse_event(0x0004)
                    time.sleep(random.uniform(0.0002, 0.00002))
                else:
                    pass
            else:
                ctypes.windll.user32.mouse_event(0x0002)
                time.sleep(random.uniform(0.0002, 0.00002))
                ctypes.windll.user32.mouse_event(0x0004)
                time.sleep(random.uniform(0.0002, 0.00002))

    # -------------------------------------------------------------------------
    #                      TESTS D'ÉTAT DU BOT
    # -------------------------------------------------------------------------
    def is_aimbot_enabled():
        if not Enable_Slots:
            return Enable_Aim
        return {
            1: Enable_Aim_Slot1, 2: Enable_Aim_Slot2, 3: Enable_Aim_Slot3,
            4: Enable_Aim_Slot4, 5: Enable_Aim_Slot5,
        }.get(Ai992.current_slot_selected, Enable_Aim)

    def is_flickbot_enabled():
        return Enable_Flick_Bot

    def is_triggerbot_enabled():
        return Enable_TriggerBot

    def is_targeted():
        return True if win32api.GetAsyncKeyState(Keybind) < 0 else False

    def is_targeted2():
        if Keybind2 and win32api.GetAsyncKeyState(Keybind2) < 0:
            return True
        if Controller_On:
            if Controller_Toggled:
                return True
        else:
            return False

    def is_targeted3():
        return True if Flickbot_Keybind and win32api.GetAsyncKeyState(Flickbot_Keybind) < 0 else False

    def is_target_locked(x, y):
        threshold = Auto_Fire_Fov_Size
        return (Ai992.screen_x - threshold <= x <= Ai992.screen_x + threshold and
                Ai992.screen_y - threshold <= y <= Ai992.screen_y + threshold)

    # -------------------------------------------------------------------------
    #              FONCTION PRINCIPALE DE DÉPLACEMENT "move_crosshair"
    # -------------------------------------------------------------------------
    def move_crosshair(self, x, y, mvment=None):
        """
        Améliorations :
        - On réduit la randomisation pour éviter les sauts brusques.
        - On privilégie un smoothing plus subtil.
        """
        if not Ai992.is_targeted() and not Ai992.is_targeted2():
            return

        delta_x = (x - Ai992.screen_x)
        delta_y = (y - Ai992.screen_y)
        distance = np.linalg.norm((delta_x, delta_y))
        if distance == 0:
            return

        # Ajuster le smoothing pour plus de précision (et moins d'à-coups)
        smoothing = round(0.3 + (Aim_Smooth - 10) / 15.0, 2)  # Valeur réajustée

        move_x = (delta_x / distance) * pixel_increment * smoothing
        move_y = (delta_y / distance) * pixel_increment * smoothing

        move_x *= sensitivity
        move_y *= sensitivity

        # Réduction de l'aléatoire pour un suivi plus précis
        random_factor = max(0, randomness - 0.15)  # on enlève 0.15
        move_x += random.uniform(-random_factor, random_factor)
        move_y += random.uniform(-random_factor, random_factor)

        distance_clamped = min(1, distance / distance_to_scale)
        move_x *= distance_clamped
        move_y *= distance_clamped

        # Sélection d'interpolation
        t = distance / distance_to_scale
        if mvment == "Catmull":
            p0, p1, p2, p3 = 0, move_x, move_x * 1.2, move_x * 1.5
            move_x = self.catmull_rom_interpolation(p0, p1, p2, p3, t)
            p0, p1, p2, p3 = 0, move_y, move_y * 1.2, move_y * 1.5
            move_y = self.catmull_rom_interpolation(p0, p1, p2, p3, t)

        elif mvment == "Hermite":
            p0, p1 = 0, move_x
            m0, m1 = move_x * 1.2, move_x * 1.5
            move_x = self.hermite_interpolation(p0, p1, m0, m1, t)
            p0, p1 = 0, move_y
            m0, m1 = move_y * 1.2, move_y * 1.5
            move_y = self.hermite_interpolation(p0, p1, m0, m1, t)

        elif mvment == "Sine":
            move_x = self.sine_interpolation(0, move_x, t)
            move_y = self.sine_interpolation(0, move_y, t)

        elif mvment == "Magic":  # Notre nouvelle interpolation
            move_x = self.magic_smooth_interpolation(0, move_x, t)
            move_y = self.magic_smooth_interpolation(0, move_y, t)

        else:
            # Default: On retire la plupart des interpolations 
            # pour ne garder que "Catmull/Hermite/Sine/Magic".
            # => Si rien n'est choisi, on applique "Magic" par défaut.
            move_x = self.magic_smooth_interpolation(0, move_x, t)
            move_y = self.magic_smooth_interpolation(0, move_y, t)

        with Ai992.lock:
            Ai992.ii_.mi = MouseInput(round(move_x), round(move_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
            input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
            ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

    # -------------------------------------------------------------------------
    #           MOUVEMENT SILENCIEUX (FLICK BOT)
    # -------------------------------------------------------------------------
    def move_crosshair_silent(self, x, y):
        if not Ai992.is_targeted3():
            return

        flick_strength = round(0.8 + (Flick_Scope_Sens - 10) * (2.5 - 0.8) / (90 - 10), 2)
        delta_x = (x - Ai992.screen_x) * flick_strength
        delta_y = (y - Ai992.screen_y) * flick_strength

        Ai992.ii_.mi = MouseInput(round(delta_x), round(delta_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
        input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
        ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

        time.sleep(Flick_Delay)

        if win32api.GetKeyState(win32con.VK_LBUTTON) not in (-127, -128):
            ctypes.windll.user32.mouse_event(0x0002)
            time.sleep(random.uniform(0.00008, 0.00002))
            ctypes.windll.user32.mouse_event(0x0004)

        time.sleep(Flick_Delay / 4)

        with Ai992.lock:
            Ai992.ii_.mi = MouseInput(round(-delta_x), round(-delta_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
            input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
            ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

        self.last_flick = time.time()

    # -------------------------------------------------------------------------
    #           FPS TARGET
    # -------------------------------------------------------------------------
    def get_targ_fps():
        target_fps = Model_FPS
        frame_duration = 1.0 / target_fps
        return frame_duration

    # -------------------------------------------------------------------------
    #           START (BOUCLE PRINCIPALE)
    # -------------------------------------------------------------------------
    def start(self):
        kernel32 = ctypes.WinDLL('kernel32')
        user32 = ctypes.WinDLL('user32')
        hWnd = kernel32.GetConsoleWindow()
        SW_HIDE = 0

        # Affiche la fenêtre principale (MyWindow)
        Ai992.window.show()

        half_screen_width = ctypes.windll.user32.GetSystemMetrics(0) / 2
        half_screen_height = ctypes.windll.user32.GetSystemMetrics(1) / 2

        closest_detection = None
        detected_players = []

        # Si use_mss == 0, on utilise bettercam
        if use_mss == 0:
            camera = bettercam.create(output_idx=0, output_color="BGR", max_buffer_len=1)

        try:
            # Petite notification sonore (facultatif)
            winsound.PlaySound(r'C:\\Windows\\Media\\Windows Unlock.wav', winsound.SND_FILENAME)
        except:
            pass

        # Démarre (ou non) les overlays
        if dont_launch_overlays == 1:
            overlay = None
            fpswind = None
        else:
            overlay = DetectionBox()
            fpswind = FPSOverlay()
            overlay.show()

        # Cache la console si le fichier scos.txt existe
        try:
            open(rf"{current_directory}\extra\gfx\scos.txt", "r").read()
        except:
            user32.ShowWindow(hWnd, SW_HIDE)

        # Boucle principale
        while True:
            try:
                # Affiche ou masque l'overlay FPS
                if Show_FPS and fpswind:
                    fpswind.show()
                elif fpswind:
                    fpswind.hide()
            except:
                pass

            start_time = time.perf_counter()

            # Récupère l’état de certaines touches
            key_states = {
                "F1": win32api.GetKeyState(win32con.VK_F1),
                "F2": win32api.GetKeyState(win32con.VK_F2),
                "LEFT": win32api.GetKeyState(win32con.VK_LEFT)  # Touche INS ou LEFT selon config
            }

            # Exemple : si la touche LEFT est pressée => toggle du menu
            if key_states["LEFT"] in (-127, -128):
                try:
                    Ai992.window.toggle_menu_visibility()
                except:
                    time.sleep(0.15)
                    Ai992.window.toggle_menu_visibility()
                time.sleep(0.15)

            if not CupMode_On:
                # Touche F1 => Active / désactive l'aimbot
                if key_states["F1"] in (-127, -128):
                    time.sleep(0.25)
                    my_window1z = MyWindow()
                    my_window1z.toggle_checkbox1(True)

                # Touche F2 => Ferme le programme
                if key_states["F2"] in (-127, -128):
                    time.sleep(0.25)
                    try:
                        console_window = ctypes.windll.kernel32.GetConsoleWindow()
                        ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
                    except:
                        try:
                            sys.exit()
                        except:
                            os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

            # Gère le FOV en fonction des slots d’arme (si Enable_Slots)
            if not Enable_Slots:
                self.Fov_Size = Fov_Size
            else:
                slot_keys = [Slot1_Keybind, Slot2_Keybind, Slot3_Keybind,
                            Slot4_Keybind, Slot5_Keybind, Slot6_Keybind]
                slot_fov_sizes = [Fov_Size_Slot1, Fov_Size_Slot2, Fov_Size_Slot3,
                                Fov_Size_Slot4, Fov_Size_Slot5, 10]  # slot6 = pickaxe = 10
                for idx, key in enumerate(slot_keys):
                    if key is not None and win32api.GetAsyncKeyState(key) < 0:
                        Ai992.current_slot_selected = idx + 1
                        break
                self.Fov_Size = slot_fov_sizes[Ai992.current_slot_selected - 1]

            # Capture d’écran (region = Fov_Size)
            if use_mss == 0:
                left = int((screen_res_X - self.Fov_Size) // 2)
                top = int((screen_res_Y - self.Fov_Size) // 2)
                right = left + self.Fov_Size
                bottom = top + self.Fov_Size
                detection_box = (left, top, right, bottom)

                frame = camera.grab(region=detection_box)
                if frame is None:
                    continue

                # Conversion en numpy array
                frame = np.asarray(frame)[..., :3]
                frame = np.ascontiguousarray(frame)

                # Masque basique (exemple)
                mask = np.ones((self.Fov_Size, self.Fov_Size), dtype=np.uint8)
                mask[self.Fov_Size // 2:, : self.Fov_Size // 4] = 0
                frame = cv2.bitwise_and(frame, frame, mask=mask)

                region_left, region_top = left, top
            else:
                # mss
                detection_box = {
                    'left': int(half_screen_width - self.Fov_Size / 2),
                    'top': int(half_screen_height - self.Fov_Size / 2),
                    'width': int(self.Fov_Size),
                    'height': int(self.Fov_Size)
                }
                sct_img = Ai992.screen.grab(detection_box)
                frame = np.array(sct_img)[..., :3]
                region_left, region_top = detection_box['left'], detection_box['top']

            # Masque circulaire (si hide_masks=0)
            if hide_masks == 0:
                frame = np.ascontiguousarray(frame)
                mask = np.zeros_like(frame, dtype=np.uint8)
                center_x, center_y = self.Fov_Size // 2, self.Fov_Size // 2
                radius = self.Fov_Size // 2
                cv2.ellipse(
                    mask, (center_x, center_y),
                    (radius - 2, radius - 2),
                    0, 0, 360, (255, 255, 255),
                    thickness=cv2.FILLED
                )
                if mask.ndim == 3:
                    mask = mask[..., 0]
                frame = cv2.bitwise_and(frame, frame, mask=mask)

            # Lancement de l’inférence
            confi = Confidence / 100
            imgsz_value = int(Img_Value) if self.default_model else 640
            results = Ai992.window.modell(
                frame,
                conf=confi,
                iou=0.7,
                imgsz=imgsz_value,
                max_det=Max_Detections,
                retina_masks=True,
                verbose=False,
                classes=0 if Use_Model_Class else None
            )

            # Recherche de la détection la plus proche du centre
            if len(results[0].boxes.xyxy) != 0:
                least_crosshair_dist = False
                for detection, conf_ in zip(
                    results[0].boxes.xyxy.tolist(),
                    results[0].boxes.conf.tolist()
                ):
                    x1, y1, x2, y2 = map(int, detection)
                    height = y2 - y1

                    # Ajuste le point de visée selon Aim_Bone
                    if Aim_Bone == "Head":
                        relative_head_X = (x1 + x2) // 2
                        relative_head_Y = int((y1 + y2) / 2 - height / 2.5)
                    elif Aim_Bone == "Neck":
                        relative_head_X = (x1 + x2) // 2
                        relative_head_Y = int((y1 + y2) / 2 - height / 3)
                    else:  # Body
                        relative_head_X = (x1 + x2) // 2
                        relative_head_Y = int((y1 + y2) / 2 - height / 5)

                    # Distance par rapport au centre du FOV
                    crosshair_dist = math.dist(
                        (relative_head_X, relative_head_Y),
                        (self.Fov_Size / 2, self.Fov_Size / 2)
                    )

                    if not least_crosshair_dist or crosshair_dist < least_crosshair_dist:
                        least_crosshair_dist = crosshair_dist
                        closest_detection = {
                            "x1y1": (x1, y1),
                            "x2y2": (x2, y2),
                            "relative_head_X": relative_head_X,
                            "relative_head_Y": relative_head_Y,
                            "conf": conf_
                        }

                    # Pour l’overlay (ESP)
                    if Show_Detections or Show_Aimline:
                        detected_players.append({
                            'x1': x1, 'y1': y1,
                            'x2': x2, 'y2': y2,
                            'head1': closest_detection["relative_head_X"] if closest_detection else 0,
                            'head2': closest_detection["relative_head_Y"] if closest_detection else 0
                        })

                    # Mode debug => on affiche rectangles dans la frame OpenCV
                    if Show_Debug:
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 255), 1)
                        cv2.putText(
                            frame, f"{int(conf_ * 100)}%",
                            (x1, y1), cv2.FONT_HERSHEY_DUPLEX,
                            0.5, (1, 1, 255), 1
                        )

                # Une fois la plus proche trouvée, on applique l’aimbot
                if closest_detection:
                    absolute_head_X = closest_detection["relative_head_X"] + region_left
                    absolute_head_Y = closest_detection["relative_head_Y"] + region_top

                    if Show_Debug:
                        cv2.circle(
                            frame,
                            (closest_detection["relative_head_X"], closest_detection["relative_head_Y"]),
                            2, (0, 0, 255), -1
                        )
                        cv2.line(
                            frame,
                            (closest_detection["relative_head_X"], closest_detection["relative_head_Y"]),
                            (self.Fov_Size // 2, self.Fov_Size // 2),
                            (255, 255, 255), 1
                        )

                    # Triggerbot
                    if Ai992.is_triggerbot_enabled() and Ai992.is_target_locked(absolute_head_X, absolute_head_Y):
                        tbconfi = Auto_Fire_Confidence / 100
                        if closest_detection["conf"] >= tbconfi:
                            threading.Thread(target=Ai992.left_click, daemon=True).start()

                    # Aimbot
                    if Ai992.is_aimbot_enabled():
                        threading.Thread(
                            target=Ai992.move_crosshair,
                            args=(self, absolute_head_X, absolute_head_Y, Smoothing_Type),
                            daemon=True
                        ).start()

                    # Flickbot
                    if Ai992.is_flickbot_enabled():
                        time_since_last_flick = time.time() - self.last_flick
                        if time_since_last_flick > Flick_Cooldown:
                            threading.Thread(
                                target=Ai992.move_crosshair_silent,
                                args=(self, absolute_head_X, absolute_head_Y),
                                daemon=True
                            ).start()

            # Mise à jour de l’overlay (ESP) si besoin
            if (Show_Detections or Show_Aimline) and fpswind and overlay:
                fpswind.enemies = len(detected_players)
                overlay.update_detected_players(detected_players)
                detected_players = []

            # Contrôle de la cadence (Model_FPS)
            elapsed_time = time.perf_counter() - start_time
            frame_duration = Ai992.get_targ_fps()  # ~ 1.0 / Model_FPS
            time_to_sleep = max(0, frame_duration - elapsed_time)
            if time_to_sleep > 0:
                time.sleep(time_to_sleep)

            # Affiche les FPS sur l’overlay
            if Show_FPS and fpswind:
                fpswind.fps = int(1.0 / (time.perf_counter() - start_time))

            # Mode debug => on affiche la frame avec OpenCV
            if Show_Debug and not CupMode_On:
                cv2.putText(frame,
                            f"FPS: {int(1.0 / (time.perf_counter() - start_time))}",
                            (5, 20),
                            cv2.FONT_HERSHEY_COMPLEX_SMALL,
                            1, (155, 155, 155), 1)
                cv2.imshow(random_caption1, frame)
                cv2.waitKey(1)

            # Process Qt events (pour l'UI)
            Ai992.app.processEvents()


class Encryption:
    @staticmethod
    def encrypt_string(plain_text, key, iv):
        plain_text = pad(plain_text.encode(), 16)
        aes_instance = AES.new(key, AES.MODE_CBC, iv)
        encrypted_text = aes_instance.encrypt(plain_text)
        return binascii.hexlify(encrypted_text).decode()

    @staticmethod
    def decrypt_string(cipher_text, key, iv):
        cipher_text = binascii.unhexlify(cipher_text)
        aes_instance = AES.new(key, AES.MODE_CBC, iv)
        decrypted_text = aes_instance.decrypt(cipher_text)
        return unpad(decrypted_text, 16).decode()

    @staticmethod
    def encrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).digest()[:32]
            _iv = SHA256.new(iv.encode()).digest()[:16]
            return Encryption.encrypt_string(message, _key, _iv)
        except Exception as e:
            print(f"Encryption failed: {e}")
            os._exit(1)

    @staticmethod
    def decrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).digest()[:32]
            _iv = SHA256.new(iv.encode()).digest()[:16]
            return Encryption.decrypt_string(message, _key, _iv)
        except Exception as e:
            print(f"Decryption failed: {e}")
            os._exit(1)

class PyProtect():
    def main():

        def getip():
            ip = "Not Found"
            try:
                ip = requests.get("https://api.ipify.org").text
            except:
                pass
            return ip

        Current_Version = "1.00"
        ip = getip()
        serveruser = os.getenv("UserName")
        pc_name = os.getenv("COMPUTERNAME")

        try:
            LKey2 = open(rf"{license_file_path}", "r") # // KEY
            XFC2 = LKey2.read()
            LKey2.close()
        except:
            XFC2 = "N/A"
        try:
            DirLocation = os.path.dirname(os.path.realpath(__file__))
        except:
            DirLocation = "N/A"

        def get_blacklisted_process_name():
            for process in psutil.process_iter(['pid', 'name']):
                for name in BLACKLISTED_WINDOW_NAMES:
                    if name.lower() in process.info['name'].lower():
                        return process.info['name'], process.info['pid']
            return None, None

        def block_bad_processes():
            blacklisted_process_name, blacklisted_pid = get_blacklisted_process_name()
            if blacklisted_process_name:
                try:
                    process = psutil.Process(blacklisted_pid)
                    process.terminate()
                    pass
                except:
                    print(f"\n[+] Nizzware AI\n[+] Blacklisted process; {blacklisted_process_name}")
                    time.sleep(1)
                    exit(1)
                    os.system('taskkill /f /fi "imagename eq cmd.exe" >nul 2>&1')
                    os.system('taskkill /f /fi "imagename eq python.exe" >nul 2>&1')

        def block_debuggers():
            while True:
                time.sleep(5)
                for proc in psutil.process_iter():
                    if any(procstr in proc.name().lower() for procstr in BLACKLISTED_PROGRAMS):
                        try:
                            try:
                                proc.kill()
                                proc.kill()
                                proc.kill()
                                proc.kill()
                                proc.kill()
                            except:
                                os.system('taskkill /f /fi "imagename eq cmd.exe" >nul 2>&1')
                                os.system('taskkill /f /fi "imagename eq python.exe" >nul 2>&1')
                        except(psutil.NoSuchProcess, psutil.AccessDenied):
                            pass

        threading.Thread(target=block_debuggers).start()
        threading.Thread(target=block_bad_processes).start()
        #threading.Thread(target=vtdetect).start()

    main()

class StatusIndicator(QWidget):
    def __init__(self, color, parent=None):
        super().__init__(parent)
        self.color = color
        self.setFixedSize(16, 16)  # Taille augmentée
        self._opacity = 1.0
        
        # Animation de pulsation
        self.animation = QPropertyAnimation(self, b"opacity")
        self.animation.setDuration(1500)
        self.animation.setLoopCount(-1)
        self.animation.setStartValue(1.0)
        self.animation.setEndValue(0.3)
        self.animation.start()

    def setOpacity(self, value):
        self._opacity = value
        self.update()

    def getOpacity(self):
        return self._opacity

    opacity = pyqtProperty(float, getOpacity, setOpacity)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setOpacity(self._opacity)
        painter.setBrush(QBrush(self.color))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(2, 2, 12, 12)

class KeyAuthLogin(QWidget):
    def __init__(self):
            super().__init__()
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setAttribute(Qt.WA_TranslucentBackground)
            
            # App credentials
            self.name = "AiAim"  # quote_plus("Your_App_Name")
            self.ownerid = "9aGBHLaWqt"  # Replace with your owner ID
            self.version = "1.0"
            self.session_id = None
            
            # Get HWID
            self.hwid = get_hwid()
            if not self.hwid:
                QMessageBox.critical(self, "Error", "Failed to get hardware ID")
                sys.exit(1)
                
            # License file path
            self.license_path = license_file_path
            
            # Load saved license
            self.load_saved_license()
            self.initUI()
            
            # Auto-login if saved key exists
            if hasattr(self, 'saved_key') and self.saved_key:
                self.key_input.setEnabled(False)
                self.login_btn.setEnabled(False)
                self.status_label.setText("Loading saved key...")
                self.status_label.setStyleSheet("color: orange;")
                QTimer.singleShot(100, self.auto_login)
                

    def auto_login(self):
            print("Performing auto-login...")
            if hasattr(self, 'saved_key') and self.saved_key:
                print(f"Auto-login with key: {self.saved_key}")
                self.key_input.setText(self.saved_key)
                self.login()
            print("Auto-login completed.")

    def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(QColor(theme_color))
            painter.setPen(Qt.NoPen)
            rect = QRect(0, 0, self.width(), self.height())
            painter.drawRoundedRect(rect, 10, 10)

    def initUI(self):
            try:
                self.setFixedSize(350, 400)
                
                # Configuration fenêtre avec une marge pour éviter le background noir
                self.setWindowFlags(Qt.FramelessWindowHint)
                self.setAttribute(Qt.WA_TranslucentBackground)
                
                main_layout = QVBoxLayout()
                main_layout.setContentsMargins(10, 10, 10, 10)  # Marge pour éviter le background noir
                
                # Container principal avec fond et coins arrondis
                main_container = QWidget()
                main_container.setStyleSheet("""
                    QWidget {
                        background-color: cc0000;
                        border-radius: 15px;
                    }
                """)
                
                layout = QVBoxLayout(main_container)
                layout.setContentsMargins(0, 0, 0, 0)
                layout.setSpacing(0)
                
                # Barre de titre
                title_container = QWidget()
                title_container.setFixedHeight(50)
                title_container.setStyleSheet("""
                    QWidget {
                        background-color: cc0000;
                        border-top-left-radius: 15px;
                        border-top-right-radius: 15px;
                    }
                """)
                title_layout = QHBoxLayout(title_container)
                title_layout.setContentsMargins(5, 0, 10, 0)
                
                title_label = QLabel('IRIS CORP AI')
                title_label.setStyleSheet("""
                    color: white; 
                    font-size: 20px; 
                    font-weight: bold; 
                    font-family: 'Segoe UI';
                """)
                
                # Boutons de contrôle
                buttons_container = QWidget()
                buttons_layout = QHBoxLayout(buttons_container)
                buttons_layout.setContentsMargins(0, 0, 0, 0)
                buttons_layout.setSpacing(5)
                
                minimize_btn = QPushButton(qta.icon('fa5s.window-minimize', color='white'), "")
                minimize_btn.setFixedSize(24, 24)
                minimize_btn.clicked.connect(self.showMinimized)
                minimize_btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        border: none;
                        border-radius: 12px;
                        padding-bottom: 4px;
                    }
                    QPushButton:hover {
                        background: rgba(255, 255, 255, 0.1);
                    }
                """)
                
                close_btn = QPushButton(qta.icon('fa5s.times', color='white'), "")
                close_btn.setFixedSize(24, 24)
                close_btn.clicked.connect(self.close)
                close_btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        border: none;
                        border-radius: 12px;
                    }
                    QPushButton:hover {
                        background: rgba(255, 0, 0, 0.15);
                    }
                """)
                
                buttons_layout.addWidget(minimize_btn)
                buttons_layout.addWidget(close_btn)
                
                title_layout.addWidget(title_label)
                title_layout.addStretch()
                title_layout.addWidget(buttons_container)
                
                layout.addWidget(title_container)
                
                # Content container
                content = QWidget()
                content_layout = QVBoxLayout(content)
                content_layout.setContentsMargins(5, 0, 5, 0)
                content_layout.setSpacing(25)  # Augmenté pour plus d'espace
                
                # Image avec un container pour éviter le chevauchement
                image_container = QWidget()
                image_container.setFixedHeight(150)  # Plus grand pour l'image
                image_layout = QVBoxLayout(image_container)
                image_layout.setContentsMargins(0, 0, 0, 0)
                
                self.image_label = QLabel()
                self.image_label.setAlignment(Qt.AlignCenter)
                self.image_label.setStyleSheet("background: transparent;")
                image_layout.addWidget(self.image_label)
                content_layout.addWidget(image_container)
                
                # Status et Version sur la même ligne
                status_version_container = QWidget()
                status_version_layout = QHBoxLayout(status_version_container)
                status_version_layout.setContentsMargins(0, 0, 0, 0)
                
                # Status avec taille augmentée
                status_widget = QWidget()
                status_layout = QHBoxLayout(status_widget)
                status_layout.setContentsMargins(0, 0, 0, 0)
                
                self.status_indicator = StatusIndicator(QColor("#2ecc71"))
                self.status_label = QLabel("Online")
                self.status_label.setStyleSheet("""
                    QLabel {
                        color: rgba(255, 255, 255, 0.9);
                        font-size: 16px;
                        font-family: 'Segoe UI';
                        font-weight: 600;
                    }
                """)
                
                status_layout.addWidget(self.status_indicator, alignment=Qt.AlignVCenter)
                status_layout.addWidget(self.status_label)
                status_version_layout.addWidget(status_widget)
                
                # Version à droite
                self.version_label = QLabel()
                self.version_label.setStyleSheet("""
                    QLabel {
                        color: rgba(255, 255, 255, 0.5);
                        font-size: 14px;
                        font-family: 'Segoe UI';
                    }
                """)
                status_version_layout.addStretch()
                status_version_layout.addWidget(self.version_label)
                
                content_layout.addWidget(status_version_container)
                
                # Input avec style amélioré
                self.key_input = QLineEdit()
                self.key_input.setPlaceholderText("Enter license key...")
                self.key_input.setAlignment(Qt.AlignCenter)
                self.key_input.setFixedHeight(50)
                self.key_input.setStyleSheet("""
                    QLineEdit {
                        padding: 10px 15px;
                        background: rgba(255, 255, 255, 0.07);
                        border: 2px solid rgba(255, 255, 255, 0.05);
                        border-radius: 12px;
                        color: white;
                        font-size: 15px;
                        font-family: 'Segoe UI';
                        font-weight: 500;
                    }
                    QLineEdit:focus {
                        background: rgba(255, 255, 255, 0.1);
                        border: 2px solid rgba(33, 150, 243, 0.5);
                    }
                    QLineEdit::placeholder {
                        color: rgba(255, 255, 255, 0.4);
                    }
                """)
                content_layout.addWidget(self.key_input)
                
                # Login button avec effet avancé
                self.login_btn = QPushButton("Login")
                self.login_btn.setFixedHeight(50)
                self.login_btn.setCursor(Qt.PointingHandCursor)
                self.login_btn.setStyleSheet("""
                    QPushButton {
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2196F3, stop:1 #1976D2);
                        border: none;
                        border-radius: 12px;
                        color: white;
                        font-size: 20px;
                        font-weight: bold;
                        font-family: 'Segoe UI';
                        padding: 5px;
                    }
                    QPushButton:hover {
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1E88E5, stop:1 #1565C0);
                        border: 2px solid rgba(255, 255, 255, 0.1);
                    }
                    QPushButton:pressed {
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1976D2, stop:1 #0D47A1);
                        padding: 7px;
                    }
                """)
                self.login_btn.clicked.connect(self.login)
                content_layout.addWidget(self.login_btn)
                
                content_layout.addStretch()
                layout.addWidget(content)
                
                main_layout.addWidget(main_container)
                self.setLayout(main_layout)
                
                # Charger la configuration
                self.load_config()
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to initialize UI: {str(e)}")
                sys.exit(1)

    def load_config(self):
            try:
                print("Début du chargement de la configuration...")
                response = requests.get('https://raw.githubusercontent.com/famito/AIMIA/refs/heads/main/login.json')
                print(f"Status code de la réponse JSON: {response.status_code}")
                config = response.json()
                
                # Extraction des données du config
                login_data = config.get('login-page', [])
                print(f"Données login_data: {login_data}")
                if not login_data:
                    print("Error: No login-page data found in config")
                    return
                    
                # Chargement de l'image
                image_url = login_data[0].get('ImageUrl')
                print(f"URL de l'image: {image_url}")
                
                if image_url:
                    try:
                        print(f"Tentative de téléchargement de l'image depuis: {image_url}")
                        headers = {'User-Agent': 'Mozilla/5.0'}
                        image_response = requests.get(image_url, stream=True, headers=headers)
                        print(f"Status code de la réponse image: {image_response.status_code}")
                        image_response.raise_for_status()
                        
                        image = QImage()
                        image_data = QByteArray(image_response.content)
                        print(f"Taille des données image: {len(image_data)} bytes")
                        
                        if image.loadFromData(image_data):
                            pixmap = QPixmap.fromImage(image)
                            target_width = 310
                            target_height = int(target_width * 9/16)
                            scaled_pixmap = pixmap.scaled(target_width, target_height, 
                                                        Qt.KeepAspectRatio, 
                                                        Qt.SmoothTransformation)
                            self.image_label.setPixmap(scaled_pixmap)
                            print("Image chargée avec succès via QImage")
                        else:
                            print("Échec du chargement de l'image via QImage")
                            
                    except requests.exceptions.RequestException as e:
                        print(f"Erreur lors du téléchargement de l'image: {str(e)}")
                    except Exception as e:
                        print(f"Erreur lors du traitement de l'image: {str(e)}")
                
                # Mise à jour du statut initial
                initial_status = login_data[0].get('status', 'online')
                self.update_status(initial_status, login_data)
                
                # Mise à jour de la version
                version = login_data[0].get('version', '1.0')
                self.version_label.setText(f"v{version}")
                
            except Exception as e:
                print(f"Error loading config: {str(e)}")

    def update_status(self, status_id, config_data):
            try:
                # Définition des couleurs pour chaque statut
                status_colors = {
                    "online": QColor("#2ecc71"),    # Vert
                    "offline": QColor("#e74c3c"),   # Rouge
                    "updating": QColor("#f1c40f"),  # Jaune
                    "custom": QColor("#9b59b6")     # Violet pour "In development"
                }
                
                # Recherche des informations de statut
                status_info = next(
                    (item for item in config_data if item.get('id') == status_id),
                    None
                )
                
                if status_info:
                    # Mise à jour de la couleur
                    self.status_indicator.color = status_colors.get(status_id, QColor("#2ecc71"))
                    self.status_indicator.update()
                    
                    # Mise à jour du label
                    self.status_label.setText(status_info['label'])
                    print(f"Status updated to: {status_info['label']}")
                else:
                    print(f"Status {status_id} not found in config")
            except Exception as e:
                print(f"Error updating status: {str(e)}")

    def check_admin(self):
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if not is_admin:
                self.status_label.setText('Running without admin privileges')
        except:
            self.status_label.setText('Could not check admin status')

    def initialize_auth(self):
        print("Initializing authentication with KeyAuth...")
        try:
            conn = http.client.HTTPSConnection("keyauth.win", timeout=10)
            params = f"type=init&ver=1.0&name={self.name}&ownerid={self.ownerid}"
            print(f"Auth parameters: {params}")
            
            conn.request("GET", f"/api/1.2/?{params}")
            res = conn.getresponse()
            data = json.loads(res.read().decode())
            print(f"Auth response: {data}")
            
            if data.get("success"):
                self.session_id = data.get("sessionid")
                print(f"Session ID obtained: {self.session_id}")
                return True
            else:
                error_message = data.get('message', 'Unknown error')
                self.status_label.setText(f"Initialization failed: {error_message}")
                print(f"Initialization failed: {error_message}")
                return False
        except Exception as e:
            print(f"Connection error: {str(e)}")
            self.status_label.setText(f"Connection error: {str(e)}")
            return False
        finally:
            try:
                conn.close()
                print("Connection closed.")
            except Exception as e:
                print(f"Error closing connection: {str(e)}")

    def login(self):
        print("Starting login process...")
        if self.key_input.isEnabled():
            self.key_input.setEnabled(False)
            self.login_btn.setEnabled(False)

        self.status_label.setText("Verifying license...")
        self.status_label.setStyleSheet("color: orange;")
        print("License verification initiated.")
        
        QTimer.singleShot(0, self._process_login)

    def _process_login(self):
        print("Processing login...")
        try:
            key = self.key_input.text().strip()
            print(f"License key provided: {key}")

            if not key:
                print("No license key entered.")
                self.status_label.setText("Please enter a license key")
                self.key_input.setEnabled(True)
                self.login_btn.setEnabled(True)
                return

            if not self.initialize_auth():
                print("Authentication initialization failed.")
                self.key_input.setEnabled(True)
                self.login_btn.setEnabled(True)
                return

            conn = http.client.HTTPSConnection("keyauth.win", timeout=10)
            params = (
                f"type=license&key={key}&sessionid={self.session_id}&"
                f"name={self.name}&ownerid={self.ownerid}&hwid={self.hwid}"
            )
            print(f"License verification parameters: {params}")
            
            conn.request("GET", f"/api/1.2/?{params}")
            res = conn.getresponse()
            data = json.loads(res.read().decode())
            print(f"License verification response: {data}")

            if data.get("success"):
                self.status_label.setText("Login successful!")
                self.status_label.setStyleSheet("color: green;")
                print("Login successful.")
                self.save_license(key)
                QTimer.singleShot(500, self.launch_main_app)
            else:
                error_msg = data.get("message", "Invalid key")
                print(f"Login failed: {error_msg}")
                if "hwid" in error_msg.lower():
                    error_msg = "License already in use on another device"
                elif "invalid" in error_msg.lower():
                    error_msg = "Invalid license key"
                
                self.status_label.setText(error_msg)
                self.status_label.setStyleSheet("color: red;")
                
                if os.path.exists(self.license_path):
                    os.remove(self.license_path)
                    print(f"License file deleted: {self.license_path}")
                
                self.key_input.setEnabled(True)
                self.login_btn.setEnabled(True)

        except Exception as e:
            print(f"Login error: {str(e)}")
            self.status_label.setText(f"Login error: {str(e)}")
            self.key_input.setEnabled(True)
            self.login_btn.setEnabled(True)
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                    print("Connection closed after login process.")
                except Exception as e:
                    print(f"Error closing connection: {str(e)}")

    def load_saved_license(self):
        print("Loading saved license...")
        try:
            if os.path.exists(self.license_path):
                with open(self.license_path, 'r') as f:
                    saved_key = f.read().strip()
                    print(f"Saved license key found: {saved_key}")
                    if saved_key:
                        self.saved_key = saved_key
                        return
        except Exception as e:
            print(f"Error loading saved license: {str(e)}")
        self.saved_key = None
        print("No saved license found.")

    def save_license(self, key):
        print(f"Saving license key: {key}")
        try:
            os.makedirs(os.path.dirname(self.license_path), exist_ok=True)
            with open(self.license_path, 'w') as f:
                f.write(key)
            print("License key saved successfully.")
        except Exception as e:
            print(f"Error saving license: {str(e)}")
            self.status_label.setText(f"Warning: Could not save license: {str(e)}")

    def launch_main_app(self):
        print("Launching main application...")
        try:
            self.close()

            global xxxx
            xxxx = Ai992()
            xxxx.start()
            print("Main application launched.")
        except Exception as e:
            print(f"Failed to launch application: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to launch application: {str(e)}")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragPos = event.globalPos()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            self.move(self.pos() + event.globalPos() - self.dragPos)
            self.dragPos = event.globalPos()

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False
    

# webhook_url = ""
# pc_name = socket.gethostname()
# serveruser = os.getlogin()
# DirLocation = os.getcwd()


# try:
#     ip = requests.get("https://api.ipify.org").text  # This gets the public IP from ipify's API
# except requests.RequestException:
#     ip = "Could not retrieve IP"

# embed = {
#     "description": f"```[PC-USER] {serveruser} / {pc_name}\n"
#                    # f"[IP] {ip}\n"
#                    f"[TIME] {current_time}\n"
#                    f"[DIRECTORY] {DirLocation}\n```",
#     "title": "**[System Info]**"
# }
# data = {
#     "content": "\n",
#     "embeds": [
#         embed
#     ],
# }


# result = requests.post(webhook_url, json=data)
# username = os.getlogin()

def main():
    os.system("cls")
    # print("[+] Nizzware AI\n[+] Starting...")
    print("app started")
    #PyProtect()
    setup_initial_files()
    #LoginForm()
    app = QApplication(sys.argv)
    # app.setWindowIcon(QIcon(icon_path))
    window = KeyAuthLogin()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()