from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import importlib.util
import time
import subprocess
import psutil
from threading import Lock
import traceback

# Configuration des chemins
current_directory = os.path.dirname(os.path.abspath(__file__))
main_path = os.path.join(current_directory, "extra", "main.py")
log_path = os.path.join(current_directory, "logs")

# Configuration du logging
os.makedirs(log_path, exist_ok=True)
logging.basicConfig(
    filename=os.path.join(log_path, 'auth_server.log'),
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
CORS(app)

# Global lock for KeyAuth instances
auth_lock = Lock()
keyauth_instance = None
main_process = None

def kill_existing_processes():
    try:
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # Chercher les process Python qui exécutent main.py
                if proc.name() in ['python.exe', 'pythonw.exe']:
                    cmdline = proc.cmdline()
                    if any('main.py' in cmd for cmd in cmdline):
                        proc.kill()
                        logging.info(f"Killed existing process: {proc.pid}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except Exception as e:
        logging.error(f"Error killing processes: {str(e)}")

def get_keyauth():
    global keyauth_instance
    with auth_lock:
        if not keyauth_instance:
            try:
                spec = importlib.util.spec_from_file_location("main", main_path)
                main_module = importlib.util.module_from_spec(spec)
                sys.modules["main"] = main_module
                spec.loader.exec_module(main_module)
                
                keyauth_instance = main_module.api(
                    name="AiAim",
                    ownerid="9aGBHLaWqt",
                    secret="06934b55e622cb1f0f5b57f664bacdafa36c8038f0fcd19fb09f68a989205f33", 
                    version="1.0",
                    hash_to_check = main_module.calculate_checksum()
                )
                keyauth_instance.init()
            except Exception as e:
                logging.error(f"Failed to initialize KeyAuth: {str(e)}")
                return None
                
        return keyauth_instance


@app.route('/status')
def status():
    try:
        key_path = os.path.join(current_directory, 'extra', 'gfx', 'key.txt')
        key_exists = os.path.exists(key_path)
        
        try:
            auth = get_keyauth()
            if not auth:
                return jsonify({
                    "status": "error",
                    "message": "Failed to initialize KeyAuth instance",
                    "details": logging.getLogger().handlers[0].baseFilename
                }), 500
        except Exception as ke:
            return jsonify({
                "status": "error",
                "message": f"KeyAuth error: {str(ke)}",
                "path": main_path, 
                "current_dir": current_directory
            }), 500
            
        return jsonify({
            "status": "ready",
            "authenticated": key_exists
        })
            
    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": str(e),
            "traceback": traceback.format_exc() 
        }), 500

@app.route('/auth', methods=['POST'])
def auth():
    global main_process
    try:
        key = request.json.get('key')
        if not key:
            return jsonify({
                "success": False,
                "message": "No key provided"
            }), 400

        logging.info("Attempting to verify license key")
        logging.info(f"Current directory: {current_directory}")
        logging.info(f"Main path: {main_path}")
        
        try:
            auth = get_keyauth()
            if not auth:
                return jsonify({
                    "success": False,
                    "message": "Failed to initialize KeyAuth",
                    "path": main_path
                }), 500
                
            # Valider la licence
            auth.license(key)
            
            # Sauvegarder la clé
            key_path = os.path.join(current_directory, 'extra', 'gfx', 'key.txt')
            os.makedirs(os.path.dirname(key_path), exist_ok=True)
            with open(key_path, 'w') as f:
                f.write(key)
            
            # Tuer les processus existants
            kill_existing_processes()
            
            # Vérifier que main.py existe
            if not os.path.exists(main_path):
                return jsonify({
                    "success": False,
                    "message": "main.py not found",
                    "path": main_path
                }), 500
                
            # Démarrer main.py sans console
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
            main_process = subprocess.Popen(
                ['pythonw', main_path], 
                startupinfo=startupinfo,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            
            logging.info("Main application started successfully")
            return jsonify({
                "success": True,
                "message": "License validated and application started"
            })
            
        except Exception as ke:
            logging.error(f"KeyAuth error: {str(ke)}")
            return jsonify({
                "success": False,
                "message": str(ke),
                "traceback": traceback.format_exc()
            }), 400
            
    except Exception as e:
        logging.error(f"Auth failed: {str(e)}")
        return jsonify({
            "success": False,
            "message": str(e),
            "traceback": traceback.format_exc()
        }), 500

def wait_for_port_available(port, timeout=30):
    import socket
    start_time = time.time()
    while True:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', port))
                return True
        except socket.error:
            if time.time() - start_time > timeout:
                return False
            time.sleep(1)

if __name__ == '__main__':
    try:
        kill_existing_processes()
        
        port = 5789
        if not wait_for_port_available(port):
            logging.error(f"Port {port} is not available after timeout")
            sys.exit(1)
            
        logging.info("Starting authentication server...")
        app.run(
            host='127.0.0.1',
            port=port, 
            threaded=True
        )
        
    except Exception as e:
        logging.error(f"Server failed to start: {e}")
        sys.exit(1)