from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging

# Configuration des chemins
current_directory = os.path.dirname(os.path.abspath(__file__))
extra_path = os.path.join(current_directory, "extra")
log_path = os.path.join(current_directory, "logs")

# Créer le dossier logs s'il n'existe pas
os.makedirs(log_path, exist_ok=True)

# Configuration du logging
logging.basicConfig(
    filename=os.path.join(log_path, 'auth_server.log'),
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Ajouter le dossier extra au path Python
sys.path.append(extra_path)

app = Flask(__name__)
CORS(app)

# Import de main.py
try:
    from main import api, LoginForm
    logging.info("Successfully imported main.py modules")
except Exception as e:
    logging.error(f"Failed to import main.py: {str(e)}")
    sys.exit(1)

@app.route('/status', methods=['GET'])
def status():
    try:
        key_path = os.path.join(extra_path, 'gfx', 'key.txt')
        status_response = {
            "status": "ready",
            "authenticated": os.path.exists(key_path)
        }
        logging.info(f"Status check: {status_response}")
        return jsonify(status_response)
    except Exception as e:
        logging.error(f"Status check failed: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/auth', methods=['POST'])
def auth():
    try:
        data = request.get_json()
        if not data or 'key' not in data:
            return jsonify({"success": False, "message": "No key provided"}), 400

        key = data['key']
        logging.info("Attempting authentication with provided key")

        # Initialisation de KeyAuth
        auth_instance = api(
            name="AiAim",
            ownerid="9aGBHLaWqt",
            secret="06934b55e622cb1f0f5b57f664bacdafa36c8038f0fcd19fb09f68a989205f33",
            version="1.0",
            hash_to_check=LoginForm.getchecksum()
        )
        
        auth_instance.init()
        auth_instance.license(key)
        
        # Sauvegarder la clé
        key_path = os.path.join(extra_path, 'gfx', 'key.txt')
        os.makedirs(os.path.dirname(key_path), exist_ok=True)
        with open(key_path, 'w') as f:
            f.write(key)
        
        logging.info("Authentication successful")
        return jsonify({"success": True, "message": "License validated"})
            
    except Exception as e:
        logging.error(f"Authentication failed: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 400

if __name__ == '__main__':
    logging.info("Starting authentication server...")
    app.run(port=5789, host='127.0.0.1', threaded=True)