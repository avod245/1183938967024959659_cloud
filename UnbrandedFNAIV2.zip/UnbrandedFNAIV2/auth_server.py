import os
import sys
import logging
import importlib.util
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import psutil

# Configuration des chemins
SCRIPT_DIR = Path(__file__).resolve().parent
EXTRA_DIR = SCRIPT_DIR / 'extra'
LOGS_DIR = SCRIPT_DIR / 'logs'

# Création des dossiers nécessaires
LOGS_DIR.mkdir(exist_ok=True)

# Configuration du logging
log_file = LOGS_DIR / 'auth_server.log'
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def import_main_module():
    """Importe le module main.py de manière sécurisée"""
    try:
        main_path = EXTRA_DIR / 'main.py'
        spec = importlib.util.spec_from_file_location("main", main_path)
        main_module = importlib.util.module_from_spec(spec)
        sys.modules["main"] = main_module
        spec.loader.exec_module(main_module)
        logger.info("Module main.py importé avec succès")
        return main_module
    except Exception as e:
        logger.error(f"Erreur lors de l'importation du module main: {e}")
        raise

def check_port(port):
    """Vérifie si un port est utilisé et termine le processus si nécessaire"""
    try:
        for proc in psutil.process_iter(['pid', 'name', 'connections']):
            try:
                conns = proc.info.get('connections', [])
                for conn in conns:
                    if hasattr(conn, 'laddr') and conn.laddr.port == port:
                        logger.warning(f"Terminaison du processus {proc.pid} utilisant le port {port}")
                        proc.kill()
                        return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception as e:
        logger.error(f"Erreur lors de la vérification du port: {e}")
    return False

# Import du module main et création de l'application Flask
try:
    main_module = import_main_module()
    app = Flask(__name__, static_folder='webview/static')
    CORS(app, resources={
        r"/*": {
            "origins": ["http://localhost:5789"],
            "methods": ["GET", "POST", "OPTIONS"],
            "allow_headers": ["Content-Type"]
        }
    })
except Exception as e:
    logger.critical(f"Erreur fatale lors de l'initialisation: {e}")
    sys.exit(1)

@app.route('/status')
def status():
    """Endpoint de vérification du statut"""
    try:
        auth_status = (
            main_module.app_manager.auth_verified
            if hasattr(main_module, 'app_manager') else False
        )
        return jsonify({
            "status": "running",
            "auth_initialized": auth_status
        })
    except Exception as e:
        logger.error(f"Erreur status: {e}")
        return jsonify({"status": "error"}), 500

@app.route('/auth', methods=['POST'])
def authenticate():
    """Endpoint d'authentification"""
    try:
        key = request.json.get('key')
        if not key:
            logger.warning("Clé non fournie")
            return jsonify({"success": False, "message": "Clé requise"}), 400

        logger.info("Traitement de la requête d'authentification")
        auth_result = main_module.app_manager.authenticate(key)
        
        if auth_result.success:
            logger.info("Authentification réussie")
            success, message = main_module.app_manager.start_application()
            
            if success:
                logger.info("Application démarrée avec succès")
                return jsonify({
                    "success": True, 
                    "message": "Authentification réussie",
                    "userData": auth_result.user_data
                })
            else:
                logger.error(f"Échec du démarrage: {message}")
                return jsonify({
                    "success": False,
                    "message": message
                }), 500
        else:
            logger.warning(f"Échec de l'authentification: {auth_result.message}")
            return jsonify({
                "success": False,
                "message": auth_result.message
            }), 401

    except Exception as e:
        logger.error(f"Erreur d'authentification: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    return response

def main():
    """Point d'entrée principal"""
    try:
        port = 5789
        check_port(port)
        logger.info(f"Démarrage du serveur sur le port {port}")
        app.run(
            host='127.0.0.1',
            port=port,
            threaded=True,
            use_reloader=False
        )
    except Exception as e:
        logger.critical(f"Échec du démarrage du serveur: {e}", exc_info=True)
        sys.exit(1)

if __name__ == '__main__':
    main()
