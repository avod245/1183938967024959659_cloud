# auth_server.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
from datetime import datetime
from main import app_manager

# Création du dossier logs s'il n'existe pas
current_dir = os.path.dirname(os.path.abspath(__file__))
logs_dir = os.path.join(current_dir, 'logs')
os.makedirs(logs_dir, exist_ok=True)

# Configuration du logging avec timestamp dans le nom du fichier
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
log_file = os.path.join(logs_dir, f'auth_server_{timestamp}.log')

# Configuration du logging
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Configuration du logging console en plus du fichier
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logging.getLogger('').addHandler(console_handler)

app = Flask(__name__)
CORS(app)

@app.route('/status', methods=['GET'])
def status():
    """
    Endpoint de vérification du statut
    """
    logging.info("Status check received")
    return jsonify({
        "status": "running",
        "auth_initialized": app_manager.auth_verified if hasattr(app_manager, 'auth_verified') else False
    })

@app.route('/auth', methods=['POST'])
def authenticate():
    """
    Point d'entrée d'authentification
    """
    try:
        key = request.json.get('key')
        if not key:
            logging.warning("No key provided in authentication request")
            return jsonify({
                "success": False,
                "message": "No key provided"
            }), 400

        logging.info("Processing authentication request")
        auth_result = app_manager.authenticate(key)
        
        if auth_result.success:
            logging.info("Authentication successful, starting application")
            success, message = app_manager.start_application()
            if not success:
                logging.error(f"Failed to start application: {message}")
                return jsonify({
                    "success": False,
                    "message": message
                }), 500

            logging.info("Application started successfully")
            return jsonify({
                "success": True,
                "message": "Authentication successful",
                "userData": auth_result.user_data
            })
        else:
            logging.warning(f"Authentication failed: {auth_result.message}")
            return jsonify({
                "success": False,
                "message": auth_result.message
            }), 401

    except Exception as e:
        logging.error(f"Authentication error: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

if __name__ == '__main__':
    try:
        port = 5789
        logging.info(f"Starting authentication server on port {port}...")
        # Test si le port est disponible
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', port))
        if result == 0:
            logging.warning(f"Port {port} is already in use")
            # Tentative de libération du port
            sock.close()
            import psutil
            for proc in psutil.process_iter(['pid', 'name', 'connections']):
                for conn in proc.info.get('connections', []):
                    if conn.laddr.port == port:
                        logging.info(f"Killing process {proc.info['pid']} using port {port}")
                        psutil.Process(proc.info['pid']).kill()
                        break
        
        app.run(host='127.0.0.1', port=port, threaded=True)
    except Exception as e:
        logging.critical(f"Server failed to start: {e}", exc_info=True)
        sys.exit(1)