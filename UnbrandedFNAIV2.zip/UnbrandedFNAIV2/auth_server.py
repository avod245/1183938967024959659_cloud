from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import importlib.util
import time

# Configuration des chemins avec logs plus visibles
current_directory = os.path.dirname(os.path.abspath(__file__))
log_file = os.path.join(current_directory, 'debug_server.log')
print(f"Log file will be created at: {log_file}")  # Debug print

# Configuration du logging avec plus de détails
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    force=True
)

# Ajouter aussi le logging vers la console
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
logging.getLogger('').addHandler(console_handler)

# Log de démarrage
logging.info(f"Starting server in directory: {current_directory}")

app = Flask(__name__)
CORS(app)

@app.route('/status', methods=['GET'])
def status():
    logging.info("Status endpoint called")
    return jsonify({"status": "ready"})

if __name__ == '__main__':
    try:
        logging.info("Starting authentication server...")
        app.run(port=5789, host='127.0.0.1')
    except Exception as e:
        logging.error(f"Server failed to start: {str(e)}")
        sys.exit(1)