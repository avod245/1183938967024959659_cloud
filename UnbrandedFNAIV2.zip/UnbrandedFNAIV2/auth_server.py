from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import importlib.util
import time

# Configuration des chemins
current_directory = os.path.dirname(os.path.abspath(__file__))
main_path = os.path.join(current_directory, "extra", "main.py")
log_path = os.path.join(current_directory, "logs")

# Créer le dossier logs s'il n'existe pas
os.makedirs(log_path, exist_ok=True)

# Configuration du logging
logging.basicConfig(
    filename=os.path.join(log_path, 'auth_server.log'),
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Import de main.py
try:
    logging.info(f"Loading main.py from {main_path}")
    spec = importlib.util.spec_from_file_location("main", main_path)
    main_module = importlib.util.module_from_spec(spec)
    sys.modules["main"] = main_module
    spec.loader.exec_module(main_module)
    logging.info("Successfully loaded main.py")
except Exception as e:
    logging.error(f"Failed to load main.py: {str(e)}")
    sys.exit(1)

@app.route('/status', methods=['GET'])
def status():
    try:
        key_path = os.path.join(current_directory, 'extra', 'gfx', 'key.txt')
        key_exists = os.path.exists(key_path)
        logging.info(f"Status check - key exists: {key_exists}")
        return jsonify({
            "status": "ready",
            "authenticated": key_exists
        })
    except Exception as e:
        logging.error(f"Status check failed: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/auth', methods=['POST'])
def auth():
    try:
        key = request.json.get('key')
        if not key:
            return jsonify({"success": False, "message": "No key provided"}), 400

        logging.info("Attempting to verify license key")
        
        try:
            # Initialiser l'auth avec KeyAuth
            auth = main_module.api(
                name="AiAim",
                ownerid="9aGBHLaWqt",
                secret="06934b55e622cb1f0f5b57f664bacdafa36c8038f0fcd19fb09f68a989205f33",
                version="1.0",
                hash_to_check=main_module.LoginForm.getchecksum()
            )
            
            auth.init()
            auth.license(key)
            
            # Sauvegarder la clé
            key_path = os.path.join(current_directory, 'extra', 'gfx', 'key.txt')
            os.makedirs(os.path.dirname(key_path), exist_ok=True)
            with open(key_path, 'w') as f:
                f.write(key)
            
            logging.info("License successfully validated")
            return jsonify({"success": True, "message": "License validated"})
            
        except Exception as e:
            logging.error(f"License validation failed: {str(e)}")
            return jsonify({"success": False, "message": str(e)}), 400
            
    except Exception as e:
        logging.error(f"Auth failed: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 500

def wait_for_port_available(port, timeout=30):
    import socket
    start_time = time.time()
    while True:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', port))
                return True
        except socket.error:
            if time.time() - start_time > timeout:
                return False
            time.sleep(1)

if __name__ == '__main__':
    try:
        port = 5789
        if not wait_for_port_available(port):
            logging.error(f"Port {port} is not available after timeout")
            sys.exit(1)

        logging.info("Starting authentication server...")
        app.run(host='127.0.0.1', port=port, threaded=True)
    except Exception as e:
        logging.error(f"Server failed to start: {e}")
        sys.exit(1)