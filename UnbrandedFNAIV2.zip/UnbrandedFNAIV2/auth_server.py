from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import importlib.util

# Configuration des chemins
current_directory = os.path.dirname(os.path.abspath(__file__))
main_path = os.path.join(current_directory, "extra", "main.py")
log_path = os.path.join(current_directory, "logs")

# Configuration du logging
os.makedirs(log_path, exist_ok=True)
logging.basicConfig(
    filename=os.path.join(log_path, 'auth_server.log'),
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Initialisation de l'application Flask
app = Flask(__name__)
CORS(app)

def load_main_module():
    """
    Charge dynamiquement le module principal `main.py`.
    """
    try:
        spec = importlib.util.spec_from_file_location("main", main_path)
        main_module = importlib.util.module_from_spec(spec)
        sys.modules["main"] = main_module
        spec.loader.exec_module(main_module)
        logging.info("Main module loaded successfully.")
        return main_module
    except Exception as e:
        logging.error(f"Failed to load main module: {e}")
        return None

main_module = load_main_module()

@app.route('/auth', methods=['POST'])
def authenticate():
    """
    Gère la validation de la clé d'authentification envoyée par le client C#.
    """
    if not main_module:
        return jsonify({
            "success": False,
            "message": "Main module not loaded"
        }), 500

    key = request.json.get('key')
    if not key:
        return jsonify({
            "success": False,
            "message": "No key provided"
        }), 400

    try:
        # Charger la classe API depuis `main.py`
        api_class = getattr(main_module, 'api', None)
        if not api_class:
            return jsonify({
                "success": False,
                "message": "API class not found in main.py"
            }), 500

        # Initialiser et valider la clé
        auth = api_class(
            name="AiAim",
            ownerid="9aGBHLaWqt",
            secret="06934b55e622cb1f0f5b57f664bacdafa36c8038f0fcd19fb09f68a989205f33",
            version="1.0",
            hash_to_check=main_module.calculate_checksum()
        )
        auth.init()
        auth.license(key)

        logging.info("License key validated successfully.")
        return jsonify({
            "success": True,
            "message": "License validated successfully"
        })

    except Exception as e:
        logging.error(f"Authentication failed: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 400

@app.route('/status', methods=['GET'])
def status():
    """
    Vérifie l'état du serveur et la disponibilité du module principal.
    """
    return jsonify({
        "status": "running",
        "module_loaded": main_module is not None
    })

if __name__ == '__main__':
    try:
        port = 5789
        logging.info("Starting authentication server...")
        app.run(host='127.0.0.1', port=port, threaded=True)
    except Exception as e:
        logging.error(f"Server failed to start: {e}")
        sys.exit(1)
