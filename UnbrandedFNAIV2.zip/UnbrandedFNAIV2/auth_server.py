from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import importlib.util

app = Flask(__name__)
CORS(app)

# Importer dynamiquement main.py pour utiliser ses classes
spec = importlib.util.spec_from_file_location("main", "main.py")
main_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(main_module)

@app.route('/status', methods=['GET'])
def status():
    try:
        # Vérifier si le fichier de clé existe
        key_path = os.path.join(current_directory, 'extra', 'gfx', 'key.txt')
        key_exists = os.path.exists(key_path)
        return jsonify({
            "status": "ready",
            "authenticated": key_exists
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        })

@app.route('/auth', methods=['POST'])
def auth():
    try:
        key = request.json.get('key')
        if not key:
            return jsonify({"success": False, "message": "No key provided"})

        # Utiliser la classe api de main.py
        auth = main_module.api(
            name="AiAim",
            ownerid="9aGBHLaWqt",
            secret="06934b55e622cb1f0f5b57f664bacdafa36c8038f0fcd19fb09f68a989205f33",
            version="1.0",
            hash_to_check=main_module.LoginForm.getchecksum()
        )
        
        auth.init()
        
        try:
            auth.license(key)
            
            # Sauvegarder la clé
            key_path = os.path.join("extra", "gfx", "key.txt")
            with open(key_path, 'w') as f:
                f.write(key)
                
            return jsonify({"success": True, "message": "License validated"})
            
        except Exception as e:
            return jsonify({"success": False, "message": str(e)})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

if __name__ == '__main__':
    app.run(port=5789)