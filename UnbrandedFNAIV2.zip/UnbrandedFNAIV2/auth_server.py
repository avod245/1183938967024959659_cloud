from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import importlib.util
import tempfile

# Utiliser le dossier temp du système
temp_dir = tempfile.gettempdir()
log_file = os.path.join(temp_dir, 'unbranded_fnai_debug.log')

# Configuration du logging
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Log de démarrage avec information sur le fichier de log
print(f"Logs will be written to: {log_file}")
logging.info(f"Starting server, log file location: {log_file}")

app = Flask(__name__)
CORS(app)

@app.route('/status', methods=['GET'])
def status():
    logging.info("Status endpoint called")
    return jsonify({"status": "ready"})

if __name__ == '__main__':
    try:
        logging.info("Starting authentication server...")
        app.run(port=5789, host='127.0.0.1')
    except Exception as e:
        logging.error(f"Server failed to start: {str(e)}")
        # Écrire aussi l'erreur dans un fichier séparé dans temp
        with open(os.path.join(temp_dir, 'unbranded_fnai_error.txt'), 'w') as f:
            f.write(str(e))
        sys.exit(1)