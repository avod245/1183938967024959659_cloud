from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging
import subprocess
from main import app_manager

# Configuration du logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
CORS(app)

@app.route('/auth', methods=['POST'])
def authenticate():
    """
    Point d'entrée d'authentification
    """
    try:
        key = request.json.get('key')
        if not key:
            return jsonify({
                "success": False,
                "message": "No key provided"
            }), 400

        # Authentification via le gestionnaire d'application
        auth_result = app_manager.authenticate(key)
        
        if auth_result.success:
            # Démarrage de l'application si l'authentification réussit
            success, message = app_manager.start_application()
            if not success:
                return jsonify({
                    "success": False,
                    "message": message
                }), 500

            return jsonify({
                "success": True,
                "message": "Authentication successful",
                "userData": auth_result.user_data
            })
        else:
            return jsonify({
                "success": False,
                "message": auth_result.message
            }), 401

    except Exception as e:
        logging.error(f"Authentication error: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

@app.route('/status', methods=['GET'])
def status():
    """
    Endpoint de vérification du statut
    """
    return jsonify({
        "status": "running",
        "auth_initialized": app_manager.auth_verified
    })

if __name__ == '__main__':
    try:
        port = 5789
        logging.info("Starting authentication server...")
        app.run(host='127.0.0.1', port=port, threaded=True)
    except Exception as e:
        logging.error(f"Server failed to start: {e}")
        sys.exit(1)