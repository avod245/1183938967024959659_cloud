import os
import sys
import logging
import importlib.util
from pathlib import Path
from flask import Flask, request, jsonify
from flask_cors import CORS
import psutil
import traceback

# Configuration des chemins
SCRIPT_DIR = Path(__file__).resolve().parent
EXTRA_DIR = SCRIPT_DIR / 'extra'
LOGS_DIR = SCRIPT_DIR / 'logs'
LOGS_DIR.mkdir(exist_ok=True)

# Configuration du logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / 'auth_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AuthServer:
    def __init__(self):
        self.app = Flask(__name__)
        self._setup_cors()
        self._setup_routes()
        self._initialize_main()

    def _setup_cors(self):
        # Configuration CORS plus permissive pour le développement local
        CORS(self.app, supports_credentials=True)
        
    def _initialize_main(self):
        """Initialise le module main de manière sécurisée"""
        try:
            main_path = EXTRA_DIR / 'main.py'
            if not main_path.exists():
                raise FileNotFoundError(f"main.py not found in {EXTRA_DIR}")

            sys.path.insert(0, str(EXTRA_DIR))
            from main import app_manager
            self.app_manager = app_manager
            logger.info("Module main.py chargé avec succès")
        except Exception as e:
            logger.error(f"Erreur lors du chargement de main.py: {traceback.format_exc()}")
            raise

    def _setup_routes(self):
        @self.app.route('/status', methods=['GET'])
        def status():
            """Endpoint de vérification du statut"""
            try:
                is_ready = hasattr(self, 'app_manager')
                auth_status = self.app_manager.auth_verified if is_ready else False
                
                return jsonify({
                    "status": "running",
                    "ready": is_ready,
                    "authenticated": auth_status
                })
            except Exception as e:
                logger.error(f"Erreur /status: {traceback.format_exc()}")
                return jsonify({
                    "status": "error",
                    "message": str(e)
                }), 500

        @self.app.route('/auth', methods=['POST'])
        def authenticate():
            """Endpoint d'authentification"""
            try:
                data = request.get_json()
                if not data or 'key' not in data:
                    return jsonify({
                        "success": False,
                        "message": "License key required"
                    }), 400

                key = data['key']
                logger.info("Tentative d'authentification...")
                
                # Utilisation du gestionnaire d'authentification de main.py
                auth_result = self.app_manager.authenticate(key)
                
                if auth_result.success:
                    logger.info("Authentification réussie")
                    # Démarrage de l'application
                    success, message = self.app_manager.start_application()
                    
                    if success:
                        return jsonify({
                            "success": True,
                            "message": "Authentication successful",
                            "userData": auth_result.user_data
                        })
                    else:
                        logger.error(f"Échec du démarrage: {message}")
                        return jsonify({
                            "success": False,
                            "message": f"Failed to start application: {message}"
                        }), 500
                else:
                    logger.warning(f"Échec de l'authentification: {auth_result.message}")
                    return jsonify({
                        "success": False,
                        "message": auth_result.message
                    }), 401

            except Exception as e:
                logger.error(f"Erreur d'authentification: {traceback.format_exc()}")
                return jsonify({
                    "success": False,
                    "message": str(e)
                }), 500

    def check_port(self, port):
        """Vérifie et libère le port si nécessaire"""
        for proc in psutil.process_iter(['pid', 'name', 'connections']):
            try:
                for conn in proc.connections():
                    if conn.laddr.port == port:
                        logger.warning(f"Killing process {proc.pid} using port {port}")
                        proc.kill()
                        return True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return False

    def run(self, host='127.0.0.1', port=5789):
        """Démarre le serveur"""
        try:
            self.check_port(port)
            logger.info(f"Démarrage du serveur sur {host}:{port}")
            self.app.run(
                host=host,
                port=port,
                threaded=True,
                use_reloader=False
            )
        except Exception as e:
            logger.error(f"Erreur de démarrage du serveur: {traceback.format_exc()}")
            raise

def main():
    """Point d'entrée principal"""
    try:
        server = AuthServer()
        server.run()
    except Exception as e:
        logger.critical(f"Erreur fatale: {traceback.format_exc()}")
        sys.exit(1)

if __name__ == '__main__':
    main()