from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sys
import logging

# S'assurer que le dossier parent est dans le PYTHONPATH
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import app_manager

app = Flask(__name__)
CORS(app)

# Logging simple vers un fichier local
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='server.log',
    filemode='a'
)

@app.route('/status', methods=['GET'])
def status():
    try:
        return jsonify({
            "status": "running",
            "auth_initialized": hasattr(app_manager, 'auth_verified') and app_manager.auth_verified
        })
    except Exception as e:
        logging.error(f"Status check error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/auth', methods=['POST'])
def authenticate():
    try:
        key = request.json.get('key')
        if not key:
            return jsonify({
                "success": False,
                "message": "No key provided"
            }), 400

        auth_result = app_manager.authenticate(key)
        if auth_result.success:
            success, message = app_manager.start_application()
            if success:
                return jsonify({
                    "success": True,
                    "message": "Authentication successful",
                    "userData": auth_result.user_data
                })
            else:
                return jsonify({
                    "success": False,
                    "message": f"Start failed: {message}"
                }), 500
        else:
            return jsonify({
                "success": False,
                "message": auth_result.message
            }), 401

    except Exception as e:
        logging.error(f"Auth error: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

if __name__ == '__main__':
    try:
        app.run(host='127.0.0.1', port=5789, threaded=True)
    except Exception as e:
        logging.error(f"Server failed to start: {e}")
        sys.exit(1)