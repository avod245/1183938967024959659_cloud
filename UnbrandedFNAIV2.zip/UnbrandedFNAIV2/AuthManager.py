# auth_manager.py
import hashlib
import sys
import os

class AuthManager:
    def __init__(self):
        self.api = None
        
    def initialize_auth(self, name, ownerid, secret, version):
        """
        Initialise l'authentification avec les paramètres KeyAuth
        """
        try:
            from keyauth import api
            self.api = api(
                name=name,
                ownerid=ownerid, 
                secret=secret,
                version=version,
                hash_to_check=self.calculate_checksum()
            )
            self.api.init()
            return True
        except Exception as e:
            print(f"Error initializing auth: {e}")
            return False
            
    def validate_license(self, key):
        """
        Vérifie la validité d'une clé de licence
        """
        try:
            if not self.api:
                return False, "Auth not initialized"
                
            self.api.license(key)
            return True, "License valid"
        except Exception as e:
            return False, str(e)
            
    def calculate_checksum(self):
        """
        Calcule le checksum du fichier principal
        """
        md5_hash = hashlib.md5()
        try:
            with open(sys.argv[0], "rb") as file:
                md5_hash.update(file.read())
            return md5_hash.hexdigest()
        except Exception as e:
            print(f"Error calculating checksum: {e}")
            return ""